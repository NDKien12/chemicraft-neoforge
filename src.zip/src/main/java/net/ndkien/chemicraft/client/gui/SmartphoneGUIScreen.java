package net.ndkien.chemicraft.client.gui;

import net.neoforged.neoforge.client.network.ClientPacketDistributor;

import net.ndkien.chemicraft.world.inventory.SmartphoneGUIMenu;
import net.ndkien.chemicraft.network.SmartphoneGUIButtonMessage;
import net.ndkien.chemicraft.init.ChemicraftModScreens;

import net.minecraft.world.level.Level;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.resources.Identifier;
import net.minecraft.network.chat.Component;
import net.minecraft.client.renderer.RenderPipelines;
import net.minecraft.client.input.KeyEvent;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.GuiGraphicsExtractor;

import com.mojang.blaze3d.platform.InputConstants;

public class SmartphoneGUIScreen extends AbstractContainerScreen<SmartphoneGUIMenu> implements ChemicraftModScreens.ScreenAccessor {
	private final Level world;
	private final int x, y, z;
	private final Player entity;
	private boolean menuStateUpdateActive = false;
	private Button button_router_1;
	private Button button_router_2;
	private Button button_router_3;
	private Button button_router_4;
	private static final Identifier BACKGROUND = Identifier.parse("chemicraft:textures/screens/smartphone_gui.png");

	public SmartphoneGUIScreen(SmartphoneGUIMenu container, Inventory inventory, Component text) {
		super(container, inventory, text, 108, 192);
		this.world = container.world;
		this.x = container.x;
		this.y = container.y;
		this.z = container.z;
		this.entity = container.entity;
	}

	@Override
	public void updateMenuState(int elementType, String name, Object elementState) {
		menuStateUpdateActive = true;
		menuStateUpdateActive = false;
	}

	@Override
	public void extractRenderState(GuiGraphicsExtractor guiGraphics, int mouseX, int mouseY, float partialTicks) {
		super.extractRenderState(guiGraphics, mouseX, mouseY, partialTicks);
	}

	@Override
	public void extractBackground(GuiGraphicsExtractor guiGraphics, int mouseX, int mouseY, float partialTicks) {
		super.extractBackground(guiGraphics, mouseX, mouseY, partialTicks);
		guiGraphics.blit(RenderPipelines.GUI_TEXTURED, BACKGROUND, this.leftPos, this.topPos, 0, 0, this.imageWidth, this.imageHeight, this.imageWidth, this.imageHeight);
	}

	@Override
	public boolean keyPressed(KeyEvent event) {
		int key = InputConstants.getKey(event).getValue();
		if (key == 256) {
			this.minecraft.player.closeContainer();
			return true;
		}
		return super.keyPressed(event);
	}

	@Override
	protected void extractLabels(GuiGraphicsExtractor guiGraphics, int mouseX, int mouseY) {
		guiGraphics.text(this.font, Component.translatable("gui.chemicraft.smartphone_gui.label_send_request_to"), 8, 11, -12829636, false);
		guiGraphics.text(this.font, Component.translatable("gui.chemicraft.smartphone_gui.label_send_request_to1"), 8, 29, -12829636, false);
	}

	@Override
	public void init() {
		super.init();
		button_router_1 = Button.builder(Component.translatable("gui.chemicraft.smartphone_gui.button_router_1"), e -> {
			int x = SmartphoneGUIScreen.this.x;
			int y = SmartphoneGUIScreen.this.y;
			if (true) {
				ClientPacketDistributor.sendToServer(new SmartphoneGUIButtonMessage(0, x, y, z));
				SmartphoneGUIButtonMessage.handleButtonAction(entity, 0, x, y, z);
			}
		}).bounds(this.leftPos + 8, this.topPos + 47, 70, 20).build();
		this.addRenderableWidget(button_router_1);
		button_router_2 = Button.builder(Component.translatable("gui.chemicraft.smartphone_gui.button_router_2"), e -> {
			int x = SmartphoneGUIScreen.this.x;
			int y = SmartphoneGUIScreen.this.y;
			if (true) {
				ClientPacketDistributor.sendToServer(new SmartphoneGUIButtonMessage(1, x, y, z));
				SmartphoneGUIButtonMessage.handleButtonAction(entity, 1, x, y, z);
			}
		}).bounds(this.leftPos + 8, this.topPos + 74, 70, 20).build();
		this.addRenderableWidget(button_router_2);
		button_router_3 = Button.builder(Component.translatable("gui.chemicraft.smartphone_gui.button_router_3"), e -> {
			int x = SmartphoneGUIScreen.this.x;
			int y = SmartphoneGUIScreen.this.y;
			if (true) {
				ClientPacketDistributor.sendToServer(new SmartphoneGUIButtonMessage(2, x, y, z));
				SmartphoneGUIButtonMessage.handleButtonAction(entity, 2, x, y, z);
			}
		}).bounds(this.leftPos + 8, this.topPos + 101, 70, 20).build();
		this.addRenderableWidget(button_router_3);
		button_router_4 = Button.builder(Component.translatable("gui.chemicraft.smartphone_gui.button_router_4"), e -> {
			int x = SmartphoneGUIScreen.this.x;
			int y = SmartphoneGUIScreen.this.y;
			if (true) {
				ClientPacketDistributor.sendToServer(new SmartphoneGUIButtonMessage(3, x, y, z));
				SmartphoneGUIButtonMessage.handleButtonAction(entity, 3, x, y, z);
			}
		}).bounds(this.leftPos + 8, this.topPos + 128, 70, 20).build();
		this.addRenderableWidget(button_router_4);
	}
}