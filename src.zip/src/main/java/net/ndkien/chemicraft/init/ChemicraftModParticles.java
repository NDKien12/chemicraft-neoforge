/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.ndkien.chemicraft.init;

import net.neoforged.neoforge.client.event.RegisterParticleProvidersEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.api.distmarker.Dist;

import net.ndkien.chemicraft.client.particle.TwoParticle;
import net.ndkien.chemicraft.client.particle.ThreeParticle;
import net.ndkien.chemicraft.client.particle.OneParticle;
import net.ndkien.chemicraft.client.particle.FourParticle;

@EventBusSubscriber(Dist.CLIENT)
public class ChemicraftModParticles {
	@SubscribeEvent
	public static void registerParticles(RegisterParticleProvidersEvent event) {
		event.registerSpriteSet(ChemicraftModParticleTypes.ONE.get(), OneParticle::provider);
		event.registerSpriteSet(ChemicraftModParticleTypes.TWO.get(), TwoParticle::provider);
		event.registerSpriteSet(ChemicraftModParticleTypes.THREE.get(), ThreeParticle::provider);
		event.registerSpriteSet(ChemicraftModParticleTypes.FOUR.get(), FourParticle::provider);
	}
}