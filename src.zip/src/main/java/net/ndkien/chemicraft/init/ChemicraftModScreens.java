/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package net.ndkien.chemicraft.init;

import net.neoforged.neoforge.client.event.RegisterMenuScreensEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.api.distmarker.Dist;

import net.ndkien.chemicraft.client.gui.SmartphoneGUIScreen;
import net.ndkien.chemicraft.client.gui.ElectrolysisScreen;
import net.ndkien.chemicraft.client.gui.CyclotronGUIScreen;

@EventBusSubscriber(Dist.CLIENT)
public class ChemicraftModScreens {
	@SubscribeEvent
	public static void clientLoad(RegisterMenuScreensEvent event) {
		event.register(ChemicraftModMenus.ELECTROLYSIS.get(), ElectrolysisScreen::new);
		event.register(ChemicraftModMenus.SMARTPHONE_GUI.get(), SmartphoneGUIScreen::new);
		event.register(ChemicraftModMenus.CYCLOTRON_GUI.get(), CyclotronGUIScreen::new);
	}

	public interface ScreenAccessor {
		void updateMenuState(int elementType, String name, Object elementState);
	}
}