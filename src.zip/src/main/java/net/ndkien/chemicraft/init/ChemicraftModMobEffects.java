/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package net.ndkien.chemicraft.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredHolder;

import net.ndkien.chemicraft.potion.AnesthesiaMobEffect;
import net.ndkien.chemicraft.ChemicraftMod;

import net.minecraft.world.effect.MobEffect;
import net.minecraft.core.registries.Registries;

public class ChemicraftModMobEffects {
	public static final DeferredRegister<MobEffect> REGISTRY = DeferredRegister.create(Registries.MOB_EFFECT, ChemicraftMod.MODID);
	public static final DeferredHolder<MobEffect, MobEffect> ANESTHESIA = REGISTRY.register("anesthesia", AnesthesiaMobEffect::new);
}