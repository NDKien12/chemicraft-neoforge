/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.ndkien.chemicraft.init;

import net.neoforged.neoforge.client.event.EntityRenderersEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.api.distmarker.Dist;

import net.minecraft.client.renderer.entity.ThrownItemRenderer;

@EventBusSubscriber(Dist.CLIENT)
public class ChemicraftModEntityRenderers {
	@SubscribeEvent
	public static void registerEntityRenderers(EntityRenderersEvent.RegisterRenderers event) {
		event.registerEntityRenderer(ChemicraftModEntities.MISSILE_PROJECTILE.get(), ThrownItemRenderer::new);
		event.registerEntityRenderer(ChemicraftModEntities.GAS_BOMB_PROJECTILE.get(), ThrownItemRenderer::new);
		event.registerEntityRenderer(ChemicraftModEntities.BLADE_PROJECTILE.get(), ThrownItemRenderer::new);
		event.registerEntityRenderer(ChemicraftModEntities.ANESTHESIA_BOMB_PROJECTILE.get(), ThrownItemRenderer::new);
		event.registerEntityRenderer(ChemicraftModEntities.MILD_MISSILE_PROJECTILE.get(), ThrownItemRenderer::new);
		event.registerEntityRenderer(ChemicraftModEntities.STRONG_MISSILE_PROJECTILE.get(), ThrownItemRenderer::new);
	}
}