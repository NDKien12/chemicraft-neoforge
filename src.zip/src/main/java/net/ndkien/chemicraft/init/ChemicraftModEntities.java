/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.ndkien.chemicraft.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredHolder;

import net.ndkien.chemicraft.entity.MissileProjectileEntity;
import net.ndkien.chemicraft.entity.GasBombProjectileEntity;
import net.ndkien.chemicraft.entity.BladeProjectileEntity;
import net.ndkien.chemicraft.entity.AnesthesiaBombProjectileEntity;
import net.ndkien.chemicraft.ChemicraftMod;

import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Entity;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.Identifier;
import net.minecraft.core.registries.Registries;

public class ChemicraftModEntities {
	public static final DeferredRegister<EntityType<?>> REGISTRY = DeferredRegister.create(Registries.ENTITY_TYPE, ChemicraftMod.MODID);
	public static final DeferredHolder<EntityType<?>, EntityType<MissileProjectileEntity>> MISSILE_PROJECTILE = register("missile_projectile",
			EntityType.Builder.<MissileProjectileEntity>of(MissileProjectileEntity::new, MobCategory.MISC).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(1).sized(1f, 1f));
	public static final DeferredHolder<EntityType<?>, EntityType<GasBombProjectileEntity>> GAS_BOMB_PROJECTILE = register("gas_bomb_projectile",
			EntityType.Builder.<GasBombProjectileEntity>of(GasBombProjectileEntity::new, MobCategory.MISC).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(1).sized(0.5f, 0.5f));
	public static final DeferredHolder<EntityType<?>, EntityType<BladeProjectileEntity>> BLADE_PROJECTILE = register("blade_projectile",
			EntityType.Builder.<BladeProjectileEntity>of(BladeProjectileEntity::new, MobCategory.MISC).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(1).sized(0.5f, 0.5f));
	public static final DeferredHolder<EntityType<?>, EntityType<AnesthesiaBombProjectileEntity>> ANESTHESIA_BOMB_PROJECTILE = register("anesthesia_bomb_projectile",
			EntityType.Builder.<AnesthesiaBombProjectileEntity>of(AnesthesiaBombProjectileEntity::new, MobCategory.MISC).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(1).sized(0.5f, 0.5f));

	// Start of user code block custom entities
	// End of user code block custom entities
	private static <T extends Entity> DeferredHolder<EntityType<?>, EntityType<T>> register(String registryname, EntityType.Builder<T> entityTypeBuilder) {
		return REGISTRY.register(registryname, () -> (EntityType<T>) entityTypeBuilder.build(ResourceKey.create(Registries.ENTITY_TYPE, Identifier.fromNamespaceAndPath(ChemicraftMod.MODID, registryname))));
	}
}