/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.ndkien.chemicraft.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredBlock;
import net.neoforged.neoforge.client.event.RegisterColorHandlersEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.api.distmarker.Dist;

import net.ndkien.chemicraft.block.*;
import net.ndkien.chemicraft.ChemicraftMod;

import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.Block;

import java.util.function.Function;

public class ChemicraftModBlocks {
	public static final DeferredRegister.Blocks REGISTRY = DeferredRegister.createBlocks(ChemicraftMod.MODID);
	public static final DeferredBlock<Block> SPONDUMENE_ORE;
	public static final DeferredBlock<Block> DEEPSLATE_SPONDUMENE_ORE;
	public static final DeferredBlock<Block> ELECTROLYSIS_MACHINE;
	public static final DeferredBlock<Block> AQUAMARINE_ORE;
	public static final DeferredBlock<Block> DEEPSLATE_AQUAMARINE_ORE;
	public static final DeferredBlock<Block> BLOCK_OF_LITHIUM;
	public static final DeferredBlock<Block> BLOCK_OF_BERYLLIUM;
	public static final DeferredBlock<Block> BORAX_ORE;
	public static final DeferredBlock<Block> DEEPSLATE_BORAX_ORE;
	public static final DeferredBlock<Block> BLOCK_OF_STEEL;
	public static final DeferredBlock<Block> BLOCK_OF_BORON;
	public static final DeferredBlock<Block> BLOCK_OF_CARBON;
	public static final DeferredBlock<Block> BLOCK_OF_AQUAMARINE;
	public static final DeferredBlock<Block> MISSILE_LAUNCHER;
	public static final DeferredBlock<Block> FLUORITE_ORE;
	public static final DeferredBlock<Block> DEEPSLATE_FLUORITE_ORE;
	public static final DeferredBlock<Block> HELIUM_LIGHT_STICK;
	public static final DeferredBlock<Block> NEON_LIGHT_STICK;
	public static final DeferredBlock<Block> ARGON_LIGHT_STICK;
	public static final DeferredBlock<Block> KRYPTON_LIGHT_STICK;
	public static final DeferredBlock<Block> XENON_LIGHT_STICK;
	public static final DeferredBlock<Block> RADON_LIGHT_STICK;
	public static final DeferredBlock<Block> SALT_CRYSTAL_ORE;
	public static final DeferredBlock<Block> DEEPSLATE_SALT_CRYSTAL_ORE;
	public static final DeferredBlock<Block> BLOCK_OF_SODIUM;
	public static final DeferredBlock<Block> CRYOLITE_ORE;
	public static final DeferredBlock<Block> DEEPSLATE_CRYOLITE_ORE;
	public static final DeferredBlock<Block> BAUXITE;
	public static final DeferredBlock<Block> BLOCK_OF_MAGNESSIUM;
	public static final DeferredBlock<Block> BLOCK_OF_ALUMINUM;
	public static final DeferredBlock<Block> BLOCK_OF_SILICON;
	public static final DeferredBlock<Block> WEATHER_SENSOR;
	public static final DeferredBlock<Block> APATITE_ORE;
	public static final DeferredBlock<Block> DEEPSLATE_APATITE_ORE;
	public static final DeferredBlock<Block> BLOCK_OF_APATITE;
	public static final DeferredBlock<Block> BLOCK_OF_PHOSPHORUS;
	public static final DeferredBlock<Block> SULFUR_ORE;
	public static final DeferredBlock<Block> DEEPSLATE_SULFUR_ORE;
	public static final DeferredBlock<Block> SILVITE_ORE;
	public static final DeferredBlock<Block> DEEPSLATE_SILVITE_ORE;
	public static final DeferredBlock<Block> BLOCK_OF_POTASSIUM;
	public static final DeferredBlock<Block> BLOCK_OF_CALCIUM;
	public static final DeferredBlock<Block> LIGHT_SENSOR;
	public static final DeferredBlock<Block> ALUMINUM_DOOR;
	public static final DeferredBlock<Block> BLOCK_OF_SCANDIUM;
	public static final DeferredBlock<Block> ILMENITE_ORE;
	public static final DeferredBlock<Block> DEEPSLATE_ILMENITE_ORE;
	public static final DeferredBlock<Block> BLOCK_OF_TITANIUM;
	public static final DeferredBlock<Block> VANADINITE_ORE;
	public static final DeferredBlock<Block> DEEPSLATE_VANADINITE_ORE;
	public static final DeferredBlock<Block> BLOCK_OF_VANADIUM;
	public static final DeferredBlock<Block> CHROMITE;
	public static final DeferredBlock<Block> BLOCK_OF_CHROMIUM;
	public static final DeferredBlock<Block> BLOCK_OF_OXIDIZED_STEEL;
	public static final DeferredBlock<Block> BLOCK_OF_STAINLESS_STEEL;
	public static final DeferredBlock<Block> PYROLUXITE;
	public static final DeferredBlock<Block> BLOCK_OF_MANGANESE;
	public static final DeferredBlock<Block> COBALTITE_ORE;
	public static final DeferredBlock<Block> DEEPSLATE_COBALTITE_ORE;
	public static final DeferredBlock<Block> BLOCK_OF_COBALT;
	public static final DeferredBlock<Block> PENTLANDITE;
	public static final DeferredBlock<Block> BLOCK_OF_NICKEL;
	public static final DeferredBlock<Block> SPHALERITE_ORE;
	public static final DeferredBlock<Block> DEEPSLATE_SPHALERITE_ORE;
	public static final DeferredBlock<Block> BLOCK_OF_ZINC;
	public static final DeferredBlock<Block> BLOCK_OF_SULFUR;
	public static final DeferredBlock<Block> RED_LED;
	public static final DeferredBlock<Block> GREEN_LED;
	public static final DeferredBlock<Block> BLUE_LED;
	public static final DeferredBlock<Block> WHITE_LED;
	public static final DeferredBlock<Block> BLOCK_OF_GALLIUM;
	public static final DeferredBlock<Block> BLOCK_OF_GERMANIUM;
	public static final DeferredBlock<Block> ARSENOPYRITE_ORE;
	public static final DeferredBlock<Block> DEEPSLATE_ARSENOPYRITE_ORE;
	public static final DeferredBlock<Block> BLOCK_OF_ARSENIC;
	static {
		SPONDUMENE_ORE = register("spondumene_ore", SpondumeneOreBlock::new);
		DEEPSLATE_SPONDUMENE_ORE = register("deepslate_spondumene_ore", DeepslateSpondumeneOreBlock::new);
		ELECTROLYSIS_MACHINE = register("electrolysis_machine", ElectrolysisMachineBlock::new);
		AQUAMARINE_ORE = register("aquamarine_ore", AquamarineOreBlock::new);
		DEEPSLATE_AQUAMARINE_ORE = register("deepslate_aquamarine_ore", DeepslateAquamarineOreBlock::new);
		BLOCK_OF_LITHIUM = register("block_of_lithium", BlockOfLithiumBlock::new);
		BLOCK_OF_BERYLLIUM = register("block_of_beryllium", BlockOfBerylliumBlock::new);
		BORAX_ORE = register("borax_ore", BoraxOreBlock::new);
		DEEPSLATE_BORAX_ORE = register("deepslate_borax_ore", DeepslateBoraxOreBlock::new);
		BLOCK_OF_STEEL = register("block_of_steel", BlockOfSteelBlock::new);
		BLOCK_OF_BORON = register("block_of_boron", BlockOfBoronBlock::new);
		BLOCK_OF_CARBON = register("block_of_carbon", BlockOfCarbonBlock::new);
		BLOCK_OF_AQUAMARINE = register("block_of_aquamarine", BlockOfAquamarineBlock::new);
		MISSILE_LAUNCHER = register("missile_launcher", MissileLauncherBlock::new);
		FLUORITE_ORE = register("fluorite_ore", FluoriteOreBlock::new);
		DEEPSLATE_FLUORITE_ORE = register("deepslate_fluorite_ore", DeepslateFluoriteOreBlock::new);
		HELIUM_LIGHT_STICK = register("helium_light_stick", HeliumLightStickBlock::new);
		NEON_LIGHT_STICK = register("neon_light_stick", NeonLightStickBlock::new);
		ARGON_LIGHT_STICK = register("argon_light_stick", ArgonLightStickBlock::new);
		KRYPTON_LIGHT_STICK = register("krypton_light_stick", KryptonLightStickBlock::new);
		XENON_LIGHT_STICK = register("xenon_light_stick", XenonLightStickBlock::new);
		RADON_LIGHT_STICK = register("radon_light_stick", RadonLightStickBlock::new);
		SALT_CRYSTAL_ORE = register("salt_crystal_ore", SaltCrystalOreBlock::new);
		DEEPSLATE_SALT_CRYSTAL_ORE = register("deepslate_salt_crystal_ore", DeepslateSaltCrystalOreBlock::new);
		BLOCK_OF_SODIUM = register("block_of_sodium", BlockOfSodiumBlock::new);
		CRYOLITE_ORE = register("cryolite_ore", CryoliteOreBlock::new);
		DEEPSLATE_CRYOLITE_ORE = register("deepslate_cryolite_ore", DeepslateCryoliteOreBlock::new);
		BAUXITE = register("bauxite", BauxiteBlock::new);
		BLOCK_OF_MAGNESSIUM = register("block_of_magnessium", BlockOfMagnessiumBlock::new);
		BLOCK_OF_ALUMINUM = register("block_of_aluminum", BlockOfAluminumBlock::new);
		BLOCK_OF_SILICON = register("block_of_silicon", BlockOfSiliconBlock::new);
		WEATHER_SENSOR = register("weather_sensor", WeatherSensorBlock::new);
		APATITE_ORE = register("apatite_ore", ApatiteOreBlock::new);
		DEEPSLATE_APATITE_ORE = register("deepslate_apatite_ore", DeepslateApatiteOreBlock::new);
		BLOCK_OF_APATITE = register("block_of_apatite", BlockOfApatiteBlock::new);
		BLOCK_OF_PHOSPHORUS = register("block_of_phosphorus", BlockOfPhosphorusBlock::new);
		SULFUR_ORE = register("sulfur_ore", SulfurOreBlock::new);
		DEEPSLATE_SULFUR_ORE = register("deepslate_sulfur_ore", DeepslateSulfurOreBlock::new);
		SILVITE_ORE = register("silvite_ore", SilviteOreBlock::new);
		DEEPSLATE_SILVITE_ORE = register("deepslate_silvite_ore", DeepslateSilviteOreBlock::new);
		BLOCK_OF_POTASSIUM = register("block_of_potassium", BlockOfPotassiumBlock::new);
		BLOCK_OF_CALCIUM = register("block_of_calcium", BlockOfCalciumBlock::new);
		LIGHT_SENSOR = register("light_sensor", LightSensorBlock::new);
		ALUMINUM_DOOR = register("aluminum_door", AluminumDoorBlock::new);
		BLOCK_OF_SCANDIUM = register("block_of_scandium", BlockOfScandiumBlock::new);
		ILMENITE_ORE = register("ilmenite_ore", IlmeniteOreBlock::new);
		DEEPSLATE_ILMENITE_ORE = register("deepslate_ilmenite_ore", DeepslateIlmeniteOreBlock::new);
		BLOCK_OF_TITANIUM = register("block_of_titanium", BlockOfTitaniumBlock::new);
		VANADINITE_ORE = register("vanadinite_ore", VanadiniteOreBlock::new);
		DEEPSLATE_VANADINITE_ORE = register("deepslate_vanadinite_ore", DeepslateVanadiniteOreBlock::new);
		BLOCK_OF_VANADIUM = register("block_of_vanadium", BlockOfVanadiumBlock::new);
		CHROMITE = register("chromite", ChromiteBlock::new);
		BLOCK_OF_CHROMIUM = register("block_of_chromium", BlockOfChromiumBlock::new);
		BLOCK_OF_OXIDIZED_STEEL = register("block_of_oxidized_steel", BlockOfOxidizedSteelBlock::new);
		BLOCK_OF_STAINLESS_STEEL = register("block_of_stainless_steel", BlockOfStainlessSteelBlock::new);
		PYROLUXITE = register("pyroluxite", PyroluxiteBlock::new);
		BLOCK_OF_MANGANESE = register("block_of_manganese", BlockOfManganeseBlock::new);
		COBALTITE_ORE = register("cobaltite_ore", CobaltiteOreBlock::new);
		DEEPSLATE_COBALTITE_ORE = register("deepslate_cobaltite_ore", DeepslateCobaltiteOreBlock::new);
		BLOCK_OF_COBALT = register("block_of_cobalt", BlockOfCobaltBlock::new);
		PENTLANDITE = register("pentlandite", PentlanditeBlock::new);
		BLOCK_OF_NICKEL = register("block_of_nickel", BlockOfNickelBlock::new);
		SPHALERITE_ORE = register("sphalerite_ore", SphaleriteOreBlock::new);
		DEEPSLATE_SPHALERITE_ORE = register("deepslate_sphalerite_ore", DeepslateSphaleriteOreBlock::new);
		BLOCK_OF_ZINC = register("block_of_zinc", BlockOfZincBlock::new);
		BLOCK_OF_SULFUR = register("block_of_sulfur", BlockOfSulfurBlock::new);
		RED_LED = register("red_led", RedLEDBlock::new);
		GREEN_LED = register("green_led", GreenLEDBlock::new);
		BLUE_LED = register("blue_led", BlueLEDBlock::new);
		WHITE_LED = register("white_led", WhiteLEDBlock::new);
		BLOCK_OF_GALLIUM = register("block_of_gallium", BlockOfGalliumBlock::new);
		BLOCK_OF_GERMANIUM = register("block_of_germanium", BlockOfGermaniumBlock::new);
		ARSENOPYRITE_ORE = register("arsenopyrite_ore", ArsenopyriteOreBlock::new);
		DEEPSLATE_ARSENOPYRITE_ORE = register("deepslate_arsenopyrite_ore", DeepslateArsenopyriteOreBlock::new);
		BLOCK_OF_ARSENIC = register("block_of_arsenic", BlockOfArsenicBlock::new);
	}

	// Start of user code block custom blocks
	// End of user code block custom blocks
	private static <B extends Block> DeferredBlock<B> register(String name, Function<BlockBehaviour.Properties, ? extends B> supplier) {
		return REGISTRY.registerBlock(name, supplier);
	}

	@EventBusSubscriber(Dist.CLIENT)
	public static class BlocksClientSideHandler {
		@SubscribeEvent
		public static void blockColorLoad(RegisterColorHandlersEvent.BlockTintSources event) {
			ElectrolysisMachineBlock.blockColorLoad(event);
		}
	}
}