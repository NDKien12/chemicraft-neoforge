/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.ndkien.chemicraft.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredHolder;

import net.ndkien.chemicraft.ChemicraftMod;

import net.minecraft.core.registries.Registries;
import net.minecraft.core.particles.SimpleParticleType;
import net.minecraft.core.particles.ParticleType;

public class ChemicraftModParticleTypes {
	public static final DeferredRegister<ParticleType<?>> REGISTRY = DeferredRegister.create(Registries.PARTICLE_TYPE, ChemicraftMod.MODID);
	public static final DeferredHolder<ParticleType<?>, SimpleParticleType> ONE = REGISTRY.register("one", () -> new SimpleParticleType(true));
	public static final DeferredHolder<ParticleType<?>, SimpleParticleType> TWO = REGISTRY.register("two", () -> new SimpleParticleType(true));
	public static final DeferredHolder<ParticleType<?>, SimpleParticleType> THREE = REGISTRY.register("three", () -> new SimpleParticleType(true));
	public static final DeferredHolder<ParticleType<?>, SimpleParticleType> FOUR = REGISTRY.register("four", () -> new SimpleParticleType(true));
}