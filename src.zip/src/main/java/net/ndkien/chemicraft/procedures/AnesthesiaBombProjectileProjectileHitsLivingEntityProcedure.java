package net.ndkien.chemicraft.procedures;

import net.ndkien.chemicraft.init.ChemicraftModMobEffects;

import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.effect.MobEffectInstance;

public class AnesthesiaBombProjectileProjectileHitsLivingEntityProcedure {
	public static void execute(Entity entity) {
		if (entity == null)
			return;
		if (entity instanceof LivingEntity _entity && !_entity.level().isClientSide())
			_entity.addEffect(new MobEffectInstance(ChemicraftModMobEffects.ANESTHESIA, 12000, 1));
	}
}