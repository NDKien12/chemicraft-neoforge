package net.ndkien.chemicraft.procedures;

import net.ndkien.chemicraft.init.ChemicraftModBlocks;
import net.ndkien.chemicraft.ChemicraftMod;

import net.minecraft.world.level.block.state.properties.Property;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.util.RandomSource;
import net.minecraft.util.Mth;
import net.minecraft.core.BlockPos;

public class BlockOfSteelBlockAddedProcedure {
	public static void execute(LevelAccessor world, double x, double y, double z) {
		ChemicraftMod.queueServerWork(Mth.nextInt(RandomSource.create(), 100, 20000), () -> {
			{
				BlockPos _bp = BlockPos.containing(x, y, z);
				BlockState _bs = ChemicraftModBlocks.BLOCK_OF_OXIDIZED_STEEL.get().defaultBlockState();
				BlockState _bso = world.getBlockState(_bp);
				for (Property<?> _propertyOld : _bso.getProperties()) {
					Property _propertyNew = _bs.getBlock().getStateDefinition().getProperty(_propertyOld.getName());
					if (_propertyNew != null && _bs.getValue(_propertyNew) != null)
						try {
							_bs = _bs.setValue(_propertyNew, _bso.getValue(_propertyOld));
						} catch (Exception e) {
						}
				}
				world.setBlock(_bp, _bs, 3);
			}
		});
	}
}