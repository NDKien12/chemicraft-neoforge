package net.ndkien.chemicraft.procedures;

import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.Level;

public class WeatherSensorEmittedRedstonePowerProcedure {
	public static double execute(LevelAccessor world) {
		double power = 0;
		if (world instanceof Level _lvl0 && _lvl0.isRaining()) {
			power = 7;
		} else {
			if (world instanceof Level _lvl1 && _lvl1.isThundering()) {
				power = 15;
			} else {
				power = 0;
			}
		}
		return power;
	}
}