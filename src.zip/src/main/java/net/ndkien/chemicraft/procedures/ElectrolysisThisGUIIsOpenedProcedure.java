package net.ndkien.chemicraft.procedures;

import net.neoforged.neoforge.transfer.item.ItemUtil;
import net.neoforged.neoforge.transfer.item.ItemResource;
import net.neoforged.neoforge.transfer.ResourceHandler;
import net.neoforged.neoforge.common.extensions.ILevelExtension;
import net.neoforged.neoforge.capabilities.Capabilities;

import net.ndkien.chemicraft.init.ChemicraftModItems;
import net.ndkien.chemicraft.init.ChemicraftModBlocks;

import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.entity.ExperienceOrb;
import net.minecraft.world.Container;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.core.BlockPos;

public class ElectrolysisThisGUIIsOpenedProcedure {
	public static void execute(LevelAccessor world, double x, double y, double z) {
		if (itemFromBlockInventory(world, BlockPos.containing(x, y, z), 3).getCount() < 64 && itemFromBlockInventory(world, BlockPos.containing(x, y, z), 4).getCount() < 16
				&& (itemFromBlockInventory(world, BlockPos.containing(x, y, z), 1).copy()).getItem() == ChemicraftModItems.BERYLLIUM_OXIDE.get()
				&& (itemFromBlockInventory(world, BlockPos.containing(x, y, z), 3).getCount() <= 63 && (itemFromBlockInventory(world, BlockPos.containing(x, y, z), 3).copy()).getItem() == ChemicraftModItems.BERYLLIUM_INGOT.get()
						|| itemFromBlockInventory(world, BlockPos.containing(x, y, z), 4).getCount() <= 15 && (itemFromBlockInventory(world, BlockPos.containing(x, y, z), 4).copy()).getItem() == ChemicraftModItems.OXYGEN_BOTTLE.get()
						|| (itemFromBlockInventory(world, BlockPos.containing(x, y, z), 3).copy()).getItem() == Blocks.AIR.asItem() && (itemFromBlockInventory(world, BlockPos.containing(x, y, z), 4).copy()).getItem() == Blocks.AIR.asItem())) {
			if (world instanceof ServerLevel _level)
				_level.addFreshEntity(new ExperienceOrb(_level, x, y, z, 2));
			if (world instanceof ServerLevel _serverLevel) {
				BlockEntity _be = _serverLevel.getBlockEntity(BlockPos.containing(x, y, z));
				if (_be instanceof Container _container) {
					_container.getItem(1).shrink(1);
				}
			}
			if (world instanceof ServerLevel _serverLevel) {
				BlockEntity _be = _serverLevel.getBlockEntity(BlockPos.containing(x, y, z));
				if (_be instanceof Container _container) {
					ItemStack _setstack = new ItemStack(ChemicraftModItems.BERYLLIUM_INGOT.get()).copy();
					_setstack.setCount(itemFromBlockInventory(world, BlockPos.containing(x, y, z), 3).getCount() + 1);
					_container.setItem(3, _setstack);
				}
			}
			if (world instanceof ServerLevel _serverLevel) {
				BlockEntity _be = _serverLevel.getBlockEntity(BlockPos.containing(x, y, z));
				if (_be instanceof Container _container) {
					ItemStack _setstack = new ItemStack(ChemicraftModItems.OXYGEN_BOTTLE.get()).copy();
					_setstack.setCount(itemFromBlockInventory(world, BlockPos.containing(x, y, z), 4).getCount() + 1);
					_container.setItem(4, _setstack);
				}
			}
		}
		if (itemFromBlockInventory(world, BlockPos.containing(x, y, z), 3).getCount() < 15 && itemFromBlockInventory(world, BlockPos.containing(x, y, z), 4).getCount() < 16
				&& (itemFromBlockInventory(world, BlockPos.containing(x, y, z), 1).copy()).getItem() == Items.POTION
				&& (itemFromBlockInventory(world, BlockPos.containing(x, y, z), 3).getCount() <= 14 && (itemFromBlockInventory(world, BlockPos.containing(x, y, z), 3).copy()).getItem() == ChemicraftModItems.HYDROGEN_BOTTLE.get()
						|| itemFromBlockInventory(world, BlockPos.containing(x, y, z), 4).getCount() <= 15 && (itemFromBlockInventory(world, BlockPos.containing(x, y, z), 4).copy()).getItem() == ChemicraftModItems.OXYGEN_BOTTLE.get()
						|| (itemFromBlockInventory(world, BlockPos.containing(x, y, z), 3).copy()).getItem() == Blocks.AIR.asItem() && (itemFromBlockInventory(world, BlockPos.containing(x, y, z), 4).copy()).getItem() == Blocks.AIR.asItem())) {
			if (world instanceof ServerLevel _level)
				_level.addFreshEntity(new ExperienceOrb(_level, x, y, z, 2));
			if (world instanceof ServerLevel _serverLevel) {
				BlockEntity _be = _serverLevel.getBlockEntity(BlockPos.containing(x, y, z));
				if (_be instanceof Container _container) {
					_container.getItem(1).shrink(1);
				}
			}
			if (world instanceof ServerLevel _serverLevel) {
				BlockEntity _be = _serverLevel.getBlockEntity(BlockPos.containing(x, y, z));
				if (_be instanceof Container _container) {
					ItemStack _setstack = new ItemStack(ChemicraftModItems.HYDROGEN_BOTTLE.get()).copy();
					_setstack.setCount(itemFromBlockInventory(world, BlockPos.containing(x, y, z), 3).getCount() + 2);
					_container.setItem(3, _setstack);
				}
			}
			if (world instanceof ServerLevel _serverLevel) {
				BlockEntity _be = _serverLevel.getBlockEntity(BlockPos.containing(x, y, z));
				if (_be instanceof Container _container) {
					ItemStack _setstack = new ItemStack(ChemicraftModItems.OXYGEN_BOTTLE.get()).copy();
					_setstack.setCount(itemFromBlockInventory(world, BlockPos.containing(x, y, z), 4).getCount() + 1);
					_container.setItem(4, _setstack);
				}
			}
		}
		if (itemFromBlockInventory(world, BlockPos.containing(x, y, z), 3).getCount() < 64 && itemFromBlockInventory(world, BlockPos.containing(x, y, z), 4).getCount() < 16
				&& (itemFromBlockInventory(world, BlockPos.containing(x, y, z), 1).copy()).getItem() == ChemicraftModItems.FLUORITE.get()
				&& (itemFromBlockInventory(world, BlockPos.containing(x, y, z), 3).getCount() <= 63 && (itemFromBlockInventory(world, BlockPos.containing(x, y, z), 3).copy()).getItem() == ChemicraftModItems.CALCIUM.get()
						|| itemFromBlockInventory(world, BlockPos.containing(x, y, z), 4).getCount() <= 15 && (itemFromBlockInventory(world, BlockPos.containing(x, y, z), 4).copy()).getItem() == ChemicraftModItems.FLUORINE_BOTTLE.get()
						|| (itemFromBlockInventory(world, BlockPos.containing(x, y, z), 3).copy()).getItem() == Blocks.AIR.asItem() && (itemFromBlockInventory(world, BlockPos.containing(x, y, z), 4).copy()).getItem() == Blocks.AIR.asItem())) {
			if (world instanceof ServerLevel _level)
				_level.addFreshEntity(new ExperienceOrb(_level, x, y, z, 2));
			if (world instanceof ServerLevel _serverLevel) {
				BlockEntity _be = _serverLevel.getBlockEntity(BlockPos.containing(x, y, z));
				if (_be instanceof Container _container) {
					_container.getItem(1).shrink(1);
				}
			}
			if (world instanceof ServerLevel _serverLevel) {
				BlockEntity _be = _serverLevel.getBlockEntity(BlockPos.containing(x, y, z));
				if (_be instanceof Container _container) {
					ItemStack _setstack = new ItemStack(ChemicraftModItems.CALCIUM.get()).copy();
					_setstack.setCount(itemFromBlockInventory(world, BlockPos.containing(x, y, z), 3).getCount() + 1);
					_container.setItem(3, _setstack);
				}
			}
			if (world instanceof ServerLevel _serverLevel) {
				BlockEntity _be = _serverLevel.getBlockEntity(BlockPos.containing(x, y, z));
				if (_be instanceof Container _container) {
					ItemStack _setstack = new ItemStack(ChemicraftModItems.FLUORINE_BOTTLE.get()).copy();
					_setstack.setCount(itemFromBlockInventory(world, BlockPos.containing(x, y, z), 4).getCount() + 1);
					_container.setItem(4, _setstack);
				}
			}
		}
		if (itemFromBlockInventory(world, BlockPos.containing(x, y, z), 3).getCount() < 64 && itemFromBlockInventory(world, BlockPos.containing(x, y, z), 4).getCount() < 16
				&& (itemFromBlockInventory(world, BlockPos.containing(x, y, z), 1).copy()).getItem() == ChemicraftModItems.TABLE_SALT.get()
				&& (itemFromBlockInventory(world, BlockPos.containing(x, y, z), 3).getCount() <= 63 && (itemFromBlockInventory(world, BlockPos.containing(x, y, z), 3).copy()).getItem() == ChemicraftModItems.SODIUM_INGOT.get()
						|| itemFromBlockInventory(world, BlockPos.containing(x, y, z), 4).getCount() <= 15 && (itemFromBlockInventory(world, BlockPos.containing(x, y, z), 4).copy()).getItem() == ChemicraftModItems.CHLORINE_BOTTLE.get()
						|| (itemFromBlockInventory(world, BlockPos.containing(x, y, z), 3).copy()).getItem() == Blocks.AIR.asItem() && (itemFromBlockInventory(world, BlockPos.containing(x, y, z), 4).copy()).getItem() == Blocks.AIR.asItem())) {
			if (world instanceof ServerLevel _level)
				_level.addFreshEntity(new ExperienceOrb(_level, x, y, z, 2));
			if (world instanceof ServerLevel _serverLevel) {
				BlockEntity _be = _serverLevel.getBlockEntity(BlockPos.containing(x, y, z));
				if (_be instanceof Container _container) {
					_container.getItem(1).shrink(1);
				}
			}
			if (world instanceof ServerLevel _serverLevel) {
				BlockEntity _be = _serverLevel.getBlockEntity(BlockPos.containing(x, y, z));
				if (_be instanceof Container _container) {
					ItemStack _setstack = new ItemStack(ChemicraftModItems.SODIUM_INGOT.get()).copy();
					_setstack.setCount(itemFromBlockInventory(world, BlockPos.containing(x, y, z), 3).getCount() + 1);
					_container.setItem(3, _setstack);
				}
			}
			if (world instanceof ServerLevel _serverLevel) {
				BlockEntity _be = _serverLevel.getBlockEntity(BlockPos.containing(x, y, z));
				if (_be instanceof Container _container) {
					ItemStack _setstack = new ItemStack(ChemicraftModItems.CHLORINE_BOTTLE.get()).copy();
					_setstack.setCount(itemFromBlockInventory(world, BlockPos.containing(x, y, z), 4).getCount() + 1);
					_container.setItem(4, _setstack);
				}
			}
		}
		if (itemFromBlockInventory(world, BlockPos.containing(x, y, z), 3).getCount() < 64 && itemFromBlockInventory(world, BlockPos.containing(x, y, z), 4).getCount() < 16
				&& (itemFromBlockInventory(world, BlockPos.containing(x, y, z), 1).copy()).getItem() == ChemicraftModItems.HALITE.get()
				&& (itemFromBlockInventory(world, BlockPos.containing(x, y, z), 3).getCount() <= 63 && (itemFromBlockInventory(world, BlockPos.containing(x, y, z), 3).copy()).getItem() == ChemicraftModItems.SODIUM_INGOT.get()
						|| itemFromBlockInventory(world, BlockPos.containing(x, y, z), 4).getCount() <= 15 && (itemFromBlockInventory(world, BlockPos.containing(x, y, z), 4).copy()).getItem() == ChemicraftModItems.CHLORINE_BOTTLE.get()
						|| (itemFromBlockInventory(world, BlockPos.containing(x, y, z), 3).copy()).getItem() == Blocks.AIR.asItem() && (itemFromBlockInventory(world, BlockPos.containing(x, y, z), 4).copy()).getItem() == Blocks.AIR.asItem())) {
			if (world instanceof ServerLevel _level)
				_level.addFreshEntity(new ExperienceOrb(_level, x, y, z, 2));
			if (world instanceof ServerLevel _serverLevel) {
				BlockEntity _be = _serverLevel.getBlockEntity(BlockPos.containing(x, y, z));
				if (_be instanceof Container _container) {
					_container.getItem(1).shrink(1);
				}
			}
			if (world instanceof ServerLevel _serverLevel) {
				BlockEntity _be = _serverLevel.getBlockEntity(BlockPos.containing(x, y, z));
				if (_be instanceof Container _container) {
					ItemStack _setstack = new ItemStack(ChemicraftModItems.SODIUM_INGOT.get()).copy();
					_setstack.setCount(itemFromBlockInventory(world, BlockPos.containing(x, y, z), 3).getCount() + 1);
					_container.setItem(3, _setstack);
				}
			}
			if (world instanceof ServerLevel _serverLevel) {
				BlockEntity _be = _serverLevel.getBlockEntity(BlockPos.containing(x, y, z));
				if (_be instanceof Container _container) {
					ItemStack _setstack = new ItemStack(ChemicraftModItems.CHLORINE_BOTTLE.get()).copy();
					_setstack.setCount(itemFromBlockInventory(world, BlockPos.containing(x, y, z), 4).getCount() + 1);
					_container.setItem(4, _setstack);
				}
			}
		}
		if (itemFromBlockInventory(world, BlockPos.containing(x, y, z), 3).getCount() < 64 && itemFromBlockInventory(world, BlockPos.containing(x, y, z), 4).getCount() < 16
				&& (itemFromBlockInventory(world, BlockPos.containing(x, y, z), 1).copy()).getItem() == ChemicraftModItems.MAGNESSIUM_CHLORIDE.get()
				&& (itemFromBlockInventory(world, BlockPos.containing(x, y, z), 3).getCount() <= 63 && (itemFromBlockInventory(world, BlockPos.containing(x, y, z), 3).copy()).getItem() == ChemicraftModItems.MAGNESIUM_INGOT.get()
						|| itemFromBlockInventory(world, BlockPos.containing(x, y, z), 4).getCount() <= 15 && (itemFromBlockInventory(world, BlockPos.containing(x, y, z), 4).copy()).getItem() == ChemicraftModItems.CHLORINE_BOTTLE.get()
						|| (itemFromBlockInventory(world, BlockPos.containing(x, y, z), 3).copy()).getItem() == Blocks.AIR.asItem() && (itemFromBlockInventory(world, BlockPos.containing(x, y, z), 4).copy()).getItem() == Blocks.AIR.asItem())) {
			if (world instanceof ServerLevel _level)
				_level.addFreshEntity(new ExperienceOrb(_level, x, y, z, 2));
			if (world instanceof ServerLevel _serverLevel) {
				BlockEntity _be = _serverLevel.getBlockEntity(BlockPos.containing(x, y, z));
				if (_be instanceof Container _container) {
					_container.getItem(1).shrink(1);
				}
			}
			if (world instanceof ServerLevel _serverLevel) {
				BlockEntity _be = _serverLevel.getBlockEntity(BlockPos.containing(x, y, z));
				if (_be instanceof Container _container) {
					ItemStack _setstack = new ItemStack(ChemicraftModItems.MAGNESIUM_INGOT.get()).copy();
					_setstack.setCount(itemFromBlockInventory(world, BlockPos.containing(x, y, z), 3).getCount() + 1);
					_container.setItem(3, _setstack);
				}
			}
			if (world instanceof ServerLevel _serverLevel) {
				BlockEntity _be = _serverLevel.getBlockEntity(BlockPos.containing(x, y, z));
				if (_be instanceof Container _container) {
					ItemStack _setstack = new ItemStack(ChemicraftModItems.CHLORINE_BOTTLE.get()).copy();
					_setstack.setCount(itemFromBlockInventory(world, BlockPos.containing(x, y, z), 4).getCount() + 1);
					_container.setItem(4, _setstack);
				}
			}
		}
		if (itemFromBlockInventory(world, BlockPos.containing(x, y, z), 3).getCount() < 64 && itemFromBlockInventory(world, BlockPos.containing(x, y, z), 4).getCount() < 16
				&& (itemFromBlockInventory(world, BlockPos.containing(x, y, z), 1).copy()).getItem() == ChemicraftModItems.ALUMINA.get()
				&& (itemFromBlockInventory(world, BlockPos.containing(x, y, z), 2).copy()).getItem() == ChemicraftModItems.CRYOLITE.get()
				&& (itemFromBlockInventory(world, BlockPos.containing(x, y, z), 3).getCount() <= 63 && (itemFromBlockInventory(world, BlockPos.containing(x, y, z), 3).copy()).getItem() == ChemicraftModItems.ALUMINUM_INGOT.get()
						|| itemFromBlockInventory(world, BlockPos.containing(x, y, z), 4).getCount() <= 15 && (itemFromBlockInventory(world, BlockPos.containing(x, y, z), 4).copy()).getItem() == ChemicraftModItems.OXYGEN_BOTTLE.get()
						|| (itemFromBlockInventory(world, BlockPos.containing(x, y, z), 3).copy()).getItem() == Blocks.AIR.asItem() && (itemFromBlockInventory(world, BlockPos.containing(x, y, z), 4).copy()).getItem() == Blocks.AIR.asItem())) {
			if (world instanceof ServerLevel _level)
				_level.addFreshEntity(new ExperienceOrb(_level, x, y, z, 2));
			if (world instanceof ServerLevel _serverLevel) {
				BlockEntity _be = _serverLevel.getBlockEntity(BlockPos.containing(x, y, z));
				if (_be instanceof Container _container) {
					_container.getItem(1).shrink(1);
				}
			}
			if (world instanceof ServerLevel _serverLevel) {
				BlockEntity _be = _serverLevel.getBlockEntity(BlockPos.containing(x, y, z));
				if (_be instanceof Container _container) {
					_container.getItem(2).shrink(1);
				}
			}
			if (world instanceof ServerLevel _serverLevel) {
				BlockEntity _be = _serverLevel.getBlockEntity(BlockPos.containing(x, y, z));
				if (_be instanceof Container _container) {
					ItemStack _setstack = new ItemStack(ChemicraftModItems.ALUMINUM_INGOT.get()).copy();
					_setstack.setCount(itemFromBlockInventory(world, BlockPos.containing(x, y, z), 3).getCount() + 1);
					_container.setItem(3, _setstack);
				}
			}
			if (world instanceof ServerLevel _serverLevel) {
				BlockEntity _be = _serverLevel.getBlockEntity(BlockPos.containing(x, y, z));
				if (_be instanceof Container _container) {
					ItemStack _setstack = new ItemStack(ChemicraftModItems.OXYGEN_BOTTLE.get()).copy();
					_setstack.setCount(itemFromBlockInventory(world, BlockPos.containing(x, y, z), 4).getCount() + 1);
					_container.setItem(4, _setstack);
				}
			}
		}
		if (itemFromBlockInventory(world, BlockPos.containing(x, y, z), 3).getCount() < 64 && itemFromBlockInventory(world, BlockPos.containing(x, y, z), 4).getCount() < 64
				&& (itemFromBlockInventory(world, BlockPos.containing(x, y, z), 1).copy()).getItem() == ChemicraftModItems.APATITE.get()
				&& (itemFromBlockInventory(world, BlockPos.containing(x, y, z), 3).getCount() <= 63 && (itemFromBlockInventory(world, BlockPos.containing(x, y, z), 3).copy()).getItem() == ChemicraftModItems.FLUORITE.get()
						|| itemFromBlockInventory(world, BlockPos.containing(x, y, z), 4).getCount() <= 63 && (itemFromBlockInventory(world, BlockPos.containing(x, y, z), 4).copy()).getItem() == ChemicraftModItems.PHOSPHORUS_PENTOXIDE.get()
						|| (itemFromBlockInventory(world, BlockPos.containing(x, y, z), 3).copy()).getItem() == Blocks.AIR.asItem() && (itemFromBlockInventory(world, BlockPos.containing(x, y, z), 4).copy()).getItem() == Blocks.AIR.asItem())) {
			if (world instanceof ServerLevel _level)
				_level.addFreshEntity(new ExperienceOrb(_level, x, y, z, 2));
			if (world instanceof ServerLevel _serverLevel) {
				BlockEntity _be = _serverLevel.getBlockEntity(BlockPos.containing(x, y, z));
				if (_be instanceof Container _container) {
					_container.getItem(1).shrink(1);
				}
			}
			if (world instanceof ServerLevel _serverLevel) {
				BlockEntity _be = _serverLevel.getBlockEntity(BlockPos.containing(x, y, z));
				if (_be instanceof Container _container) {
					ItemStack _setstack = new ItemStack(ChemicraftModItems.FLUORITE.get()).copy();
					_setstack.setCount(itemFromBlockInventory(world, BlockPos.containing(x, y, z), 3).getCount() + 1);
					_container.setItem(3, _setstack);
				}
			}
			if (world instanceof ServerLevel _serverLevel) {
				BlockEntity _be = _serverLevel.getBlockEntity(BlockPos.containing(x, y, z));
				if (_be instanceof Container _container) {
					ItemStack _setstack = new ItemStack(ChemicraftModItems.PHOSPHORUS_PENTOXIDE.get()).copy();
					_setstack.setCount(itemFromBlockInventory(world, BlockPos.containing(x, y, z), 4).getCount() + 1);
					_container.setItem(4, _setstack);
				}
			}
		}
		if (itemFromBlockInventory(world, BlockPos.containing(x, y, z), 3).getCount() < 64 && itemFromBlockInventory(world, BlockPos.containing(x, y, z), 4).getCount() < 16
				&& (itemFromBlockInventory(world, BlockPos.containing(x, y, z), 1).copy()).getItem() == ChemicraftModItems.SILVITE.get()
				&& (itemFromBlockInventory(world, BlockPos.containing(x, y, z), 3).getCount() <= 63 && (itemFromBlockInventory(world, BlockPos.containing(x, y, z), 3).copy()).getItem() == ChemicraftModItems.POTASSIUM_INGOT.get()
						|| itemFromBlockInventory(world, BlockPos.containing(x, y, z), 4).getCount() <= 15 && (itemFromBlockInventory(world, BlockPos.containing(x, y, z), 4).copy()).getItem() == ChemicraftModItems.CHLORINE_BOTTLE.get()
						|| (itemFromBlockInventory(world, BlockPos.containing(x, y, z), 3).copy()).getItem() == Blocks.AIR.asItem() && (itemFromBlockInventory(world, BlockPos.containing(x, y, z), 4).copy()).getItem() == Blocks.AIR.asItem())) {
			if (world instanceof ServerLevel _level)
				_level.addFreshEntity(new ExperienceOrb(_level, x, y, z, 2));
			if (world instanceof ServerLevel _serverLevel) {
				BlockEntity _be = _serverLevel.getBlockEntity(BlockPos.containing(x, y, z));
				if (_be instanceof Container _container) {
					_container.getItem(1).shrink(1);
				}
			}
			if (world instanceof ServerLevel _serverLevel) {
				BlockEntity _be = _serverLevel.getBlockEntity(BlockPos.containing(x, y, z));
				if (_be instanceof Container _container) {
					ItemStack _setstack = new ItemStack(ChemicraftModItems.POTASSIUM_INGOT.get()).copy();
					_setstack.setCount(itemFromBlockInventory(world, BlockPos.containing(x, y, z), 3).getCount() + 1);
					_container.setItem(3, _setstack);
				}
			}
			if (world instanceof ServerLevel _serverLevel) {
				BlockEntity _be = _serverLevel.getBlockEntity(BlockPos.containing(x, y, z));
				if (_be instanceof Container _container) {
					ItemStack _setstack = new ItemStack(ChemicraftModItems.CHLORINE_BOTTLE.get()).copy();
					_setstack.setCount(itemFromBlockInventory(world, BlockPos.containing(x, y, z), 4).getCount() + 1);
					_container.setItem(4, _setstack);
				}
			}
		}
		if (itemFromBlockInventory(world, BlockPos.containing(x, y, z), 3).getCount() < 64 && itemFromBlockInventory(world, BlockPos.containing(x, y, z), 4).getCount() < 16
				&& (itemFromBlockInventory(world, BlockPos.containing(x, y, z), 1).copy()).getItem() == ChemicraftModItems.CHALK.get()
				&& (itemFromBlockInventory(world, BlockPos.containing(x, y, z), 3).getCount() <= 63 && (itemFromBlockInventory(world, BlockPos.containing(x, y, z), 3).copy()).getItem() == ChemicraftModItems.CALCIUM.get()
						|| itemFromBlockInventory(world, BlockPos.containing(x, y, z), 4).getCount() <= 15 && (itemFromBlockInventory(world, BlockPos.containing(x, y, z), 4).copy()).getItem() == ChemicraftModItems.CARBON_DIOXIDE.get()
						|| (itemFromBlockInventory(world, BlockPos.containing(x, y, z), 3).copy()).getItem() == Blocks.AIR.asItem() && (itemFromBlockInventory(world, BlockPos.containing(x, y, z), 4).copy()).getItem() == Blocks.AIR.asItem())) {
			if (world instanceof ServerLevel _level)
				_level.addFreshEntity(new ExperienceOrb(_level, x, y, z, 2));
			if (world instanceof ServerLevel _serverLevel) {
				BlockEntity _be = _serverLevel.getBlockEntity(BlockPos.containing(x, y, z));
				if (_be instanceof Container _container) {
					_container.getItem(1).shrink(1);
				}
			}
			if (world instanceof ServerLevel _serverLevel) {
				BlockEntity _be = _serverLevel.getBlockEntity(BlockPos.containing(x, y, z));
				if (_be instanceof Container _container) {
					ItemStack _setstack = new ItemStack(ChemicraftModItems.CALCIUM.get()).copy();
					_setstack.setCount(itemFromBlockInventory(world, BlockPos.containing(x, y, z), 3).getCount() + 1);
					_container.setItem(3, _setstack);
				}
			}
			if (world instanceof ServerLevel _serverLevel) {
				BlockEntity _be = _serverLevel.getBlockEntity(BlockPos.containing(x, y, z));
				if (_be instanceof Container _container) {
					ItemStack _setstack = new ItemStack(ChemicraftModItems.CARBON_DIOXIDE.get()).copy();
					_setstack.setCount(itemFromBlockInventory(world, BlockPos.containing(x, y, z), 4).getCount() + 1);
					_container.setItem(4, _setstack);
				}
			}
		}
		if (itemFromBlockInventory(world, BlockPos.containing(x, y, z), 3).getCount() < 64 && itemFromBlockInventory(world, BlockPos.containing(x, y, z), 4).getCount() < 64
				&& (itemFromBlockInventory(world, BlockPos.containing(x, y, z), 1).copy()).getItem() == ChemicraftModItems.SODIUM_VANADATE.get()
				&& (itemFromBlockInventory(world, BlockPos.containing(x, y, z), 3).getCount() <= 63 && (itemFromBlockInventory(world, BlockPos.containing(x, y, z), 3).copy()).getItem() == ChemicraftModItems.SODIUM_INGOT.get()
						|| itemFromBlockInventory(world, BlockPos.containing(x, y, z), 4).getCount() <= 63 && (itemFromBlockInventory(world, BlockPos.containing(x, y, z), 4).copy()).getItem() == ChemicraftModItems.VANADIUM_PENTOXIDE.get()
						|| (itemFromBlockInventory(world, BlockPos.containing(x, y, z), 3).copy()).getItem() == Blocks.AIR.asItem() && (itemFromBlockInventory(world, BlockPos.containing(x, y, z), 4).copy()).getItem() == Blocks.AIR.asItem())) {
			if (world instanceof ServerLevel _level)
				_level.addFreshEntity(new ExperienceOrb(_level, x, y, z, 2));
			if (world instanceof ServerLevel _serverLevel) {
				BlockEntity _be = _serverLevel.getBlockEntity(BlockPos.containing(x, y, z));
				if (_be instanceof Container _container) {
					_container.getItem(1).shrink(1);
				}
			}
			if (world instanceof ServerLevel _serverLevel) {
				BlockEntity _be = _serverLevel.getBlockEntity(BlockPos.containing(x, y, z));
				if (_be instanceof Container _container) {
					ItemStack _setstack = new ItemStack(ChemicraftModItems.SODIUM_INGOT.get()).copy();
					_setstack.setCount(itemFromBlockInventory(world, BlockPos.containing(x, y, z), 3).getCount() + 1);
					_container.setItem(3, _setstack);
				}
			}
			if (world instanceof ServerLevel _serverLevel) {
				BlockEntity _be = _serverLevel.getBlockEntity(BlockPos.containing(x, y, z));
				if (_be instanceof Container _container) {
					ItemStack _setstack = new ItemStack(ChemicraftModItems.VANADIUM_PENTOXIDE.get()).copy();
					_setstack.setCount(itemFromBlockInventory(world, BlockPos.containing(x, y, z), 4).getCount() + 1);
					_container.setItem(4, _setstack);
				}
			}
		}
		if (itemFromBlockInventory(world, BlockPos.containing(x, y, z), 3).getCount() < 55 && itemFromBlockInventory(world, BlockPos.containing(x, y, z), 4).getCount() < 7
				&& (itemFromBlockInventory(world, BlockPos.containing(x, y, z), 1).copy()).getItem() == ChemicraftModBlocks.PYROLUXITE.get().asItem()
				&& (itemFromBlockInventory(world, BlockPos.containing(x, y, z), 3).getCount() <= 54 && (itemFromBlockInventory(world, BlockPos.containing(x, y, z), 3).copy()).getItem() == ChemicraftModItems.MANGANESE_INGOT.get()
						|| itemFromBlockInventory(world, BlockPos.containing(x, y, z), 4).getCount() <= 6 && (itemFromBlockInventory(world, BlockPos.containing(x, y, z), 4).copy()).getItem() == ChemicraftModItems.OXYGEN_BOTTLE.get()
						|| (itemFromBlockInventory(world, BlockPos.containing(x, y, z), 3).copy()).getItem() == Blocks.AIR.asItem() && (itemFromBlockInventory(world, BlockPos.containing(x, y, z), 4).copy()).getItem() == Blocks.AIR.asItem())) {
			if (world instanceof ServerLevel _level)
				_level.addFreshEntity(new ExperienceOrb(_level, x, y, z, 2));
			if (world instanceof ServerLevel _serverLevel) {
				BlockEntity _be = _serverLevel.getBlockEntity(BlockPos.containing(x, y, z));
				if (_be instanceof Container _container) {
					_container.getItem(1).shrink(1);
				}
			}
			if (world instanceof ServerLevel _serverLevel) {
				BlockEntity _be = _serverLevel.getBlockEntity(BlockPos.containing(x, y, z));
				if (_be instanceof Container _container) {
					ItemStack _setstack = new ItemStack(ChemicraftModItems.MANGANESE_INGOT.get()).copy();
					_setstack.setCount(itemFromBlockInventory(world, BlockPos.containing(x, y, z), 3).getCount() + 1);
					_container.setItem(3, _setstack);
				}
			}
			if (world instanceof ServerLevel _serverLevel) {
				BlockEntity _be = _serverLevel.getBlockEntity(BlockPos.containing(x, y, z));
				if (_be instanceof Container _container) {
					ItemStack _setstack = new ItemStack(ChemicraftModItems.OXYGEN_BOTTLE.get()).copy();
					_setstack.setCount(itemFromBlockInventory(world, BlockPos.containing(x, y, z), 4).getCount() + 1);
					_container.setItem(4, _setstack);
				}
			}
		}
		if (itemFromBlockInventory(world, BlockPos.containing(x, y, z), 3).getCount() < 55 && itemFromBlockInventory(world, BlockPos.containing(x, y, z), 4).getCount() < 55
				&& (itemFromBlockInventory(world, BlockPos.containing(x, y, z), 1).copy()).getItem() == ChemicraftModBlocks.PENTLANDITE.get().asItem()
				&& (itemFromBlockInventory(world, BlockPos.containing(x, y, z), 3).getCount() <= 54 && (itemFromBlockInventory(world, BlockPos.containing(x, y, z), 3).copy()).getItem() == ChemicraftModItems.NICKEL_INGOT.get()
						|| itemFromBlockInventory(world, BlockPos.containing(x, y, z), 4).getCount() <= 54 && (itemFromBlockInventory(world, BlockPos.containing(x, y, z), 4).copy()).getItem() == ChemicraftModItems.SULFUR_POWDER.get()
						|| (itemFromBlockInventory(world, BlockPos.containing(x, y, z), 3).copy()).getItem() == Blocks.AIR.asItem() && (itemFromBlockInventory(world, BlockPos.containing(x, y, z), 4).copy()).getItem() == Blocks.AIR.asItem())) {
			if (world instanceof ServerLevel _level)
				_level.addFreshEntity(new ExperienceOrb(_level, x, y, z, 2));
			if (world instanceof ServerLevel _serverLevel) {
				BlockEntity _be = _serverLevel.getBlockEntity(BlockPos.containing(x, y, z));
				if (_be instanceof Container _container) {
					_container.getItem(1).shrink(1);
				}
			}
			if (world instanceof ServerLevel _serverLevel) {
				BlockEntity _be = _serverLevel.getBlockEntity(BlockPos.containing(x, y, z));
				if (_be instanceof Container _container) {
					ItemStack _setstack = new ItemStack(ChemicraftModItems.NICKEL_INGOT.get()).copy();
					_setstack.setCount(itemFromBlockInventory(world, BlockPos.containing(x, y, z), 3).getCount() + 1);
					_container.setItem(3, _setstack);
				}
			}
			if (world instanceof ServerLevel _serverLevel) {
				BlockEntity _be = _serverLevel.getBlockEntity(BlockPos.containing(x, y, z));
				if (_be instanceof Container _container) {
					ItemStack _setstack = new ItemStack(ChemicraftModItems.SULFUR_POWDER.get()).copy();
					_setstack.setCount(itemFromBlockInventory(world, BlockPos.containing(x, y, z), 4).getCount() + 1);
					_container.setItem(4, _setstack);
				}
			}
		}
		if (itemFromBlockInventory(world, BlockPos.containing(x, y, z), 3).getCount() < 64 && itemFromBlockInventory(world, BlockPos.containing(x, y, z), 4).getCount() < 64
				&& (itemFromBlockInventory(world, BlockPos.containing(x, y, z), 1).copy()).getItem() == ChemicraftModItems.SPHALERITE.get()
				&& (itemFromBlockInventory(world, BlockPos.containing(x, y, z), 3).getCount() <= 63 && (itemFromBlockInventory(world, BlockPos.containing(x, y, z), 3).copy()).getItem() == ChemicraftModItems.ZINC_INGOT.get()
						|| itemFromBlockInventory(world, BlockPos.containing(x, y, z), 4).getCount() <= 63 && (itemFromBlockInventory(world, BlockPos.containing(x, y, z), 4).copy()).getItem() == ChemicraftModItems.SULFUR_POWDER.get()
						|| (itemFromBlockInventory(world, BlockPos.containing(x, y, z), 3).copy()).getItem() == Blocks.AIR.asItem() && (itemFromBlockInventory(world, BlockPos.containing(x, y, z), 4).copy()).getItem() == Blocks.AIR.asItem())) {
			if (world instanceof ServerLevel _level)
				_level.addFreshEntity(new ExperienceOrb(_level, x, y, z, 2));
			if (world instanceof ServerLevel _serverLevel) {
				BlockEntity _be = _serverLevel.getBlockEntity(BlockPos.containing(x, y, z));
				if (_be instanceof Container _container) {
					_container.getItem(1).shrink(1);
				}
			}
			if (world instanceof ServerLevel _serverLevel) {
				BlockEntity _be = _serverLevel.getBlockEntity(BlockPos.containing(x, y, z));
				if (_be instanceof Container _container) {
					ItemStack _setstack = new ItemStack(ChemicraftModItems.ZINC_INGOT.get()).copy();
					_setstack.setCount(itemFromBlockInventory(world, BlockPos.containing(x, y, z), 3).getCount() + 1);
					_container.setItem(3, _setstack);
				}
			}
			if (world instanceof ServerLevel _serverLevel) {
				BlockEntity _be = _serverLevel.getBlockEntity(BlockPos.containing(x, y, z));
				if (_be instanceof Container _container) {
					ItemStack _setstack = new ItemStack(ChemicraftModItems.SULFUR_POWDER.get()).copy();
					_setstack.setCount(itemFromBlockInventory(world, BlockPos.containing(x, y, z), 4).getCount() + 1);
					_container.setItem(4, _setstack);
				}
			}
		}
		if (itemFromBlockInventory(world, BlockPos.containing(x, y, z), 3).getCount() < 64 && itemFromBlockInventory(world, BlockPos.containing(x, y, z), 4).getCount() < 64
				&& (itemFromBlockInventory(world, BlockPos.containing(x, y, z), 1).copy()).getItem() == ChemicraftModItems.ZINC_OXIDE.get()
				&& (itemFromBlockInventory(world, BlockPos.containing(x, y, z), 3).getCount() <= 63 && (itemFromBlockInventory(world, BlockPos.containing(x, y, z), 3).copy()).getItem() == ChemicraftModItems.ZINC_INGOT.get()
						|| itemFromBlockInventory(world, BlockPos.containing(x, y, z), 4).getCount() <= 63 && (itemFromBlockInventory(world, BlockPos.containing(x, y, z), 4).copy()).getItem() == ChemicraftModItems.OXYGEN_BOTTLE.get()
						|| (itemFromBlockInventory(world, BlockPos.containing(x, y, z), 3).copy()).getItem() == Blocks.AIR.asItem() && (itemFromBlockInventory(world, BlockPos.containing(x, y, z), 4).copy()).getItem() == Blocks.AIR.asItem())) {
			if (world instanceof ServerLevel _level)
				_level.addFreshEntity(new ExperienceOrb(_level, x, y, z, 2));
			if (world instanceof ServerLevel _serverLevel) {
				BlockEntity _be = _serverLevel.getBlockEntity(BlockPos.containing(x, y, z));
				if (_be instanceof Container _container) {
					_container.getItem(1).shrink(1);
				}
			}
			if (world instanceof ServerLevel _serverLevel) {
				BlockEntity _be = _serverLevel.getBlockEntity(BlockPos.containing(x, y, z));
				if (_be instanceof Container _container) {
					ItemStack _setstack = new ItemStack(ChemicraftModItems.ZINC_INGOT.get()).copy();
					_setstack.setCount(itemFromBlockInventory(world, BlockPos.containing(x, y, z), 3).getCount() + 1);
					_container.setItem(3, _setstack);
				}
			}
			if (world instanceof ServerLevel _serverLevel) {
				BlockEntity _be = _serverLevel.getBlockEntity(BlockPos.containing(x, y, z));
				if (_be instanceof Container _container) {
					ItemStack _setstack = new ItemStack(ChemicraftModItems.OXYGEN_BOTTLE.get()).copy();
					_setstack.setCount(itemFromBlockInventory(world, BlockPos.containing(x, y, z), 4).getCount() + 1);
					_container.setItem(4, _setstack);
				}
			}
		}
		if (itemFromBlockInventory(world, BlockPos.containing(x, y, z), 3).getCount() < 64 && itemFromBlockInventory(world, BlockPos.containing(x, y, z), 4).getCount() < 16
				&& (itemFromBlockInventory(world, BlockPos.containing(x, y, z), 1).copy()).getItem() == ChemicraftModItems.SODIUM_BROMIDE.get()
				&& (itemFromBlockInventory(world, BlockPos.containing(x, y, z), 3).getCount() <= 63 && (itemFromBlockInventory(world, BlockPos.containing(x, y, z), 3).copy()).getItem() == ChemicraftModItems.SODIUM_INGOT.get()
						|| itemFromBlockInventory(world, BlockPos.containing(x, y, z), 4).getCount() <= 15 && (itemFromBlockInventory(world, BlockPos.containing(x, y, z), 4).copy()).getItem() == ChemicraftModItems.BROMINE_BOTTLE.get()
						|| (itemFromBlockInventory(world, BlockPos.containing(x, y, z), 3).copy()).getItem() == Blocks.AIR.asItem() && (itemFromBlockInventory(world, BlockPos.containing(x, y, z), 4).copy()).getItem() == Blocks.AIR.asItem())) {
			if (world instanceof ServerLevel _level)
				_level.addFreshEntity(new ExperienceOrb(_level, x, y, z, 2));
			if (world instanceof ServerLevel _serverLevel) {
				BlockEntity _be = _serverLevel.getBlockEntity(BlockPos.containing(x, y, z));
				if (_be instanceof Container _container) {
					_container.getItem(1).shrink(1);
				}
			}
			if (world instanceof ServerLevel _serverLevel) {
				BlockEntity _be = _serverLevel.getBlockEntity(BlockPos.containing(x, y, z));
				if (_be instanceof Container _container) {
					ItemStack _setstack = new ItemStack(ChemicraftModItems.SODIUM_INGOT.get()).copy();
					_setstack.setCount(itemFromBlockInventory(world, BlockPos.containing(x, y, z), 3).getCount() + 1);
					_container.setItem(3, _setstack);
				}
			}
			if (world instanceof ServerLevel _serverLevel) {
				BlockEntity _be = _serverLevel.getBlockEntity(BlockPos.containing(x, y, z));
				if (_be instanceof Container _container) {
					ItemStack _setstack = new ItemStack(ChemicraftModItems.BROMINE_BOTTLE.get()).copy();
					_setstack.setCount(itemFromBlockInventory(world, BlockPos.containing(x, y, z), 4).getCount() + 1);
					_container.setItem(4, _setstack);
				}
			}
		}
		if (itemFromBlockInventory(world, BlockPos.containing(x, y, z), 3).getCount() < 64 && itemFromBlockInventory(world, BlockPos.containing(x, y, z), 4).getCount() < 64
				&& (itemFromBlockInventory(world, BlockPos.containing(x, y, z), 1).copy()).getItem() == ChemicraftModItems.STRONTIUM_SULFIDE.get()
				&& (itemFromBlockInventory(world, BlockPos.containing(x, y, z), 3).getCount() <= 63 && (itemFromBlockInventory(world, BlockPos.containing(x, y, z), 3).copy()).getItem() == ChemicraftModItems.STRONTIUM_INGOT.get()
						|| itemFromBlockInventory(world, BlockPos.containing(x, y, z), 4).getCount() <= 63 && (itemFromBlockInventory(world, BlockPos.containing(x, y, z), 4).copy()).getItem() == ChemicraftModItems.SULFUR_POWDER.get()
						|| (itemFromBlockInventory(world, BlockPos.containing(x, y, z), 3).copy()).getItem() == Blocks.AIR.asItem() && (itemFromBlockInventory(world, BlockPos.containing(x, y, z), 4).copy()).getItem() == Blocks.AIR.asItem())) {
			if (world instanceof ServerLevel _level)
				_level.addFreshEntity(new ExperienceOrb(_level, x, y, z, 2));
			if (world instanceof ServerLevel _serverLevel) {
				BlockEntity _be = _serverLevel.getBlockEntity(BlockPos.containing(x, y, z));
				if (_be instanceof Container _container) {
					_container.getItem(1).shrink(1);
				}
			}
			if (world instanceof ServerLevel _serverLevel) {
				BlockEntity _be = _serverLevel.getBlockEntity(BlockPos.containing(x, y, z));
				if (_be instanceof Container _container) {
					ItemStack _setstack = new ItemStack(ChemicraftModItems.STRONTIUM_INGOT.get()).copy();
					_setstack.setCount(itemFromBlockInventory(world, BlockPos.containing(x, y, z), 3).getCount() + 1);
					_container.setItem(3, _setstack);
				}
			}
			if (world instanceof ServerLevel _serverLevel) {
				BlockEntity _be = _serverLevel.getBlockEntity(BlockPos.containing(x, y, z));
				if (_be instanceof Container _container) {
					ItemStack _setstack = new ItemStack(ChemicraftModItems.SULFUR_POWDER.get()).copy();
					_setstack.setCount(itemFromBlockInventory(world, BlockPos.containing(x, y, z), 4).getCount() + 1);
					_container.setItem(4, _setstack);
				}
			}
		}
		if (itemFromBlockInventory(world, BlockPos.containing(x, y, z), 3).getCount() < 64 && itemFromBlockInventory(world, BlockPos.containing(x, y, z), 4).getCount() < 64
				&& (itemFromBlockInventory(world, BlockPos.containing(x, y, z), 1).copy()).getItem() == ChemicraftModItems.XENOTIME.get()
				&& (itemFromBlockInventory(world, BlockPos.containing(x, y, z), 3).getCount() <= 63 && (itemFromBlockInventory(world, BlockPos.containing(x, y, z), 3).copy()).getItem() == ChemicraftModItems.YTTRIUM_INGOT.get()
						|| itemFromBlockInventory(world, BlockPos.containing(x, y, z), 4).getCount() <= 63 && (itemFromBlockInventory(world, BlockPos.containing(x, y, z), 4).copy()).getItem() == ChemicraftModItems.PHOSPHORIC_ACID.get()
						|| (itemFromBlockInventory(world, BlockPos.containing(x, y, z), 3).copy()).getItem() == Blocks.AIR.asItem() && (itemFromBlockInventory(world, BlockPos.containing(x, y, z), 4).copy()).getItem() == Blocks.AIR.asItem())) {
			if (world instanceof ServerLevel _level)
				_level.addFreshEntity(new ExperienceOrb(_level, x, y, z, 2));
			if (world instanceof ServerLevel _serverLevel) {
				BlockEntity _be = _serverLevel.getBlockEntity(BlockPos.containing(x, y, z));
				if (_be instanceof Container _container) {
					_container.getItem(1).shrink(1);
				}
			}
			if (world instanceof ServerLevel _serverLevel) {
				BlockEntity _be = _serverLevel.getBlockEntity(BlockPos.containing(x, y, z));
				if (_be instanceof Container _container) {
					ItemStack _setstack = new ItemStack(ChemicraftModItems.YTTRIUM_INGOT.get()).copy();
					_setstack.setCount(itemFromBlockInventory(world, BlockPos.containing(x, y, z), 3).getCount() + 1);
					_container.setItem(3, _setstack);
				}
			}
			if (world instanceof ServerLevel _serverLevel) {
				BlockEntity _be = _serverLevel.getBlockEntity(BlockPos.containing(x, y, z));
				if (_be instanceof Container _container) {
					ItemStack _setstack = new ItemStack(ChemicraftModItems.PHOSPHORIC_ACID.get()).copy();
					_setstack.setCount(itemFromBlockInventory(world, BlockPos.containing(x, y, z), 4).getCount() + 1);
					_container.setItem(4, _setstack);
				}
			}
		}
		if (itemFromBlockInventory(world, BlockPos.containing(x, y, z), 3).getCount() < 64 && itemFromBlockInventory(world, BlockPos.containing(x, y, z), 4).getCount() < 64
				&& (itemFromBlockInventory(world, BlockPos.containing(x, y, z), 1).copy()).getItem() == ChemicraftModItems.MOLYBDENITE.get()
				&& (itemFromBlockInventory(world, BlockPos.containing(x, y, z), 3).getCount() <= 63 && (itemFromBlockInventory(world, BlockPos.containing(x, y, z), 3).copy()).getItem() == ChemicraftModItems.MOLYBDENUM.get()
						|| itemFromBlockInventory(world, BlockPos.containing(x, y, z), 4).getCount() <= 63 && (itemFromBlockInventory(world, BlockPos.containing(x, y, z), 4).copy()).getItem() == ChemicraftModItems.SULFUR_POWDER.get()
						|| (itemFromBlockInventory(world, BlockPos.containing(x, y, z), 3).copy()).getItem() == Blocks.AIR.asItem() && (itemFromBlockInventory(world, BlockPos.containing(x, y, z), 4).copy()).getItem() == Blocks.AIR.asItem())) {
			if (world instanceof ServerLevel _level)
				_level.addFreshEntity(new ExperienceOrb(_level, x, y, z, 2));
			if (world instanceof ServerLevel _serverLevel) {
				BlockEntity _be = _serverLevel.getBlockEntity(BlockPos.containing(x, y, z));
				if (_be instanceof Container _container) {
					_container.getItem(1).shrink(1);
				}
			}
			if (world instanceof ServerLevel _serverLevel) {
				BlockEntity _be = _serverLevel.getBlockEntity(BlockPos.containing(x, y, z));
				if (_be instanceof Container _container) {
					ItemStack _setstack = new ItemStack(ChemicraftModItems.MOLYBDENUM.get()).copy();
					_setstack.setCount(itemFromBlockInventory(world, BlockPos.containing(x, y, z), 3).getCount() + 1);
					_container.setItem(3, _setstack);
				}
			}
			if (world instanceof ServerLevel _serverLevel) {
				BlockEntity _be = _serverLevel.getBlockEntity(BlockPos.containing(x, y, z));
				if (_be instanceof Container _container) {
					ItemStack _setstack = new ItemStack(ChemicraftModItems.SULFUR_POWDER.get()).copy();
					_setstack.setCount(itemFromBlockInventory(world, BlockPos.containing(x, y, z), 4).getCount() + 1);
					_container.setItem(4, _setstack);
				}
			}
		}
	}

	private static ItemStack itemFromBlockInventory(LevelAccessor world, BlockPos pos, int slot) {
		if (world instanceof ILevelExtension ext) {
			ResourceHandler<ItemResource> itemHandler = ext.getCapability(Capabilities.Item.BLOCK, pos, null);
			if (itemHandler != null)
				return ItemUtil.getStack(itemHandler, slot);
		}
		return ItemStack.EMPTY;
	}
}