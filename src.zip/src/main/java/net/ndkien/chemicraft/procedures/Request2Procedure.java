package net.ndkien.chemicraft.procedures;

import net.ndkien.chemicraft.init.ChemicraftModBlocks;

import net.minecraft.world.level.block.state.properties.BooleanProperty;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.network.chat.Component;
import net.minecraft.core.BlockPos;
import net.minecraft.ChatFormatting;

public class Request2Procedure {
	public static void execute(LevelAccessor world, double x, double y, double z) {
		boolean found = false;
		double sx = 0;
		double sy = 0;
		double sz = 0;
		found = false;
		sx = -16;
		for (int _i1 = 0; _i1 < 32; _i1++) {
			sy = -16;
			for (int _i2 = 0; _i2 < 32; _i2++) {
				sz = -16;
				for (int _i3 = 0; _i3 < 32; _i3++) {
					if ((world.getBlockState(BlockPos.containing(x + sx, y + sy, z + sz))).getBlock() == ChemicraftModBlocks.ROUTER_2.get()) {
						{
							BlockPos _pos = BlockPos.containing(x + sx, y + sy, z + sz);
							BlockState _bs = world.getBlockState(_pos);
							if (_bs.getBlock().getStateDefinition().getProperty("on") instanceof BooleanProperty _booleanProp)
								world.setBlock(_pos, _bs.setValue(_booleanProp, true), 3);
						}
						found = true;
						if (world instanceof ServerLevel _level) {
							_level.getServer().getPlayerList().broadcastSystemMessage(Component.literal("Connected and sent request to Router #2").withStyle(ChatFormatting.BOLD).withStyle(ChatFormatting.UNDERLINE), false);
						}
					}
					sz = sz + 1;
				}
				sy = sy + 1;
			}
			sx = sx + 1;
		}
		if (found == false) {
			if (world instanceof ServerLevel _level) {
				_level.getServer().getPlayerList().broadcastSystemMessage(Component.literal("Router #2 not found!").withStyle(ChatFormatting.BOLD).withStyle(ChatFormatting.UNDERLINE), false);
			}
		}
	}
}