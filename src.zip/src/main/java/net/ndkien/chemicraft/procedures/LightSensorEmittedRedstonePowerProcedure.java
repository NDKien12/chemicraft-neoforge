package net.ndkien.chemicraft.procedures;

import net.minecraft.world.level.LightLayer;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.core.BlockPos;

public class LightSensorEmittedRedstonePowerProcedure {
	public static double execute(LevelAccessor world, double x, double y, double z) {
		double power = 0;
		power = world.getBrightness(LightLayer.BLOCK, BlockPos.containing(x, y + 1, z));
		return power;
	}
}