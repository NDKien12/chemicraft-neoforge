package net.ndkien.chemicraft.procedures;

import net.ndkien.chemicraft.init.ChemicraftModEntities;
import net.ndkien.chemicraft.entity.StrongMissileProjectileEntity;
import net.ndkien.chemicraft.entity.MissileProjectileEntity;
import net.ndkien.chemicraft.entity.MildMissileProjectileEntity;

import net.minecraft.world.level.block.state.properties.Property;
import net.minecraft.world.level.block.state.properties.IntegerProperty;
import net.minecraft.world.level.block.state.properties.EnumProperty;
import net.minecraft.world.level.block.state.properties.BooleanProperty;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.Level;
import net.minecraft.world.item.enchantment.Enchantments;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.entity.projectile.arrow.AbstractArrow;
import net.minecraft.world.entity.projectile.Projectile;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.Container;
import net.minecraft.sounds.SoundSource;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.resources.Identifier;
import net.minecraft.core.registries.Registries;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.core.Direction;
import net.minecraft.core.BlockPos;

public class MissileLauncherRedstoneOnProcedure {
	public static void execute(LevelAccessor world, double x, double y, double z, BlockState blockstate) {
		if ((getPropertyByName(blockstate, "on") instanceof BooleanProperty _getbp1 && blockstate.getValue(_getbp1)) == true && (getPropertyByName(blockstate, "power") instanceof IntegerProperty _getip3 ? blockstate.getValue(_getip3) : -1) == 0) {
			{
				BlockPos _pos = BlockPos.containing(x, y, z);
				BlockState _bs = world.getBlockState(_pos);
				if (_bs.getBlock().getStateDefinition().getProperty("on") instanceof BooleanProperty _booleanProp)
					world.setBlock(_pos, _bs.setValue(_booleanProp, false), 3);
			}
			if (world instanceof ServerLevel _serverLevel) {
				BlockEntity _be = _serverLevel.getBlockEntity(BlockPos.containing(x, y, z));
				if (_be instanceof Container _container) {
					_container.getItem(0).shrink(1);
				}
			}
			if (world instanceof ServerLevel _level)
				_level.sendParticles(ParticleTypes.EXPLOSION, x, y, z, 10, 0, 0, 0, 1);
			if (world instanceof Level _level) {
				if (!_level.isClientSide()) {
					_level.playSound(null, BlockPos.containing(x, y, z), BuiltInRegistries.SOUND_EVENT.getValue(Identifier.parse("entity.firework_rocket.shoot")), SoundSource.BLOCKS, 10, 1);
				} else {
					_level.playLocalSound(x, y, z, BuiltInRegistries.SOUND_EVENT.getValue(Identifier.parse("entity.firework_rocket.shoot")), SoundSource.BLOCKS, 10, 1, false);
				}
			}
			if (world instanceof Level _level) {
				if (!_level.isClientSide()) {
					_level.playSound(null, BlockPos.containing(x, y, z), BuiltInRegistries.SOUND_EVENT.getValue(Identifier.parse("item.elytra.flying")), SoundSource.BLOCKS, 10, 1);
				} else {
					_level.playLocalSound(x, y, z, BuiltInRegistries.SOUND_EVENT.getValue(Identifier.parse("item.elytra.flying")), SoundSource.BLOCKS, 10, 1, false);
				}
			}
			if (world instanceof Level _level) {
				if (!_level.isClientSide()) {
					_level.playSound(null, BlockPos.containing(x, y, z), BuiltInRegistries.SOUND_EVENT.getValue(Identifier.parse("entity.generic.explode")), SoundSource.BLOCKS, 5, 1);
				} else {
					_level.playLocalSound(x, y, z, BuiltInRegistries.SOUND_EVENT.getValue(Identifier.parse("entity.generic.explode")), SoundSource.BLOCKS, 5, 1, false);
				}
			}
			if (world instanceof Level _level) {
				if (!_level.isClientSide()) {
					_level.playSound(null, BlockPos.containing(x, y, z), BuiltInRegistries.SOUND_EVENT.getValue(Identifier.parse("entity.firework_rocket.large_blast_far")), SoundSource.BLOCKS, 10, 1);
				} else {
					_level.playLocalSound(x, y, z, BuiltInRegistries.SOUND_EVENT.getValue(Identifier.parse("entity.firework_rocket.large_blast_far")), SoundSource.BLOCKS, 10, 1, false);
				}
			}
			if (world instanceof Level _level) {
				if (!_level.isClientSide()) {
					_level.playSound(null, BlockPos.containing(x, y, z), BuiltInRegistries.SOUND_EVENT.getValue(Identifier.parse("entity.firework_rocket.launch")), SoundSource.BLOCKS, 10, 1);
				} else {
					_level.playLocalSound(x, y, z, BuiltInRegistries.SOUND_EVENT.getValue(Identifier.parse("entity.firework_rocket.launch")), SoundSource.BLOCKS, 10, 1, false);
				}
			}
			if ((getDirectionFromBlockState(blockstate)) == Direction.NORTH) {
				if (world instanceof ServerLevel projectileLevel) {
					Projectile _entityToSpawn = initArrowProjectile(new MissileProjectileEntity(ChemicraftModEntities.MISSILE_PROJECTILE.get(), 0, 0, 0, projectileLevel, createArrowWeaponItemStack(projectileLevel, 5, (byte) 0)), null, 19, true, true,
							true, AbstractArrow.Pickup.DISALLOWED);
					_entityToSpawn.setPos(x, (y + 1), z);
					_entityToSpawn.shoot(0, 0.5, (-0.866), 2, 0);
					projectileLevel.addFreshEntity(_entityToSpawn);
				}
			}
			if ((getDirectionFromBlockState(blockstate)) == Direction.SOUTH) {
				if (world instanceof ServerLevel projectileLevel) {
					Projectile _entityToSpawn = initArrowProjectile(new MissileProjectileEntity(ChemicraftModEntities.MISSILE_PROJECTILE.get(), 0, 0, 0, projectileLevel, createArrowWeaponItemStack(projectileLevel, 5, (byte) 0)), null, 19, true, true,
							true, AbstractArrow.Pickup.DISALLOWED);
					_entityToSpawn.setPos(x, (y + 1), z);
					_entityToSpawn.shoot(0, 0.5, 0.866, 2, 0);
					projectileLevel.addFreshEntity(_entityToSpawn);
				}
			}
			if ((getDirectionFromBlockState(blockstate)) == Direction.WEST) {
				if (world instanceof ServerLevel projectileLevel) {
					Projectile _entityToSpawn = initArrowProjectile(new MissileProjectileEntity(ChemicraftModEntities.MISSILE_PROJECTILE.get(), 0, 0, 0, projectileLevel, createArrowWeaponItemStack(projectileLevel, 5, (byte) 0)), null, 19, true, true,
							true, AbstractArrow.Pickup.DISALLOWED);
					_entityToSpawn.setPos(x, (y + 1), z);
					_entityToSpawn.shoot((-0.866), 0.5, 0, 2, 0);
					projectileLevel.addFreshEntity(_entityToSpawn);
				}
			}
			if ((getDirectionFromBlockState(blockstate)) == Direction.EAST) {
				if (world instanceof ServerLevel projectileLevel) {
					Projectile _entityToSpawn = initArrowProjectile(new MissileProjectileEntity(ChemicraftModEntities.MISSILE_PROJECTILE.get(), 0, 0, 0, projectileLevel, createArrowWeaponItemStack(projectileLevel, 5, (byte) 0)), null, 19, true, true,
							true, AbstractArrow.Pickup.DISALLOWED);
					_entityToSpawn.setPos(x, (y + 1), z);
					_entityToSpawn.shoot(0.866, 0.5, 0, 2, 0);
					projectileLevel.addFreshEntity(_entityToSpawn);
				}
			}
		}
		if ((getPropertyByName(blockstate, "on") instanceof BooleanProperty _getbp33 && blockstate.getValue(_getbp33)) == true
				&& (getPropertyByName(blockstate, "power") instanceof IntegerProperty _getip35 ? blockstate.getValue(_getip35) : -1) == 1) {
			{
				BlockPos _pos = BlockPos.containing(x, y, z);
				BlockState _bs = world.getBlockState(_pos);
				if (_bs.getBlock().getStateDefinition().getProperty("on") instanceof BooleanProperty _booleanProp)
					world.setBlock(_pos, _bs.setValue(_booleanProp, false), 3);
			}
			if (world instanceof ServerLevel _serverLevel) {
				BlockEntity _be = _serverLevel.getBlockEntity(BlockPos.containing(x, y, z));
				if (_be instanceof Container _container) {
					_container.getItem(0).shrink(1);
				}
			}
			if (world instanceof ServerLevel _level)
				_level.sendParticles(ParticleTypes.EXPLOSION, x, y, z, 10, 0, 0, 0, 1);
			if (world instanceof Level _level) {
				if (!_level.isClientSide()) {
					_level.playSound(null, BlockPos.containing(x, y, z), BuiltInRegistries.SOUND_EVENT.getValue(Identifier.parse("entity.firework_rocket.shoot")), SoundSource.BLOCKS, 10, 1);
				} else {
					_level.playLocalSound(x, y, z, BuiltInRegistries.SOUND_EVENT.getValue(Identifier.parse("entity.firework_rocket.shoot")), SoundSource.BLOCKS, 10, 1, false);
				}
			}
			if (world instanceof Level _level) {
				if (!_level.isClientSide()) {
					_level.playSound(null, BlockPos.containing(x, y, z), BuiltInRegistries.SOUND_EVENT.getValue(Identifier.parse("item.elytra.flying")), SoundSource.BLOCKS, 10, 1);
				} else {
					_level.playLocalSound(x, y, z, BuiltInRegistries.SOUND_EVENT.getValue(Identifier.parse("item.elytra.flying")), SoundSource.BLOCKS, 10, 1, false);
				}
			}
			if (world instanceof Level _level) {
				if (!_level.isClientSide()) {
					_level.playSound(null, BlockPos.containing(x, y, z), BuiltInRegistries.SOUND_EVENT.getValue(Identifier.parse("entity.generic.explode")), SoundSource.BLOCKS, 5, 1);
				} else {
					_level.playLocalSound(x, y, z, BuiltInRegistries.SOUND_EVENT.getValue(Identifier.parse("entity.generic.explode")), SoundSource.BLOCKS, 5, 1, false);
				}
			}
			if (world instanceof Level _level) {
				if (!_level.isClientSide()) {
					_level.playSound(null, BlockPos.containing(x, y, z), BuiltInRegistries.SOUND_EVENT.getValue(Identifier.parse("entity.firework_rocket.large_blast_far")), SoundSource.BLOCKS, 10, 1);
				} else {
					_level.playLocalSound(x, y, z, BuiltInRegistries.SOUND_EVENT.getValue(Identifier.parse("entity.firework_rocket.large_blast_far")), SoundSource.BLOCKS, 10, 1, false);
				}
			}
			if (world instanceof Level _level) {
				if (!_level.isClientSide()) {
					_level.playSound(null, BlockPos.containing(x, y, z), BuiltInRegistries.SOUND_EVENT.getValue(Identifier.parse("entity.firework_rocket.launch")), SoundSource.BLOCKS, 10, 1);
				} else {
					_level.playLocalSound(x, y, z, BuiltInRegistries.SOUND_EVENT.getValue(Identifier.parse("entity.firework_rocket.launch")), SoundSource.BLOCKS, 10, 1, false);
				}
			}
			if ((getDirectionFromBlockState(blockstate)) == Direction.NORTH) {
				if (world instanceof ServerLevel projectileLevel) {
					Projectile _entityToSpawn = initArrowProjectile(new MildMissileProjectileEntity(ChemicraftModEntities.MILD_MISSILE_PROJECTILE.get(), 0, 0, 0, projectileLevel, createArrowWeaponItemStack(projectileLevel, 10, (byte) 0)), null, 38,
							true, true, true, AbstractArrow.Pickup.DISALLOWED);
					_entityToSpawn.setPos(x, (y + 1), z);
					_entityToSpawn.shoot(0, 0.5, (-0.866), 4, 0);
					projectileLevel.addFreshEntity(_entityToSpawn);
				}
			}
			if ((getDirectionFromBlockState(blockstate)) == Direction.SOUTH) {
				if (world instanceof ServerLevel projectileLevel) {
					Projectile _entityToSpawn = initArrowProjectile(new MildMissileProjectileEntity(ChemicraftModEntities.MILD_MISSILE_PROJECTILE.get(), 0, 0, 0, projectileLevel, createArrowWeaponItemStack(projectileLevel, 10, (byte) 0)), null, 38,
							true, true, true, AbstractArrow.Pickup.DISALLOWED);
					_entityToSpawn.setPos(x, (y + 1), z);
					_entityToSpawn.shoot(0, 0.5, 0.866, 4, 0);
					projectileLevel.addFreshEntity(_entityToSpawn);
				}
			}
			if ((getDirectionFromBlockState(blockstate)) == Direction.WEST) {
				if (world instanceof ServerLevel projectileLevel) {
					Projectile _entityToSpawn = initArrowProjectile(new MildMissileProjectileEntity(ChemicraftModEntities.MILD_MISSILE_PROJECTILE.get(), 0, 0, 0, projectileLevel, createArrowWeaponItemStack(projectileLevel, 10, (byte) 0)), null, 38,
							true, true, true, AbstractArrow.Pickup.DISALLOWED);
					_entityToSpawn.setPos(x, (y + 1), z);
					_entityToSpawn.shoot((-0.866), 0.5, 0, 4, 0);
					projectileLevel.addFreshEntity(_entityToSpawn);
				}
			}
			if ((getDirectionFromBlockState(blockstate)) == Direction.EAST) {
				if (world instanceof ServerLevel projectileLevel) {
					Projectile _entityToSpawn = initArrowProjectile(new MildMissileProjectileEntity(ChemicraftModEntities.MILD_MISSILE_PROJECTILE.get(), 0, 0, 0, projectileLevel, createArrowWeaponItemStack(projectileLevel, 10, (byte) 0)), null, 38,
							true, true, true, AbstractArrow.Pickup.DISALLOWED);
					_entityToSpawn.setPos(x, (y + 1), z);
					_entityToSpawn.shoot(0.866, 0.5, 0, 4, 0);
					projectileLevel.addFreshEntity(_entityToSpawn);
				}
			}
		}
		if ((getPropertyByName(blockstate, "on") instanceof BooleanProperty _getbp65 && blockstate.getValue(_getbp65)) == true
				&& (getPropertyByName(blockstate, "power") instanceof IntegerProperty _getip67 ? blockstate.getValue(_getip67) : -1) == 2) {
			{
				BlockPos _pos = BlockPos.containing(x, y, z);
				BlockState _bs = world.getBlockState(_pos);
				if (_bs.getBlock().getStateDefinition().getProperty("on") instanceof BooleanProperty _booleanProp)
					world.setBlock(_pos, _bs.setValue(_booleanProp, false), 3);
			}
			if (world instanceof ServerLevel _serverLevel) {
				BlockEntity _be = _serverLevel.getBlockEntity(BlockPos.containing(x, y, z));
				if (_be instanceof Container _container) {
					_container.getItem(0).shrink(1);
				}
			}
			if (world instanceof ServerLevel _level)
				_level.sendParticles(ParticleTypes.EXPLOSION, x, y, z, 10, 0, 0, 0, 1);
			if (world instanceof Level _level) {
				if (!_level.isClientSide()) {
					_level.playSound(null, BlockPos.containing(x, y, z), BuiltInRegistries.SOUND_EVENT.getValue(Identifier.parse("entity.firework_rocket.shoot")), SoundSource.BLOCKS, 10, 1);
				} else {
					_level.playLocalSound(x, y, z, BuiltInRegistries.SOUND_EVENT.getValue(Identifier.parse("entity.firework_rocket.shoot")), SoundSource.BLOCKS, 10, 1, false);
				}
			}
			if (world instanceof Level _level) {
				if (!_level.isClientSide()) {
					_level.playSound(null, BlockPos.containing(x, y, z), BuiltInRegistries.SOUND_EVENT.getValue(Identifier.parse("item.elytra.flying")), SoundSource.BLOCKS, 10, 1);
				} else {
					_level.playLocalSound(x, y, z, BuiltInRegistries.SOUND_EVENT.getValue(Identifier.parse("item.elytra.flying")), SoundSource.BLOCKS, 10, 1, false);
				}
			}
			if (world instanceof Level _level) {
				if (!_level.isClientSide()) {
					_level.playSound(null, BlockPos.containing(x, y, z), BuiltInRegistries.SOUND_EVENT.getValue(Identifier.parse("entity.generic.explode")), SoundSource.BLOCKS, 5, 1);
				} else {
					_level.playLocalSound(x, y, z, BuiltInRegistries.SOUND_EVENT.getValue(Identifier.parse("entity.generic.explode")), SoundSource.BLOCKS, 5, 1, false);
				}
			}
			if (world instanceof Level _level) {
				if (!_level.isClientSide()) {
					_level.playSound(null, BlockPos.containing(x, y, z), BuiltInRegistries.SOUND_EVENT.getValue(Identifier.parse("entity.firework_rocket.large_blast_far")), SoundSource.BLOCKS, 10, 1);
				} else {
					_level.playLocalSound(x, y, z, BuiltInRegistries.SOUND_EVENT.getValue(Identifier.parse("entity.firework_rocket.large_blast_far")), SoundSource.BLOCKS, 10, 1, false);
				}
			}
			if (world instanceof Level _level) {
				if (!_level.isClientSide()) {
					_level.playSound(null, BlockPos.containing(x, y, z), BuiltInRegistries.SOUND_EVENT.getValue(Identifier.parse("entity.firework_rocket.launch")), SoundSource.BLOCKS, 10, 1);
				} else {
					_level.playLocalSound(x, y, z, BuiltInRegistries.SOUND_EVENT.getValue(Identifier.parse("entity.firework_rocket.launch")), SoundSource.BLOCKS, 10, 1, false);
				}
			}
			if ((getDirectionFromBlockState(blockstate)) == Direction.NORTH) {
				if (world instanceof ServerLevel projectileLevel) {
					Projectile _entityToSpawn = initArrowProjectile(new StrongMissileProjectileEntity(ChemicraftModEntities.STRONG_MISSILE_PROJECTILE.get(), 0, 0, 0, projectileLevel, createArrowWeaponItemStack(projectileLevel, 15, (byte) 0)), null,
							57, true, true, true, AbstractArrow.Pickup.DISALLOWED);
					_entityToSpawn.setPos(x, (y + 1), z);
					_entityToSpawn.shoot(0, 0.5, (-0.866), 6, 0);
					projectileLevel.addFreshEntity(_entityToSpawn);
				}
			}
			if ((getDirectionFromBlockState(blockstate)) == Direction.SOUTH) {
				if (world instanceof ServerLevel projectileLevel) {
					Projectile _entityToSpawn = initArrowProjectile(new StrongMissileProjectileEntity(ChemicraftModEntities.STRONG_MISSILE_PROJECTILE.get(), 0, 0, 0, projectileLevel, createArrowWeaponItemStack(projectileLevel, 15, (byte) 0)), null,
							57, true, true, true, AbstractArrow.Pickup.DISALLOWED);
					_entityToSpawn.setPos(x, (y + 1), z);
					_entityToSpawn.shoot(0, 0.5, 0.866, 6, 0);
					projectileLevel.addFreshEntity(_entityToSpawn);
				}
			}
			if ((getDirectionFromBlockState(blockstate)) == Direction.WEST) {
				if (world instanceof ServerLevel projectileLevel) {
					Projectile _entityToSpawn = initArrowProjectile(new StrongMissileProjectileEntity(ChemicraftModEntities.STRONG_MISSILE_PROJECTILE.get(), 0, 0, 0, projectileLevel, createArrowWeaponItemStack(projectileLevel, 15, (byte) 0)), null,
							57, true, true, true, AbstractArrow.Pickup.DISALLOWED);
					_entityToSpawn.setPos(x, (y + 1), z);
					_entityToSpawn.shoot((-0.866), 0.5, 0, 6, 0);
					projectileLevel.addFreshEntity(_entityToSpawn);
				}
			}
			if ((getDirectionFromBlockState(blockstate)) == Direction.EAST) {
				if (world instanceof ServerLevel projectileLevel) {
					Projectile _entityToSpawn = initArrowProjectile(new StrongMissileProjectileEntity(ChemicraftModEntities.STRONG_MISSILE_PROJECTILE.get(), 0, 0, 0, projectileLevel, createArrowWeaponItemStack(projectileLevel, 15, (byte) 0)), null,
							57, true, true, true, AbstractArrow.Pickup.DISALLOWED);
					_entityToSpawn.setPos(x, (y + 1), z);
					_entityToSpawn.shoot(0.866, 0.5, 0, 6, 0);
					projectileLevel.addFreshEntity(_entityToSpawn);
				}
			}
		}
	}

	private static Property<?> getPropertyByName(BlockState state, String name) {
		for (Property<?> property : state.getProperties()) {
			if (property.getName().equals(name)) {
				return property;
			}
		}
		return null;
	}

	private static Direction getDirectionFromBlockState(BlockState blockState) {
		if (getPropertyByName(blockState, "facing") instanceof EnumProperty ep && ep.getValueClass() == Direction.class)
			return (Direction) blockState.getValue(ep);
		if (getPropertyByName(blockState, "axis") instanceof EnumProperty ep && ep.getValueClass() == Direction.Axis.class)
			return Direction.fromAxisAndDirection((Direction.Axis) blockState.getValue(ep), Direction.AxisDirection.POSITIVE);
		return Direction.NORTH;
	}

	private static AbstractArrow initArrowProjectile(AbstractArrow entityToSpawn, Entity shooter, float damage, boolean silent, boolean fire, boolean particles, AbstractArrow.Pickup pickup) {
		entityToSpawn.setOwner(shooter);
		entityToSpawn.setBaseDamage(damage);
		if (silent)
			entityToSpawn.setSilent(true);
		if (fire)
			entityToSpawn.igniteForSeconds(100);
		if (particles)
			entityToSpawn.setCritArrow(true);
		entityToSpawn.pickup = pickup;
		return entityToSpawn;
	}

	private static ItemStack createArrowWeaponItemStack(Level level, int knockback, byte piercing) {
		ItemStack weapon = new ItemStack(Items.ARROW);
		if (knockback > 0)
			weapon.enchant(level.registryAccess().lookupOrThrow(Registries.ENCHANTMENT).getOrThrow(Enchantments.KNOCKBACK), knockback);
		if (piercing > 0)
			weapon.enchant(level.registryAccess().lookupOrThrow(Registries.ENCHANTMENT).getOrThrow(Enchantments.PIERCING), piercing);
		return weapon;
	}
}