package net.ndkien.chemicraft.procedures;

import net.minecraft.world.level.block.state.properties.Property;
import net.minecraft.world.level.block.state.properties.BooleanProperty;
import net.minecraft.world.level.block.state.BlockState;

public class NuclearReactorLuminanceProcedure {
	public static double execute(BlockState blockstate) {
		double light = 0;
		if ((getPropertyByName(blockstate, "on") instanceof BooleanProperty _getbp1 && blockstate.getValue(_getbp1)) == true) {
			light = 15;
		} else {
			light = 0;
		}
		return light;
	}

	private static Property<?> getPropertyByName(BlockState state, String name) {
		for (Property<?> property : state.getProperties()) {
			if (property.getName().equals(name)) {
				return property;
			}
		}
		return null;
	}
}