package net.ndkien.chemicraft.procedures;

import net.minecraft.world.level.LevelAccessor;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.network.chat.Component;
import net.minecraft.ChatFormatting;

import java.util.Calendar;

public class AtomicTimerRedstoneOnProcedure {
	public static void execute(LevelAccessor world) {
		if (world instanceof ServerLevel _level) {
			_level.getServer().getPlayerList().broadcastSystemMessage(Component.literal("The current date and time is: ").withColor(0xffff33).withStyle(ChatFormatting.BOLD).withStyle(ChatFormatting.UNDERLINE), false);
		}
		if (world instanceof ServerLevel _level) {
			_level.getServer().getPlayerList()
					.broadcastSystemMessage(Component.literal(((Calendar.getInstance().get(Calendar.HOUR_OF_DAY) + "" + (":" + (Calendar.getInstance().get(Calendar.MINUTE) + "" + (":" + Calendar.getInstance().get(Calendar.SECOND))))) + ""
							+ ("  " + (Calendar.getInstance().get(Calendar.DAY_OF_MONTH) + "" + ("/" + (Calendar.getInstance().get(Calendar.MONTH) + "" + ("/" + Calendar.getInstance().get(Calendar.YEAR)))))))), false);
		}
		if (Calendar.getInstance().get(Calendar.DAY_OF_MONTH) == 1 && Calendar.getInstance().get(Calendar.MONTH) == 1) {
			if (world instanceof ServerLevel _level) {
				_level.getServer().getPlayerList()
						.broadcastSystemMessage(Component.literal(("Happy New Year " + (Calendar.getInstance().get(Calendar.YEAR) + " :D!"))).withColor(0xff0000).withStyle(ChatFormatting.BOLD).withStyle(ChatFormatting.UNDERLINE), false);
			}
		}
		if (Calendar.getInstance().get(Calendar.DAY_OF_MONTH) == 24 && Calendar.getInstance().get(Calendar.MONTH) == 12) {
			if (world instanceof ServerLevel _level) {
				_level.getServer().getPlayerList().broadcastSystemMessage(Component.literal(("Merry Christmas" + " :D!")).withColor(0x00ff66).withStyle(ChatFormatting.BOLD).withStyle(ChatFormatting.UNDERLINE), false);
			}
		}
		if (Calendar.getInstance().get(Calendar.DAY_OF_MONTH) == 1 && Calendar.getInstance().get(Calendar.MONTH) != 1) {
			if (world instanceof ServerLevel _level) {
				_level.getServer().getPlayerList().broadcastSystemMessage(Component.literal("Wake up!").withColor(0x0066ff).withStyle(ChatFormatting.BOLD).withStyle(ChatFormatting.UNDERLINE), false);
			}
			if (world instanceof ServerLevel _level) {
				_level.getServer().getPlayerList().broadcastSystemMessage(Component.literal("It's the first of tha month!").withColor(0x0066ff).withStyle(ChatFormatting.BOLD).withStyle(ChatFormatting.UNDERLINE), false);
			}
		}
	}
}