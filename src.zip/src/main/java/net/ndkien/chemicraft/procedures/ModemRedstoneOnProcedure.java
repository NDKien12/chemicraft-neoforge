package net.ndkien.chemicraft.procedures;

import net.minecraft.world.level.block.state.properties.Property;
import net.minecraft.world.level.block.state.properties.IntegerProperty;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.LevelAccessor;

public class ModemRedstoneOnProcedure {
	public static void execute(LevelAccessor world, double x, double y, double z, BlockState blockstate) {
		if ((getPropertyByName(blockstate, "id") instanceof IntegerProperty _getip1 ? blockstate.getValue(_getip1) : -1) == 1) {
			Request1Procedure.execute(world, x, y, z);
		}
		if ((getPropertyByName(blockstate, "id") instanceof IntegerProperty _getip3 ? blockstate.getValue(_getip3) : -1) == 2) {
			Request2Procedure.execute(world, x, y, z);
		}
		if ((getPropertyByName(blockstate, "id") instanceof IntegerProperty _getip5 ? blockstate.getValue(_getip5) : -1) == 3) {
			Request3Procedure.execute(world, x, y, z);
		}
		if ((getPropertyByName(blockstate, "id") instanceof IntegerProperty _getip7 ? blockstate.getValue(_getip7) : -1) == 4) {
			Request4Procedure.execute(world, x, y, z);
		}
	}

	private static Property<?> getPropertyByName(BlockState state, String name) {
		for (Property<?> property : state.getProperties()) {
			if (property.getName().equals(name)) {
				return property;
			}
		}
		return null;
	}
}