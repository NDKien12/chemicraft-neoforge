package net.ndkien.chemicraft.procedures;

import net.minecraft.world.level.block.state.properties.Property;
import net.minecraft.world.level.block.state.properties.IntegerProperty;
import net.minecraft.world.level.block.state.BlockState;

public class RedLEDLuminanceProcedure {
	public static double execute(BlockState blockstate) {
		double light = 0;
		light = getPropertyByName(blockstate, "light") instanceof IntegerProperty _getip1 ? blockstate.getValue(_getip1) : -1;
		return light;
	}

	private static Property<?> getPropertyByName(BlockState state, String name) {
		for (Property<?> property : state.getProperties()) {
			if (property.getName().equals(name)) {
				return property;
			}
		}
		return null;
	}
}