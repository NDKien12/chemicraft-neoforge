package net.ndkien.chemicraft.procedures;

import net.ndkien.chemicraft.ChemicraftMod;

import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.Level;
import net.minecraft.core.BlockPos;

public class NuclearBombEntityFallsOnTheBlockProcedure {
	public static void execute(LevelAccessor world, double x, double y, double z) {
		world.setBlock(BlockPos.containing(x, y, z), Blocks.AIR.defaultBlockState(), 3);
		ChemicraftMod.queueServerWork(1, () -> {
			if (world instanceof Level _level && !_level.isClientSide())
				_level.explode(null, x, y, z, 160, Level.ExplosionInteraction.TNT);
		});
	}
}