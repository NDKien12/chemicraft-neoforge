package net.ndkien.chemicraft.network;

import net.neoforged.neoforge.network.handling.IPayloadContext;
import net.neoforged.fml.event.lifecycle.FMLCommonSetupEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;

import net.ndkien.chemicraft.procedures.Request4Procedure;
import net.ndkien.chemicraft.procedures.Request3Procedure;
import net.ndkien.chemicraft.procedures.Request2Procedure;
import net.ndkien.chemicraft.procedures.Request1Procedure;
import net.ndkien.chemicraft.ChemicraftMod;

import net.minecraft.world.level.Level;
import net.minecraft.world.entity.player.Player;
import net.minecraft.resources.Identifier;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.network.protocol.PacketFlow;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.chat.Component;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.core.SectionPos;

@EventBusSubscriber
public record SmartphoneGUIButtonMessage(int buttonID, int x, int y, int z) implements CustomPacketPayload {
	public static final Type<SmartphoneGUIButtonMessage> TYPE = new Type<>(Identifier.fromNamespaceAndPath(ChemicraftMod.MODID, "smartphone_gui_buttons"));
	public static final StreamCodec<RegistryFriendlyByteBuf, SmartphoneGUIButtonMessage> STREAM_CODEC = StreamCodec.of((RegistryFriendlyByteBuf buffer, SmartphoneGUIButtonMessage message) -> {
		buffer.writeInt(message.buttonID);
		buffer.writeInt(message.x);
		buffer.writeInt(message.y);
		buffer.writeInt(message.z);
	}, (RegistryFriendlyByteBuf buffer) -> new SmartphoneGUIButtonMessage(buffer.readInt(), buffer.readInt(), buffer.readInt(), buffer.readInt()));

	@Override
	public Type<SmartphoneGUIButtonMessage> type() {
		return TYPE;
	}

	public static void handleData(final SmartphoneGUIButtonMessage message, final IPayloadContext context) {
		if (context.flow() == PacketFlow.SERVERBOUND) {
			context.enqueueWork(() -> handleButtonAction(context.player(), message.buttonID, message.x, message.y, message.z)).exceptionally(e -> {
				context.connection().disconnect(Component.literal(e.getMessage()));
				return null;
			});
		}
	}

	public static void handleButtonAction(Player entity, int buttonID, int x, int y, int z) {
		Level world = entity.level();
		// security measure to prevent arbitrary chunk generation
		if (!world.getChunkSource().hasChunk(SectionPos.blockToSectionCoord(x), SectionPos.blockToSectionCoord(z)))
			return;
		if (buttonID == 0) {

			Request1Procedure.execute(world, x, y, z);
		}
		if (buttonID == 1) {

			Request2Procedure.execute(world, x, y, z);
		}
		if (buttonID == 2) {

			Request3Procedure.execute(world, x, y, z);
		}
		if (buttonID == 3) {

			Request4Procedure.execute(world, x, y, z);
		}
	}

	@SubscribeEvent
	public static void registerMessage(FMLCommonSetupEvent event) {
		ChemicraftMod.addNetworkMessage(SmartphoneGUIButtonMessage.TYPE, SmartphoneGUIButtonMessage.STREAM_CODEC, SmartphoneGUIButtonMessage::handleData);
	}
}