package net.ndkien.chemicraft.block;

import net.ndkien.chemicraft.procedures.BlockOfSteelBlockAddedProcedure;

import net.minecraft.world.level.block.state.properties.NoteBlockInstrument;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.Level;
import net.minecraft.core.BlockPos;

public class BlockOfSteelBlock extends Block {
	public BlockOfSteelBlock(BlockBehaviour.Properties properties) {
		super(properties.sound(SoundType.HEAVY_CORE).strength(7f, 8f).requiresCorrectToolForDrops().instrument(NoteBlockInstrument.IRON_XYLOPHONE));
	}

	@Override
	public void onPlace(BlockState blockstate, Level world, BlockPos pos, BlockState oldState, boolean moving) {
		super.onPlace(blockstate, world, pos, oldState, moving);
		BlockOfSteelBlockAddedProcedure.execute(world, pos.getX(), pos.getY(), pos.getZ());
	}
}