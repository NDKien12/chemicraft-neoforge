package net.ndkien.chemicraft.block;

import net.ndkien.chemicraft.procedures.CRTScreenRedstoneOnProcedure;
import net.ndkien.chemicraft.procedures.CRTScreenRedstoneOffProcedure;

import net.minecraft.world.level.redstone.Orientation;
import net.minecraft.world.level.block.state.properties.IntegerProperty;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.Level;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.core.BlockPos;

import javax.annotation.Nullable;

public class CRTScreenBlock extends Block {
	public static final IntegerProperty SCREEN = IntegerProperty.create("screen", 0, 2);

	public CRTScreenBlock(BlockBehaviour.Properties properties) {
		super(properties.sound(SoundType.GLASS).strength(4f));
		this.registerDefaultState(this.stateDefinition.any().setValue(SCREEN, 0));
	}

	@Override
	protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
		super.createBlockStateDefinition(builder);
		builder.add(SCREEN);
	}

	@Override
	public BlockState getStateForPlacement(BlockPlaceContext context) {
		BlockState state = super.getStateForPlacement(context);
		if (state == null)
			return null;
		return state.setValue(SCREEN, 0);
	}

	@Override
	public void neighborChanged(BlockState blockstate, Level world, BlockPos pos, Block neighborBlock, @Nullable Orientation orientation, boolean moving) {
		super.neighborChanged(blockstate, world, pos, neighborBlock, orientation, moving);
		if (world.getBestNeighborSignal(pos) > 0) {
			CRTScreenRedstoneOnProcedure.execute(world, pos.getX(), pos.getY(), pos.getZ());
		} else {
			CRTScreenRedstoneOffProcedure.execute(world, pos.getX(), pos.getY(), pos.getZ());
		}
	}
}