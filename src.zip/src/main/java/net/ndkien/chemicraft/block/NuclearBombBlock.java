package net.ndkien.chemicraft.block;

import net.ndkien.chemicraft.procedures.NuclearBombEntityFallsOnTheBlockProcedure;

import net.minecraft.world.phys.shapes.VoxelShape;
import net.minecraft.world.phys.shapes.Shapes;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.level.redstone.Orientation;
import net.minecraft.world.level.block.state.properties.EnumProperty;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.*;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.core.Direction;
import net.minecraft.core.BlockPos;

import javax.annotation.Nullable;

import java.util.function.Function;

import com.mojang.serialization.MapCodec;

public class NuclearBombBlock extends FallingBlock {
	public static final EnumProperty<Direction> FACING = DirectionalBlock.FACING;
	private final Function<BlockState, VoxelShape> shapes = this.makeShapes();
	public static final MapCodec<NuclearBombBlock> CODEC = simpleCodec(NuclearBombBlock::new);

	@Override
	public MapCodec<NuclearBombBlock> codec() {
		return CODEC;
	}

	@Override
	public int getDustColor(BlockState blockstate, BlockGetter world, BlockPos pos) {
		return blockstate.getMapColor(world, pos).col;
	}

	public NuclearBombBlock(BlockBehaviour.Properties properties) {
		super(properties.sound(SoundType.METAL).strength(5f, 6f).requiresCorrectToolForDrops().noOcclusion().isRedstoneConductor((bs, br, bp) -> false));
		this.registerDefaultState(this.stateDefinition.any().setValue(FACING, Direction.NORTH));
	}

	private Function<BlockState, VoxelShape> makeShapes() {
		return this.getShapeForEachState(state -> {
			return switch (state.getValue(FACING)) {
				case NORTH -> Shapes.or(box(0, 0, 16, 16, 2, 18), box(0, 14, 16, 16, 16, 18), box(0, 2, 16, 2, 14, 18), box(14, 2, 16, 16, 14, 18), box(2, 2, 15, 14, 14, 17), box(3, 3, 13, 13, 13, 15), box(3, 3, -1, 13, 13, 1),
						box(4, 4, -2, 12, 12, 0), box(2, 2, 11, 14, 14, 13), box(2, 2, 1, 14, 14, 3), box(1, 1, 3, 15, 15, 11));
				case EAST -> Shapes.or(box(-2, 0, 0, 0, 2, 16), box(-2, 14, 0, 0, 16, 16), box(-2, 2, 0, 0, 14, 2), box(-2, 2, 14, 0, 14, 16), box(-1, 2, 2, 1, 14, 14), box(1, 3, 3, 3, 13, 13), box(15, 3, 3, 17, 13, 13), box(16, 4, 4, 18, 12, 12),
						box(3, 2, 2, 5, 14, 14), box(13, 2, 2, 15, 14, 14), box(5, 1, 1, 13, 15, 15));
				case WEST -> Shapes.or(box(16, 0, 0, 18, 2, 16), box(16, 14, 0, 18, 16, 16), box(16, 2, 14, 18, 14, 16), box(16, 2, 0, 18, 14, 2), box(15, 2, 2, 17, 14, 14), box(13, 3, 3, 15, 13, 13), box(-1, 3, 3, 1, 13, 13),
						box(-2, 4, 4, 0, 12, 12), box(11, 2, 2, 13, 14, 14), box(1, 2, 2, 3, 14, 14), box(3, 1, 1, 11, 15, 15));
				case UP -> Shapes.or(box(0, -2, 0, 16, 0, 2), box(0, -2, 14, 16, 0, 16), box(0, -2, 2, 2, 0, 14), box(14, -2, 2, 16, 0, 14), box(2, -1, 2, 14, 1, 14), box(3, 1, 3, 13, 3, 13), box(3, 15, 3, 13, 17, 13), box(4, 16, 4, 12, 18, 12),
						box(2, 3, 2, 14, 5, 14), box(2, 13, 2, 14, 15, 14), box(1, 5, 1, 15, 13, 15));
				case DOWN -> Shapes.or(box(0, 16, 14, 16, 18, 16), box(0, 16, 0, 16, 18, 2), box(0, 16, 2, 2, 18, 14), box(14, 16, 2, 16, 18, 14), box(2, 15, 2, 14, 17, 14), box(3, 13, 3, 13, 15, 13), box(3, -1, 3, 13, 1, 13),
						box(4, -2, 4, 12, 0, 12), box(2, 11, 2, 14, 13, 14), box(2, 1, 2, 14, 3, 14), box(1, 3, 1, 15, 11, 15));
				default -> Shapes.or(box(0, 0, -2, 16, 2, 0), box(0, 14, -2, 16, 16, 0), box(14, 2, -2, 16, 14, 0), box(0, 2, -2, 2, 14, 0), box(2, 2, -1, 14, 14, 1), box(3, 3, 1, 13, 13, 3), box(3, 3, 15, 13, 13, 17), box(4, 4, 16, 12, 12, 18),
						box(2, 2, 3, 14, 14, 5), box(2, 2, 13, 14, 14, 15), box(1, 1, 5, 15, 15, 13));
			};
		});
	}

	@Override
	public VoxelShape getShape(BlockState state, BlockGetter world, BlockPos pos, CollisionContext context) {
		return shapes.apply(state);
	}

	@Override
	public boolean propagatesSkylightDown(BlockState state) {
		return true;
	}

	@Override
	public int getLightDampening(BlockState state) {
		return 0;
	}

	@Override
	public VoxelShape getVisualShape(BlockState state, BlockGetter world, BlockPos pos, CollisionContext context) {
		return Shapes.empty();
	}

	@Override
	protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
		super.createBlockStateDefinition(builder);
		builder.add(FACING);
	}

	@Override
	public BlockState getStateForPlacement(BlockPlaceContext context) {
		BlockState state = super.getStateForPlacement(context);
		if (state == null)
			return null;
		return state.setValue(FACING, context.getNearestLookingDirection().getOpposite());
	}

	public BlockState rotate(BlockState state, Rotation rot) {
		return state.setValue(FACING, rot.rotate(state.getValue(FACING)));
	}

	public BlockState mirror(BlockState state, Mirror mirrorIn) {
		return state.rotate(mirrorIn.getRotation(state.getValue(FACING)));
	}

	@Override
	public void neighborChanged(BlockState blockstate, Level world, BlockPos pos, Block neighborBlock, @Nullable Orientation orientation, boolean moving) {
		super.neighborChanged(blockstate, world, pos, neighborBlock, orientation, moving);
		if (world.getBestNeighborSignal(pos) > 0) {
			NuclearBombEntityFallsOnTheBlockProcedure.execute(world, pos.getX(), pos.getY(), pos.getZ());
		}
	}
}