package net.ndkien.chemicraft.block;

import net.ndkien.chemicraft.procedures.RedTorchBlockAddedProcedure;

import net.minecraft.world.phys.shapes.VoxelShape;
import net.minecraft.world.phys.shapes.Shapes;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.level.material.PushReaction;
import net.minecraft.world.level.block.state.properties.EnumProperty;
import net.minecraft.world.level.block.state.properties.BooleanProperty;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.Rotation;
import net.minecraft.world.level.block.Mirror;
import net.minecraft.world.level.block.HorizontalDirectionalBlock;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.core.Direction;
import net.minecraft.core.BlockPos;

import java.util.function.Function;

public class PurpleTorchBlock extends Block {
	public static final EnumProperty<Direction> FACING = HorizontalDirectionalBlock.FACING;
	public static final BooleanProperty FACING_WALL = BooleanProperty.create("facing_wall");
	private final Function<BlockState, VoxelShape> shapes = this.makeShapes();

	public PurpleTorchBlock(BlockBehaviour.Properties properties) {
		super(properties.sound(SoundType.WOOD).instabreak().lightLevel(blockstate -> 2).noCollision().pushReaction(PushReaction.DESTROY).postProcess((bs, br, bp) -> bp).emissiveRendering((bs, br, bp) -> true)
				.isRedstoneConductor((bs, br, bp) -> false));
		this.registerDefaultState(this.stateDefinition.any().setValue(FACING, Direction.NORTH).setValue(FACING_WALL, false));
	}

	private Function<BlockState, VoxelShape> makeShapes() {
		return this.getShapeForEachState(state -> {
			if (state.getValue(FACING_WALL) == true) {
				return switch (state.getValue(FACING)) {
					case NORTH -> box(7, 3.5, 12, 9, 13.5, 16);
					case EAST -> box(0, 3.5, 7, 4, 13.5, 9);
					case WEST -> box(12, 3.5, 7, 16, 13.5, 9);
					default -> box(7, 3.5, 0, 9, 13.5, 4);
				};
			}
			return switch (state.getValue(FACING)) {
				case NORTH -> box(7, 0, 7, 9, 10, 9);
				case EAST -> box(7, 0, 7, 9, 10, 9);
				case WEST -> box(7, 0, 7, 9, 10, 9);
				default -> box(7, 0, 7, 9, 10, 9);
			};
		});
	}

	@Override
	public VoxelShape getShape(BlockState state, BlockGetter world, BlockPos pos, CollisionContext context) {
		return shapes.apply(state);
	}

	@Override
	public VoxelShape getVisualShape(BlockState state, BlockGetter world, BlockPos pos, CollisionContext context) {
		return Shapes.empty();
	}

	@Override
	protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
		super.createBlockStateDefinition(builder);
		builder.add(FACING, FACING_WALL);
	}

	@Override
	public BlockState getStateForPlacement(BlockPlaceContext context) {
		BlockState state = super.getStateForPlacement(context);
		if (state == null)
			return null;
		if (context.getClickedFace().getAxis() == Direction.Axis.Y)
			return state.setValue(FACING, Direction.NORTH).setValue(FACING_WALL, false);
		return state.setValue(FACING, context.getClickedFace()).setValue(FACING_WALL, false);
	}

	public BlockState rotate(BlockState state, Rotation rot) {
		return state.setValue(FACING, rot.rotate(state.getValue(FACING)));
	}

	public BlockState mirror(BlockState state, Mirror mirrorIn) {
		return state.rotate(mirrorIn.getRotation(state.getValue(FACING)));
	}

	@Override
	public void onPlace(BlockState blockstate, Level world, BlockPos pos, BlockState oldState, boolean moving) {
		super.onPlace(blockstate, world, pos, oldState, moving);
		RedTorchBlockAddedProcedure.execute(world, pos.getX(), pos.getY(), pos.getZ());
	}
}