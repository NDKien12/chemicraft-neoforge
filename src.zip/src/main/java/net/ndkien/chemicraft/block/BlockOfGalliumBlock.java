package net.ndkien.chemicraft.block;

import net.minecraft.world.level.block.state.properties.NoteBlockInstrument;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.Block;

public class BlockOfGalliumBlock extends Block {
	public BlockOfGalliumBlock(BlockBehaviour.Properties properties) {
		super(properties.sound(SoundType.METAL).strength(2f).instrument(NoteBlockInstrument.IRON_XYLOPHONE));
	}
}