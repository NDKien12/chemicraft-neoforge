package net.ndkien.chemicraft.block;

import net.ndkien.chemicraft.procedures.WeatherSensorOnTickUpdateProcedure;
import net.ndkien.chemicraft.procedures.SmokeDetectorEmittedRedstonePowerProcedure;
import net.ndkien.chemicraft.procedures.RouterBlockAddedProcedure;

import net.minecraft.world.phys.shapes.VoxelShape;
import net.minecraft.world.phys.shapes.Shapes;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.util.RandomSource;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.core.Direction;
import net.minecraft.core.BlockPos;

public class SmokeDetectorBlock extends Block {
	private static final VoxelShape SHAPE = Shapes.or(box(0, 0, 0, 16, 2, 2), box(0, 0, 14, 16, 2, 16), box(0, 0, 2, 2, 2, 14), box(14, 0, 2, 16, 2, 14), box(5, 0, 5, 11, 2, 11), box(10, 0, 7, 14, 2, 9), box(2, 0, 3, 14, 2, 5), box(2, 0, 7, 6, 2, 9),
			box(2, 0, 11, 14, 2, 13), box(2, 0, 2, 14, 1, 14));

	public SmokeDetectorBlock(BlockBehaviour.Properties properties) {
		super(properties.sound(SoundType.METAL).strength(2f).noOcclusion().isRedstoneConductor((bs, br, bp) -> false));
	}

	@Override
	public VoxelShape getShape(BlockState state, BlockGetter world, BlockPos pos, CollisionContext context) {
		return SHAPE;
	}

	@Override
	public boolean propagatesSkylightDown(BlockState state) {
		return true;
	}

	@Override
	public int getLightDampening(BlockState state) {
		return 0;
	}

	@Override
	public VoxelShape getVisualShape(BlockState state, BlockGetter world, BlockPos pos, CollisionContext context) {
		return Shapes.empty();
	}

	@Override
	public boolean isSignalSource(BlockState state) {
		return true;
	}

	@Override
	public int getSignal(BlockState blockstate, BlockGetter blockAccess, BlockPos pos, Direction direction) {
		int x = pos.getX();
		int y = pos.getY();
		int z = pos.getZ();
		Level world = (Level) blockAccess;
		return (int) SmokeDetectorEmittedRedstonePowerProcedure.execute(world, x, y, z);
	}

	@Override
	public void onPlace(BlockState blockstate, Level world, BlockPos pos, BlockState oldState, boolean moving) {
		super.onPlace(blockstate, world, pos, oldState, moving);
		world.scheduleTick(pos, this, 1);
		RouterBlockAddedProcedure.execute(world, pos.getX(), pos.getY(), pos.getZ());
	}

	@Override
	public void tick(BlockState blockstate, ServerLevel world, BlockPos pos, RandomSource random) {
		super.tick(blockstate, world, pos, random);
		WeatherSensorOnTickUpdateProcedure.execute(world, pos.getX(), pos.getY(), pos.getZ());
		world.scheduleTick(pos, this, 1);
	}
}