package net.ndkien.chemicraft.block;

import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.Block;

public class DeepslateZirconOreBlock extends Block {
	public DeepslateZirconOreBlock(BlockBehaviour.Properties properties) {
		super(properties.strength(4.5f, 3f).requiresCorrectToolForDrops());
	}
}