package net.ndkien.chemicraft.block;

import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.Block;

public class BlockOfPhosphorusBlock extends Block {
	public BlockOfPhosphorusBlock(BlockBehaviour.Properties properties) {
		super(properties.strength(3f, 5f).requiresCorrectToolForDrops());
	}
}