package net.ndkien.chemicraft.block;

import net.minecraft.world.level.block.state.properties.NoteBlockInstrument;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.Block;

public class BlockOfSeleniumBlock extends Block {
	public BlockOfSeleniumBlock(BlockBehaviour.Properties properties) {
		super(properties.strength(4f, 5f).requiresCorrectToolForDrops().instrument(NoteBlockInstrument.BASEDRUM));
	}
}