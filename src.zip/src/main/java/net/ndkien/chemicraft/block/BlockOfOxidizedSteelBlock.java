package net.ndkien.chemicraft.block;

import net.minecraft.world.level.block.state.properties.NoteBlockInstrument;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.Block;

public class BlockOfOxidizedSteelBlock extends Block {
	public BlockOfOxidizedSteelBlock(BlockBehaviour.Properties properties) {
		super(properties.sound(SoundType.HEAVY_CORE).strength(7f, 8f).requiresCorrectToolForDrops().instrument(NoteBlockInstrument.IRON_XYLOPHONE));
	}
}