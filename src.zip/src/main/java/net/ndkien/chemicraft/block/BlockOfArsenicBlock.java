package net.ndkien.chemicraft.block;

import net.minecraft.world.level.block.state.properties.NoteBlockInstrument;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.Block;

public class BlockOfArsenicBlock extends Block {
	public BlockOfArsenicBlock(BlockBehaviour.Properties properties) {
		super(properties.strength(4f, 5f).requiresCorrectToolForDrops().instrument(NoteBlockInstrument.BASEDRUM));
	}
}