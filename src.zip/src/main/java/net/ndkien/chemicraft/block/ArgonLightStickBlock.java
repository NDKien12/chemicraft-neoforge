package net.ndkien.chemicraft.block;

import net.minecraft.world.phys.shapes.VoxelShape;
import net.minecraft.world.phys.shapes.Shapes;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.level.block.state.properties.EnumProperty;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.Rotation;
import net.minecraft.world.level.block.Mirror;
import net.minecraft.world.level.block.DirectionalBlock;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.core.Direction;
import net.minecraft.core.BlockPos;

import java.util.function.Function;

public class ArgonLightStickBlock extends Block {
	public static final EnumProperty<Direction> FACING = DirectionalBlock.FACING;
	private final Function<BlockState, VoxelShape> shapes = this.makeShapes();

	public ArgonLightStickBlock(BlockBehaviour.Properties properties) {
		super(properties.strength(2f).lightLevel(blockstate -> 2).noOcclusion().postProcess((bs, br, bp) -> bp).emissiveRendering((bs, br, bp) -> true).isRedstoneConductor((bs, br, bp) -> false));
		this.registerDefaultState(this.stateDefinition.any().setValue(FACING, Direction.NORTH));
	}

	private Function<BlockState, VoxelShape> makeShapes() {
		return this.getShapeForEachState(state -> {
			return switch (state.getValue(FACING)) {
				case NORTH -> Shapes.or(box(5, 5, 0, 11, 11, 2), box(5, 5, 14, 11, 11, 16), box(6, 6, 2, 10, 10, 14));
				case EAST -> Shapes.or(box(14, 5, 5, 16, 11, 11), box(0, 5, 5, 2, 11, 11), box(2, 6, 6, 14, 10, 10));
				case WEST -> Shapes.or(box(0, 5, 5, 2, 11, 11), box(14, 5, 5, 16, 11, 11), box(2, 6, 6, 14, 10, 10));
				case UP -> Shapes.or(box(5, 14, 5, 11, 16, 11), box(5, 0, 5, 11, 2, 11), box(6, 2, 6, 10, 14, 10));
				case DOWN -> Shapes.or(box(5, 0, 5, 11, 2, 11), box(5, 14, 5, 11, 16, 11), box(6, 2, 6, 10, 14, 10));
				default -> Shapes.or(box(5, 5, 14, 11, 11, 16), box(5, 5, 0, 11, 11, 2), box(6, 6, 2, 10, 10, 14));
			};
		});
	}

	@Override
	public VoxelShape getShape(BlockState state, BlockGetter world, BlockPos pos, CollisionContext context) {
		return shapes.apply(state);
	}

	@Override
	public VoxelShape getVisualShape(BlockState state, BlockGetter world, BlockPos pos, CollisionContext context) {
		return Shapes.empty();
	}

	@Override
	protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
		super.createBlockStateDefinition(builder);
		builder.add(FACING);
	}

	@Override
	public BlockState getStateForPlacement(BlockPlaceContext context) {
		BlockState state = super.getStateForPlacement(context);
		if (state == null)
			return null;
		return state.setValue(FACING, context.getClickedFace());
	}

	public BlockState rotate(BlockState state, Rotation rot) {
		return state.setValue(FACING, rot.rotate(state.getValue(FACING)));
	}

	public BlockState mirror(BlockState state, Mirror mirrorIn) {
		return state.rotate(mirrorIn.getRotation(state.getValue(FACING)));
	}
}