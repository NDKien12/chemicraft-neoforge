package net.ndkien.chemicraft.block;

import net.minecraft.world.level.block.state.properties.NoteBlockInstrument;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.Block;

public class BlockOfApatiteBlock extends Block {
	public BlockOfApatiteBlock(BlockBehaviour.Properties properties) {
		super(properties.sound(SoundType.METAL).strength(4.5f, 3f).requiresCorrectToolForDrops().instrument(NoteBlockInstrument.BIT));
	}
}