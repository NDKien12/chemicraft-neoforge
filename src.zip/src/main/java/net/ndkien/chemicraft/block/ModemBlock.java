package net.ndkien.chemicraft.block;

import net.ndkien.chemicraft.procedures.ModemRedstoneOnProcedure;
import net.ndkien.chemicraft.procedures.ModemOnBlockRightclickedProcedure;

import net.minecraft.world.phys.shapes.VoxelShape;
import net.minecraft.world.phys.shapes.Shapes;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.level.redstone.Orientation;
import net.minecraft.world.level.block.state.properties.IntegerProperty;
import net.minecraft.world.level.block.state.properties.EnumProperty;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.Rotation;
import net.minecraft.world.level.block.Mirror;
import net.minecraft.world.level.block.HorizontalDirectionalBlock;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.InteractionResult;
import net.minecraft.core.Direction;
import net.minecraft.core.BlockPos;

import javax.annotation.Nullable;

import java.util.function.Function;

public class ModemBlock extends Block {
	public static final EnumProperty<Direction> FACING = HorizontalDirectionalBlock.FACING;
	public static final IntegerProperty ID = IntegerProperty.create("id", 1, 4);
	private final Function<BlockState, VoxelShape> shapes = this.makeShapes();

	public ModemBlock(BlockBehaviour.Properties properties) {
		super(properties.sound(SoundType.METAL).strength(1.5f).noOcclusion().isRedstoneConductor((bs, br, bp) -> false));
		this.registerDefaultState(this.stateDefinition.any().setValue(FACING, Direction.NORTH).setValue(ID, 1));
	}

	private Function<BlockState, VoxelShape> makeShapes() {
		return this.getShapeForEachState(state -> {
			return switch (state.getValue(FACING)) {
				case NORTH -> Shapes.or(box(4, 0, 2, 6, 16, 14), box(10, 0, 2, 12, 16, 14), box(6, 0, 3, 10, 14, 13), box(9, 2, 3, 11, 4, 3.1), box(9, 5, 3, 11, 7, 3.1), box(9, 8, 3, 11, 10, 3.1), box(9, 11, 3, 11, 13, 3.1));
				case EAST -> Shapes.or(box(2, 0, 4, 14, 16, 6), box(2, 0, 10, 14, 16, 12), box(3, 0, 6, 13, 14, 10), box(12.9, 2, 9, 13, 4, 11), box(12.9, 5, 9, 13, 7, 11), box(12.9, 8, 9, 13, 10, 11), box(12.9, 11, 9, 13, 13, 11));
				case WEST -> Shapes.or(box(2, 0, 10, 14, 16, 12), box(2, 0, 4, 14, 16, 6), box(3, 0, 6, 13, 14, 10), box(3, 2, 5, 3.1, 4, 7), box(3, 5, 5, 3.1, 7, 7), box(3, 8, 5, 3.1, 10, 7), box(3, 11, 5, 3.1, 13, 7));
				default -> Shapes.or(box(10, 0, 2, 12, 16, 14), box(4, 0, 2, 6, 16, 14), box(6, 0, 3, 10, 14, 13), box(5, 2, 12.9, 7, 4, 13), box(5, 5, 12.9, 7, 7, 13), box(5, 8, 12.9, 7, 10, 13), box(5, 11, 12.9, 7, 13, 13));
			};
		});
	}

	@Override
	public VoxelShape getShape(BlockState state, BlockGetter world, BlockPos pos, CollisionContext context) {
		return shapes.apply(state);
	}

	@Override
	public boolean propagatesSkylightDown(BlockState state) {
		return true;
	}

	@Override
	public int getLightDampening(BlockState state) {
		return 0;
	}

	@Override
	public VoxelShape getVisualShape(BlockState state, BlockGetter world, BlockPos pos, CollisionContext context) {
		return Shapes.empty();
	}

	@Override
	protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
		super.createBlockStateDefinition(builder);
		builder.add(FACING, ID);
	}

	@Override
	public BlockState getStateForPlacement(BlockPlaceContext context) {
		BlockState state = super.getStateForPlacement(context);
		if (state == null)
			return null;
		return state.setValue(FACING, context.getHorizontalDirection().getOpposite()).setValue(ID, 1);
	}

	public BlockState rotate(BlockState state, Rotation rot) {
		return state.setValue(FACING, rot.rotate(state.getValue(FACING)));
	}

	public BlockState mirror(BlockState state, Mirror mirrorIn) {
		return state.rotate(mirrorIn.getRotation(state.getValue(FACING)));
	}

	@Override
	public void neighborChanged(BlockState blockstate, Level world, BlockPos pos, Block neighborBlock, @Nullable Orientation orientation, boolean moving) {
		super.neighborChanged(blockstate, world, pos, neighborBlock, orientation, moving);
		if (world.getBestNeighborSignal(pos) > 0) {
			ModemRedstoneOnProcedure.execute(world, pos.getX(), pos.getY(), pos.getZ(), blockstate);
		}
	}

	@Override
	public InteractionResult useWithoutItem(BlockState blockstate, Level world, BlockPos pos, Player entity, BlockHitResult hit) {
		super.useWithoutItem(blockstate, world, pos, entity, hit);
		int x = pos.getX();
		int y = pos.getY();
		int z = pos.getZ();
		double hitX = hit.getLocation().x;
		double hitY = hit.getLocation().y;
		double hitZ = hit.getLocation().z;
		Direction direction = hit.getDirection();
		ModemOnBlockRightclickedProcedure.execute(world, x, y, z, blockstate);
		return InteractionResult.SUCCESS;
	}
}