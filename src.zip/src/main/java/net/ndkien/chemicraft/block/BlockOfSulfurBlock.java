package net.ndkien.chemicraft.block;

import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.Block;

public class BlockOfSulfurBlock extends Block {
	public BlockOfSulfurBlock(BlockBehaviour.Properties properties) {
		super(properties.strength(4f, 5f).requiresCorrectToolForDrops());
	}
}