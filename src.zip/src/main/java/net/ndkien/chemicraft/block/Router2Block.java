package net.ndkien.chemicraft.block;

import net.ndkien.chemicraft.procedures.RouterOnBlockRightclickedProcedure;
import net.ndkien.chemicraft.procedures.RouterEmittedRedstonePowerProcedure;
import net.ndkien.chemicraft.procedures.RouterBlockAddedProcedure;
import net.ndkien.chemicraft.init.ChemicraftModBlocks;

import net.minecraft.world.phys.shapes.VoxelShape;
import net.minecraft.world.phys.shapes.Shapes;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.level.block.state.properties.EnumProperty;
import net.minecraft.world.level.block.state.properties.BooleanProperty;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.Rotation;
import net.minecraft.world.level.block.Mirror;
import net.minecraft.world.level.block.HorizontalDirectionalBlock;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.LevelReader;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.InteractionResult;
import net.minecraft.core.Direction;
import net.minecraft.core.BlockPos;

import java.util.function.Function;

public class Router2Block extends Block {
	public static final EnumProperty<Direction> FACING = HorizontalDirectionalBlock.FACING;
	public static final BooleanProperty ON = BooleanProperty.create("on");
	private final Function<BlockState, VoxelShape> shapes = this.makeShapes();

	public Router2Block(BlockBehaviour.Properties properties) {
		super(properties.sound(SoundType.METAL).strength(1.5f).noOcclusion().isRedstoneConductor((bs, br, bp) -> false));
		this.registerDefaultState(this.stateDefinition.any().setValue(FACING, Direction.NORTH).setValue(ON, false));
	}

	private Function<BlockState, VoxelShape> makeShapes() {
		return this.getShapeForEachState(state -> {
			return switch (state.getValue(FACING)) {
				case NORTH -> Shapes.or(box(0, 0, 0, 16, 2, 16), box(0, 2, 0, 2, 16, 2), box(14, 2, 0, 16, 16, 2), box(10, 0, 0, 12, 14, 2), box(4, 0, 0, 6, 14, 2), box(1, 2, 14, 3, 2.01, 16), box(5, 2, 14, 7, 2.01, 16), box(9, 2, 14, 11, 2.01, 16),
						box(13, 2, 14, 15, 2.01, 16));
				case EAST -> Shapes.or(box(0, 0, 0, 16, 2, 16), box(14, 2, 0, 16, 16, 2), box(14, 2, 14, 16, 16, 16), box(14, 0, 10, 16, 14, 12), box(14, 0, 4, 16, 14, 6), box(0, 2, 1, 2, 2.01, 3), box(0, 2, 5, 2, 2.01, 7), box(0, 2, 9, 2, 2.01, 11),
						box(0, 2, 13, 2, 2.01, 15));
				case WEST -> Shapes.or(box(0, 0, 0, 16, 2, 16), box(0, 2, 14, 2, 16, 16), box(0, 2, 0, 2, 16, 2), box(0, 0, 4, 2, 14, 6), box(0, 0, 10, 2, 14, 12), box(14, 2, 13, 16, 2.01, 15), box(14, 2, 9, 16, 2.01, 11), box(14, 2, 5, 16, 2.01, 7),
						box(14, 2, 1, 16, 2.01, 3));
				default -> Shapes.or(box(0, 0, 0, 16, 2, 16), box(14, 2, 14, 16, 16, 16), box(0, 2, 14, 2, 16, 16), box(4, 0, 14, 6, 14, 16), box(10, 0, 14, 12, 14, 16), box(13, 2, 0, 15, 2.01, 2), box(9, 2, 0, 11, 2.01, 2), box(5, 2, 0, 7, 2.01, 2),
						box(1, 2, 0, 3, 2.01, 2));
			};
		}, ON);
	}

	@Override
	public VoxelShape getShape(BlockState state, BlockGetter world, BlockPos pos, CollisionContext context) {
		return shapes.apply(state);
	}

	@Override
	public boolean propagatesSkylightDown(BlockState state) {
		return true;
	}

	@Override
	public int getLightDampening(BlockState state) {
		return 0;
	}

	@Override
	public VoxelShape getVisualShape(BlockState state, BlockGetter world, BlockPos pos, CollisionContext context) {
		return Shapes.empty();
	}

	@Override
	protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
		super.createBlockStateDefinition(builder);
		builder.add(FACING, ON);
	}

	@Override
	public BlockState getStateForPlacement(BlockPlaceContext context) {
		BlockState state = super.getStateForPlacement(context);
		if (state == null)
			return null;
		return state.setValue(FACING, context.getHorizontalDirection().getOpposite()).setValue(ON, false);
	}

	public BlockState rotate(BlockState state, Rotation rot) {
		return state.setValue(FACING, rot.rotate(state.getValue(FACING)));
	}

	public BlockState mirror(BlockState state, Mirror mirrorIn) {
		return state.rotate(mirrorIn.getRotation(state.getValue(FACING)));
	}

	@Override
	public boolean isSignalSource(BlockState state) {
		return true;
	}

	@Override
	public int getSignal(BlockState blockstate, BlockGetter blockAccess, BlockPos pos, Direction direction) {
		int x = pos.getX();
		int y = pos.getY();
		int z = pos.getZ();
		Level world = (Level) blockAccess;
		return (int) RouterEmittedRedstonePowerProcedure.execute(world, x, y, z, blockstate);
	}

	@Override
	public ItemStack getCloneItemStack(LevelReader world, BlockPos pos, BlockState state, boolean includeData, Player entity) {
		return new ItemStack(ChemicraftModBlocks.ROUTER.get());
	}

	@Override
	public void onPlace(BlockState blockstate, Level world, BlockPos pos, BlockState oldState, boolean moving) {
		super.onPlace(blockstate, world, pos, oldState, moving);
		RouterBlockAddedProcedure.execute(world, pos.getX(), pos.getY(), pos.getZ());
	}

	@Override
	public InteractionResult useWithoutItem(BlockState blockstate, Level world, BlockPos pos, Player entity, BlockHitResult hit) {
		super.useWithoutItem(blockstate, world, pos, entity, hit);
		int x = pos.getX();
		int y = pos.getY();
		int z = pos.getZ();
		double hitX = hit.getLocation().x;
		double hitY = hit.getLocation().y;
		double hitZ = hit.getLocation().z;
		Direction direction = hit.getDirection();
		RouterOnBlockRightclickedProcedure.execute(world, x, y, z);
		return InteractionResult.SUCCESS;
	}
}