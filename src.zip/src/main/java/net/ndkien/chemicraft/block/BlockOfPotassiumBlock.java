package net.ndkien.chemicraft.block;

import net.ndkien.chemicraft.procedures.BlockOfLithiumBlockAddedProcedure;

import net.minecraft.world.level.block.state.properties.NoteBlockInstrument;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.Level;
import net.minecraft.core.BlockPos;

public class BlockOfPotassiumBlock extends Block {
	public BlockOfPotassiumBlock(BlockBehaviour.Properties properties) {
		super(properties.sound(SoundType.METAL).strength(2f).requiresCorrectToolForDrops().instrument(NoteBlockInstrument.IRON_XYLOPHONE));
	}

	@Override
	public void onPlace(BlockState blockstate, Level world, BlockPos pos, BlockState oldState, boolean moving) {
		super.onPlace(blockstate, world, pos, oldState, moving);
		BlockOfLithiumBlockAddedProcedure.execute(world, pos.getX(), pos.getY(), pos.getZ());
	}
}