package net.ndkien.chemicraft.item;

import net.minecraft.world.item.Item;

public class NiobiumIngotItem extends Item {
	public NiobiumIngotItem(Item.Properties properties) {
		super(properties);
	}
}