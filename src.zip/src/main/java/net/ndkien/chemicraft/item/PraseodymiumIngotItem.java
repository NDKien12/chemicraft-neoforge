package net.ndkien.chemicraft.item;

import net.minecraft.world.item.Item;

public class PraseodymiumIngotItem extends Item {
	public PraseodymiumIngotItem(Item.Properties properties) {
		super(properties);
	}
}