package net.ndkien.chemicraft.item;

import net.minecraft.world.item.Item;

public class DarmstadtiumItem extends Item {
	public DarmstadtiumItem(Item.Properties properties) {
		super(properties);
	}
}