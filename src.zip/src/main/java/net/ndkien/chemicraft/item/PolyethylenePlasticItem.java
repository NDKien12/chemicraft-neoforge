package net.ndkien.chemicraft.item;

import net.minecraft.world.item.Item;

public class PolyethylenePlasticItem extends Item {
	public PolyethylenePlasticItem(Item.Properties properties) {
		super(properties);
	}
}