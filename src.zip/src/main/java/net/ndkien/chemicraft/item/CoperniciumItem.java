package net.ndkien.chemicraft.item;

import net.minecraft.world.item.Item;

public class CoperniciumItem extends Item {
	public CoperniciumItem(Item.Properties properties) {
		super(properties);
	}
}