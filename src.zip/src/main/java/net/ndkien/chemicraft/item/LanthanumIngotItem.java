package net.ndkien.chemicraft.item;

import net.minecraft.world.item.Item;

public class LanthanumIngotItem extends Item {
	public LanthanumIngotItem(Item.Properties properties) {
		super(properties);
	}
}