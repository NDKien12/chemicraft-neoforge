package net.ndkien.chemicraft.item;

import net.minecraft.world.item.Item;

public class IlmeniteItem extends Item {
	public IlmeniteItem(Item.Properties properties) {
		super(properties);
	}
}