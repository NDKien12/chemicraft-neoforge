package net.ndkien.chemicraft.item;

import net.minecraft.world.item.Item;

public class NTypeSemiconductorItem extends Item {
	public NTypeSemiconductorItem(Item.Properties properties) {
		super(properties);
	}
}