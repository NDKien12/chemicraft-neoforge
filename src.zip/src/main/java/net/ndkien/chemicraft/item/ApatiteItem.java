package net.ndkien.chemicraft.item;

import net.minecraft.world.item.Item;

public class ApatiteItem extends Item {
	public ApatiteItem(Item.Properties properties) {
		super(properties);
	}
}