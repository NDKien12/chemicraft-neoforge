package net.ndkien.chemicraft.item;

import net.minecraft.world.item.Item;

public class LutetiumIngotItem extends Item {
	public LutetiumIngotItem(Item.Properties properties) {
		super(properties);
	}
}