package net.ndkien.chemicraft.item;

import net.minecraft.world.item.Item;

public class YtterbiumIngotItem extends Item {
	public YtterbiumIngotItem(Item.Properties properties) {
		super(properties);
	}
}