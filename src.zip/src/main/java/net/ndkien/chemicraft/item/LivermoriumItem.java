package net.ndkien.chemicraft.item;

import net.minecraft.world.item.Item;

public class LivermoriumItem extends Item {
	public LivermoriumItem(Item.Properties properties) {
		super(properties);
	}
}