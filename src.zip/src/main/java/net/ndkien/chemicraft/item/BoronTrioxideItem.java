package net.ndkien.chemicraft.item;

import net.minecraft.world.item.Item;

public class BoronTrioxideItem extends Item {
	public BoronTrioxideItem(Item.Properties properties) {
		super(properties);
	}
}