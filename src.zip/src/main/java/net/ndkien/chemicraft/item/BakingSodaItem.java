package net.ndkien.chemicraft.item;

import net.minecraft.world.item.Item;

public class BakingSodaItem extends Item {
	public BakingSodaItem(Item.Properties properties) {
		super(properties);
	}
}