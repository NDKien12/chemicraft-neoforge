package net.ndkien.chemicraft.item;

import net.minecraft.world.item.Item;

public class OsmiumIngotItem extends Item {
	public OsmiumIngotItem(Item.Properties properties) {
		super(properties);
	}
}