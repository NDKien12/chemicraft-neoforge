package net.ndkien.chemicraft.item;

import net.minecraft.world.item.Item;

public class ResistorItem extends Item {
	public ResistorItem(Item.Properties properties) {
		super(properties);
	}
}