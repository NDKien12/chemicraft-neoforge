package net.ndkien.chemicraft.item;

import net.minecraft.world.item.Item;

public class PotashLyeItem extends Item {
	public PotashLyeItem(Item.Properties properties) {
		super(properties);
	}
}