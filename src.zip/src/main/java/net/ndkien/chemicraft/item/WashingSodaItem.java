package net.ndkien.chemicraft.item;

import net.minecraft.world.item.Item;

public class WashingSodaItem extends Item {
	public WashingSodaItem(Item.Properties properties) {
		super(properties);
	}
}