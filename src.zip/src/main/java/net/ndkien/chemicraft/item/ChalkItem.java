package net.ndkien.chemicraft.item;

import net.minecraft.world.item.Item;

public class ChalkItem extends Item {
	public ChalkItem(Item.Properties properties) {
		super(properties);
	}
}