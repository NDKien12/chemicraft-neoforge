package net.ndkien.chemicraft.item;

import net.minecraft.world.item.Item;

public class NobeliumItem extends Item {
	public NobeliumItem(Item.Properties properties) {
		super(properties);
	}
}