package net.ndkien.chemicraft.item;

import net.minecraft.world.item.Item;

public class RheniiteItem extends Item {
	public RheniiteItem(Item.Properties properties) {
		super(properties);
	}
}