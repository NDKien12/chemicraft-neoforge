package net.ndkien.chemicraft.item;

import net.minecraft.world.item.Item;

public class BismuthIngotItem extends Item {
	public BismuthIngotItem(Item.Properties properties) {
		super(properties);
	}
}