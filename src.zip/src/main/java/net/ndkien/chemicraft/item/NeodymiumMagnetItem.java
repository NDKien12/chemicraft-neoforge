package net.ndkien.chemicraft.item;

import net.minecraft.world.item.Item;

public class NeodymiumMagnetItem extends Item {
	public NeodymiumMagnetItem(Item.Properties properties) {
		super(properties);
	}
}