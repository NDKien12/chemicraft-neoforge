package net.ndkien.chemicraft.item;

import net.minecraft.world.item.Item;

public class PhosphorusItem extends Item {
	public PhosphorusItem(Item.Properties properties) {
		super(properties);
	}
}