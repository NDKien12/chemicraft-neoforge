package net.ndkien.chemicraft.item;

import net.minecraft.world.item.Item;

public class GalenaItem extends Item {
	public GalenaItem(Item.Properties properties) {
		super(properties);
	}
}