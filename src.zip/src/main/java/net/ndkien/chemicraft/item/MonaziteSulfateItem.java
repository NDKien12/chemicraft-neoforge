package net.ndkien.chemicraft.item;

import net.minecraft.world.item.Item;

public class MonaziteSulfateItem extends Item {
	public MonaziteSulfateItem(Item.Properties properties) {
		super(properties);
	}
}