package net.ndkien.chemicraft.item;

import net.minecraft.world.item.Item;

public class SensorMicrochipItem extends Item {
	public SensorMicrochipItem(Item.Properties properties) {
		super(properties);
	}
}