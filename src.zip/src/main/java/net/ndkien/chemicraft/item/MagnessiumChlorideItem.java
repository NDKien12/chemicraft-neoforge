package net.ndkien.chemicraft.item;

import net.minecraft.world.item.Item;

public class MagnessiumChlorideItem extends Item {
	public MagnessiumChlorideItem(Item.Properties properties) {
		super(properties);
	}
}