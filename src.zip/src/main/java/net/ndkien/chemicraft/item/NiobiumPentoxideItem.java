package net.ndkien.chemicraft.item;

import net.minecraft.world.item.Item;

public class NiobiumPentoxideItem extends Item {
	public NiobiumPentoxideItem(Item.Properties properties) {
		super(properties);
	}
}