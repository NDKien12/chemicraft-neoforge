package net.ndkien.chemicraft.item;

import net.minecraft.world.item.Item;

public class CalciumItem extends Item {
	public CalciumItem(Item.Properties properties) {
		super(properties);
	}
}