package net.ndkien.chemicraft.item;

import net.minecraft.world.item.Item;

public class SamariumIngotItem extends Item {
	public SamariumIngotItem(Item.Properties properties) {
		super(properties);
	}
}