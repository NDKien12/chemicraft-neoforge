package net.ndkien.chemicraft.item;

import net.minecraft.world.item.Item;

public class TinIngotItem extends Item {
	public TinIngotItem(Item.Properties properties) {
		super(properties);
	}
}