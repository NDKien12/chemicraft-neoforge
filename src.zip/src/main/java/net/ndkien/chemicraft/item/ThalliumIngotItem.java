package net.ndkien.chemicraft.item;

import net.minecraft.world.item.Item;

public class ThalliumIngotItem extends Item {
	public ThalliumIngotItem(Item.Properties properties) {
		super(properties);
	}
}