package net.ndkien.chemicraft.item;

import net.minecraft.world.item.Item;

public class SodiumIngotItem extends Item {
	public SodiumIngotItem(Item.Properties properties) {
		super(properties);
	}
}