package net.ndkien.chemicraft.item;

import net.minecraft.world.item.Item;

public class LeadIngotItem extends Item {
	public LeadIngotItem(Item.Properties properties) {
		super(properties);
	}
}