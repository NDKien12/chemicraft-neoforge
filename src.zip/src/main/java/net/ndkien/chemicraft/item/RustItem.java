package net.ndkien.chemicraft.item;

import net.minecraft.world.item.Item;

public class RustItem extends Item {
	public RustItem(Item.Properties properties) {
		super(properties);
	}
}