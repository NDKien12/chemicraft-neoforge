package net.ndkien.chemicraft.item;

import net.minecraft.world.item.Item;

public class HaliteItem extends Item {
	public HaliteItem(Item.Properties properties) {
		super(properties);
	}
}