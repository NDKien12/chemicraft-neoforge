package net.ndkien.chemicraft.item;

import net.minecraft.world.item.Item;

public class BerkeliumNuggetItem extends Item {
	public BerkeliumNuggetItem(Item.Properties properties) {
		super(properties);
	}
}