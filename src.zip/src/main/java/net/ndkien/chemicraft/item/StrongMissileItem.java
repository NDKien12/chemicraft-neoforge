package net.ndkien.chemicraft.item;

import net.minecraft.world.item.Item;

public class StrongMissileItem extends Item {
	public StrongMissileItem(Item.Properties properties) {
		super(properties);
	}
}