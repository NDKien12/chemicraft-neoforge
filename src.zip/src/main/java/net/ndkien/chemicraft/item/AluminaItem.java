package net.ndkien.chemicraft.item;

import net.minecraft.world.item.Item;

public class AluminaItem extends Item {
	public AluminaItem(Item.Properties properties) {
		super(properties);
	}
}