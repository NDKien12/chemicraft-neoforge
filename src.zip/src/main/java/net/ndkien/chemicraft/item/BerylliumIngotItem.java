package net.ndkien.chemicraft.item;

import net.minecraft.world.item.Item;

public class BerylliumIngotItem extends Item {
	public BerylliumIngotItem(Item.Properties properties) {
		super(properties);
	}
}