package net.ndkien.chemicraft.item;

import net.minecraft.world.item.Item;

public class LithiumIonBatteryItem extends Item {
	public LithiumIonBatteryItem(Item.Properties properties) {
		super(properties);
	}
}