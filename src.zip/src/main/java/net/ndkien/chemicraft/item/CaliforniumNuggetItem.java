package net.ndkien.chemicraft.item;

import net.minecraft.world.item.Item;

public class CaliforniumNuggetItem extends Item {
	public CaliforniumNuggetItem(Item.Properties properties) {
		super(properties);
	}
}