package net.ndkien.chemicraft.item;

import net.minecraft.world.item.Item;

public class EinsteiniumNuggetItem extends Item {
	public EinsteiniumNuggetItem(Item.Properties properties) {
		super(properties);
	}
}