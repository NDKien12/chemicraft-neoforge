package net.ndkien.chemicraft.item;

import net.minecraft.world.item.Item;

public class SodiumBromideItem extends Item {
	public SodiumBromideItem(Item.Properties properties) {
		super(properties);
	}
}