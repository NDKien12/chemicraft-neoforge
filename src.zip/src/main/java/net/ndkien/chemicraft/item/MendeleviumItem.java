package net.ndkien.chemicraft.item;

import net.minecraft.world.item.Item;

public class MendeleviumItem extends Item {
	public MendeleviumItem(Item.Properties properties) {
		super(properties);
	}
}