package net.ndkien.chemicraft.item;

import net.minecraft.world.item.Item;

public class DiodeItem extends Item {
	public DiodeItem(Item.Properties properties) {
		super(properties);
	}
}