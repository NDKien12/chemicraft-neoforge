package net.ndkien.chemicraft.item;

import net.minecraft.world.item.Item;

public class MonaziteHydroxideItem extends Item {
	public MonaziteHydroxideItem(Item.Properties properties) {
		super(properties);
	}
}