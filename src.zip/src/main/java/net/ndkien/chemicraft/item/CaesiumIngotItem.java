package net.ndkien.chemicraft.item;

import net.minecraft.world.item.Item;

public class CaesiumIngotItem extends Item {
	public CaesiumIngotItem(Item.Properties properties) {
		super(properties);
	}
}