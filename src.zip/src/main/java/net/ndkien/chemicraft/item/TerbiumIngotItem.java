package net.ndkien.chemicraft.item;

import net.minecraft.world.item.Item;

public class TerbiumIngotItem extends Item {
	public TerbiumIngotItem(Item.Properties properties) {
		super(properties);
	}
}