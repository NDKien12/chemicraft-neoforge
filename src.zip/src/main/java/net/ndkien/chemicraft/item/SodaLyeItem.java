package net.ndkien.chemicraft.item;

import net.minecraft.world.item.Item;

public class SodaLyeItem extends Item {
	public SodaLyeItem(Item.Properties properties) {
		super(properties);
	}
}