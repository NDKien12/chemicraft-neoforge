package net.ndkien.chemicraft.item;

import net.minecraft.world.item.Item;

public class VanadiumIngotItem extends Item {
	public VanadiumIngotItem(Item.Properties properties) {
		super(properties);
	}
}