package net.ndkien.chemicraft.item;

import net.minecraft.world.item.Item;

public class ThulliumIngotItem extends Item {
	public ThulliumIngotItem(Item.Properties properties) {
		super(properties);
	}
}