package net.ndkien.chemicraft.item;

import net.minecraft.world.item.Item;

public class MercuryBottleItem extends Item {
	public MercuryBottleItem(Item.Properties properties) {
		super(properties.stacksTo(16));
	}
}