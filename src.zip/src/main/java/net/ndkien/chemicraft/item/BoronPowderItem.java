package net.ndkien.chemicraft.item;

import net.minecraft.world.item.Item;

public class BoronPowderItem extends Item {
	public BoronPowderItem(Item.Properties properties) {
		super(properties);
	}
}