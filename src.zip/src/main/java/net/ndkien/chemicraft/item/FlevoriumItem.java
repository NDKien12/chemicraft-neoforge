package net.ndkien.chemicraft.item;

import net.minecraft.world.item.Item;

public class FlevoriumItem extends Item {
	public FlevoriumItem(Item.Properties properties) {
		super(properties);
	}
}