package net.ndkien.chemicraft.item;

import net.minecraft.world.item.Item;

public class CuriumNuggetItem extends Item {
	public CuriumNuggetItem(Item.Properties properties) {
		super(properties);
	}
}