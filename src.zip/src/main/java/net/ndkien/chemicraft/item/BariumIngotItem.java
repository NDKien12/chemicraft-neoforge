package net.ndkien.chemicraft.item;

import net.minecraft.world.item.Item;

public class BariumIngotItem extends Item {
	public BariumIngotItem(Item.Properties properties) {
		super(properties);
	}
}