package net.ndkien.chemicraft.item;

import net.minecraft.world.item.Item;

public class SilverIngotItem extends Item {
	public SilverIngotItem(Item.Properties properties) {
		super(properties);
	}
}