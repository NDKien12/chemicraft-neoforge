package net.ndkien.chemicraft.item;

import net.minecraft.world.item.Item;

public class RubidiumIngotItem extends Item {
	public RubidiumIngotItem(Item.Properties properties) {
		super(properties);
	}
}