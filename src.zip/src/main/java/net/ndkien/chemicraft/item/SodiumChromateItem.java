package net.ndkien.chemicraft.item;

import net.minecraft.world.item.Item;

public class SodiumChromateItem extends Item {
	public SodiumChromateItem(Item.Properties properties) {
		super(properties);
	}
}