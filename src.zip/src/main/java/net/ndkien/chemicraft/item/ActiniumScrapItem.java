package net.ndkien.chemicraft.item;

import net.minecraft.world.item.Item;

public class ActiniumScrapItem extends Item {
	public ActiniumScrapItem(Item.Properties properties) {
		super(properties);
	}
}