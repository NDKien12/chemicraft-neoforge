package net.ndkien.chemicraft.item;

import net.minecraft.world.item.Item;

public class RadiumScrapItem extends Item {
	public RadiumScrapItem(Item.Properties properties) {
		super(properties);
	}
}