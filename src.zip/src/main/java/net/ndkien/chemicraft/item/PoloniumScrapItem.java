package net.ndkien.chemicraft.item;

import net.minecraft.world.item.Item;

public class PoloniumScrapItem extends Item {
	public PoloniumScrapItem(Item.Properties properties) {
		super(properties);
	}
}