package net.ndkien.chemicraft.item;

import net.ndkien.chemicraft.procedures.BladeRightclickedProcedure;

import net.minecraft.world.level.Level;
import net.minecraft.world.item.Item;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.InteractionHand;

public class BladeItem extends Item {
	public BladeItem(Item.Properties properties) {
		super(properties);
	}

	@Override
	public InteractionResult use(Level world, Player entity, InteractionHand hand) {
		InteractionResult ar = super.use(world, entity, hand);
		BladeRightclickedProcedure.execute(entity);
		return ar;
	}
}