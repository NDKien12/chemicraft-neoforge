package net.ndkien.chemicraft.item;

import net.minecraft.world.item.Item;

public class MoscoviumItem extends Item {
	public MoscoviumItem(Item.Properties properties) {
		super(properties);
	}
}