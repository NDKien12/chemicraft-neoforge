package net.ndkien.chemicraft.item;

import net.minecraft.world.item.Item;

public class AluminumIngotItem extends Item {
	public AluminumIngotItem(Item.Properties properties) {
		super(properties);
	}
}