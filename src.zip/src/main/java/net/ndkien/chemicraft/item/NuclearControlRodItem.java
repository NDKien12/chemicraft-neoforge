package net.ndkien.chemicraft.item;

import net.minecraft.world.item.Item;

public class NuclearControlRodItem extends Item {
	public NuclearControlRodItem(Item.Properties properties) {
		super(properties);
	}
}