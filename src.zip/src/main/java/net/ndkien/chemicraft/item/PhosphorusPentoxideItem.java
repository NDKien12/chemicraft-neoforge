package net.ndkien.chemicraft.item;

import net.minecraft.world.item.Item;

public class PhosphorusPentoxideItem extends Item {
	public PhosphorusPentoxideItem(Item.Properties properties) {
		super(properties);
	}
}