package net.ndkien.chemicraft.item;

import net.minecraft.world.item.Item;

public class NeodymiumIngotItem extends Item {
	public NeodymiumIngotItem(Item.Properties properties) {
		super(properties);
	}
}