package net.ndkien.chemicraft.item;

import net.minecraft.world.item.Item;

public class NuclearFuelRodItem extends Item {
	public NuclearFuelRodItem(Item.Properties properties) {
		super(properties);
	}
}