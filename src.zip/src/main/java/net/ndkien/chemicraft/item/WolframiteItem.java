package net.ndkien.chemicraft.item;

import net.minecraft.world.item.Item;

public class WolframiteItem extends Item {
	public WolframiteItem(Item.Properties properties) {
		super(properties);
	}
}