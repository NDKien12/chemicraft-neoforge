package net.ndkien.chemicraft.item;

import net.minecraft.world.item.Item;

public class RAMItem extends Item {
	public RAMItem(Item.Properties properties) {
		super(properties);
	}
}