package net.ndkien.chemicraft.item;

import net.minecraft.world.item.Item;

public class XenotimeItem extends Item {
	public XenotimeItem(Item.Properties properties) {
		super(properties);
	}
}