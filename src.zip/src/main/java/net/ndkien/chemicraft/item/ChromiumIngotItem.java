package net.ndkien.chemicraft.item;

import net.minecraft.world.item.Item;

public class ChromiumIngotItem extends Item {
	public ChromiumIngotItem(Item.Properties properties) {
		super(properties);
	}
}