package net.ndkien.chemicraft.item;

import net.minecraft.world.item.Item;

public class PromethiumNuggetItem extends Item {
	public PromethiumNuggetItem(Item.Properties properties) {
		super(properties);
	}
}