package net.ndkien.chemicraft.item;

import net.minecraft.world.item.Item;

public class BoraxItem extends Item {
	public BoraxItem(Item.Properties properties) {
		super(properties);
	}
}