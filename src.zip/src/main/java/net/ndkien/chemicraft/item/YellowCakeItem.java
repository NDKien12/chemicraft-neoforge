package net.ndkien.chemicraft.item;

import net.minecraft.world.item.Item;

public class YellowCakeItem extends Item {
	public YellowCakeItem(Item.Properties properties) {
		super(properties);
	}
}