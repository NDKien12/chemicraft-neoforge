package net.ndkien.chemicraft.item;

import net.minecraft.world.item.Item;

public class GermaniumItem extends Item {
	public GermaniumItem(Item.Properties properties) {
		super(properties);
	}
}