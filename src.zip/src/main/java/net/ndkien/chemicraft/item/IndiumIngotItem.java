package net.ndkien.chemicraft.item;

import net.minecraft.world.item.Item;

public class IndiumIngotItem extends Item {
	public IndiumIngotItem(Item.Properties properties) {
		super(properties);
	}
}