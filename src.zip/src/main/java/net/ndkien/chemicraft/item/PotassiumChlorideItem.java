package net.ndkien.chemicraft.item;

import net.minecraft.world.item.Item;

public class PotassiumChlorideItem extends Item {
	public PotassiumChlorideItem(Item.Properties properties) {
		super(properties);
	}
}