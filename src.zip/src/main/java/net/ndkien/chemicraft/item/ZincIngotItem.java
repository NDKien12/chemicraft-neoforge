package net.ndkien.chemicraft.item;

import net.minecraft.world.item.Item;

public class ZincIngotItem extends Item {
	public ZincIngotItem(Item.Properties properties) {
		super(properties);
	}
}