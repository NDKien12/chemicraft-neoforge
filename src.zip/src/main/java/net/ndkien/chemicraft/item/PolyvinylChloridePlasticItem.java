package net.ndkien.chemicraft.item;

import net.minecraft.world.item.Item;

public class PolyvinylChloridePlasticItem extends Item {
	public PolyvinylChloridePlasticItem(Item.Properties properties) {
		super(properties);
	}
}