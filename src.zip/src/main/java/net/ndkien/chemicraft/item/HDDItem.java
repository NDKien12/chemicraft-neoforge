package net.ndkien.chemicraft.item;

import net.minecraft.world.item.Item;

public class HDDItem extends Item {
	public HDDItem(Item.Properties properties) {
		super(properties);
	}
}