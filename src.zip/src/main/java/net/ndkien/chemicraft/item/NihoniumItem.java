package net.ndkien.chemicraft.item;

import net.minecraft.world.item.Item;

public class NihoniumItem extends Item {
	public NihoniumItem(Item.Properties properties) {
		super(properties);
	}
}