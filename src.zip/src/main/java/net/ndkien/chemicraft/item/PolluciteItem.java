package net.ndkien.chemicraft.item;

import net.minecraft.world.item.Item;

public class PolluciteItem extends Item {
	public PolluciteItem(Item.Properties properties) {
		super(properties);
	}
}