package net.ndkien.chemicraft.item;

import net.minecraft.world.item.Item;

public class ManganeseIngotItem extends Item {
	public ManganeseIngotItem(Item.Properties properties) {
		super(properties);
	}
}