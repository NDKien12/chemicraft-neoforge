package net.ndkien.chemicraft.item;

import net.minecraft.world.item.Item;

public class MissileItem extends Item {
	public MissileItem(Item.Properties properties) {
		super(properties);
	}
}