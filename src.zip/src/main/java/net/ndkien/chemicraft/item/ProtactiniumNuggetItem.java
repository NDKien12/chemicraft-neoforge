package net.ndkien.chemicraft.item;

import net.minecraft.world.item.Item;

public class ProtactiniumNuggetItem extends Item {
	public ProtactiniumNuggetItem(Item.Properties properties) {
		super(properties);
	}
}