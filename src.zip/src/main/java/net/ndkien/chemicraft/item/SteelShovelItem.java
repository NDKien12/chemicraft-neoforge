package net.ndkien.chemicraft.item;

import net.minecraft.world.item.ToolMaterial;
import net.minecraft.world.item.ShovelItem;
import net.minecraft.world.item.Item;
import net.minecraft.tags.TagKey;
import net.minecraft.tags.BlockTags;
import net.minecraft.resources.Identifier;
import net.minecraft.core.registries.Registries;

public class SteelShovelItem extends ShovelItem {
	private static final ToolMaterial TOOL_MATERIAL = new ToolMaterial(BlockTags.INCORRECT_FOR_IRON_TOOL, 500, 6f, 0, 16, TagKey.create(Registries.ITEM, Identifier.parse("chemicraft:steel_shovel_repair_items")));

	public SteelShovelItem(Item.Properties properties) {
		super(TOOL_MATERIAL, 3.5f, -3f, properties);
	}
}