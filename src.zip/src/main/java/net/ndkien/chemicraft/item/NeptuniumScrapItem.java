package net.ndkien.chemicraft.item;

import net.minecraft.world.item.Item;

public class NeptuniumScrapItem extends Item {
	public NeptuniumScrapItem(Item.Properties properties) {
		super(properties);
	}
}