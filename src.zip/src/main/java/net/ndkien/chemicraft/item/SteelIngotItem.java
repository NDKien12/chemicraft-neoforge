package net.ndkien.chemicraft.item;

import net.minecraft.world.item.Item;

public class SteelIngotItem extends Item {
	public SteelIngotItem(Item.Properties properties) {
		super(properties);
	}
}