package net.ndkien.chemicraft.item;

import net.minecraft.world.item.Item;
import net.minecraft.world.food.FoodProperties;

public class TableSaltItem extends Item {
	public TableSaltItem(Item.Properties properties) {
		super(properties.food((new FoodProperties.Builder()).nutrition(1).saturationModifier(0.1f).build()));
	}
}