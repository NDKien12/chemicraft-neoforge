package net.ndkien.chemicraft.item;

import net.minecraft.world.item.Items;
import net.minecraft.world.item.ItemStackTemplate;
import net.minecraft.world.item.ItemInstance;
import net.minecraft.world.item.Item;

public class KryptonBottleItem extends Item {
	public KryptonBottleItem(Item.Properties properties) {
		super(properties);
	}

	@Override
	public ItemStackTemplate getCraftingRemainder(ItemInstance itemInstance) {
		return new ItemStackTemplate(Items.GLASS_BOTTLE);
	}
}