package net.ndkien.chemicraft.item;

import net.minecraft.world.item.Item;

public class PTypeSemiconductorItem extends Item {
	public PTypeSemiconductorItem(Item.Properties properties) {
		super(properties);
	}
}