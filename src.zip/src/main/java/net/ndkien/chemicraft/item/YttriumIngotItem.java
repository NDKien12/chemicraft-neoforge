package net.ndkien.chemicraft.item;

import net.minecraft.world.item.Item;

public class YttriumIngotItem extends Item {
	public YttriumIngotItem(Item.Properties properties) {
		super(properties);
	}
}