package net.ndkien.chemicraft.item;

import net.minecraft.world.item.Item;

public class SphaleriteItem extends Item {
	public SphaleriteItem(Item.Properties properties) {
		super(properties);
	}
}