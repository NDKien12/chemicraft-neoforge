package net.ndkien.chemicraft.item;

import net.minecraft.world.item.Item;

public class RutheniumIngotItem extends Item {
	public RutheniumIngotItem(Item.Properties properties) {
		super(properties);
	}
}