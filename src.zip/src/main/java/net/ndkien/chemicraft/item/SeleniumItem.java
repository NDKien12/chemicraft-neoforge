package net.ndkien.chemicraft.item;

import net.minecraft.world.item.Item;

public class SeleniumItem extends Item {
	public SeleniumItem(Item.Properties properties) {
		super(properties);
	}
}