package net.ndkien.chemicraft.item;

import net.minecraft.world.item.Item;

public class FermiumNuggetItem extends Item {
	public FermiumNuggetItem(Item.Properties properties) {
		super(properties);
	}
}