package net.ndkien.chemicraft.item;

import net.minecraft.world.item.Item;

public class BerylliumOxideItem extends Item {
	public BerylliumOxideItem(Item.Properties properties) {
		super(properties);
	}
}