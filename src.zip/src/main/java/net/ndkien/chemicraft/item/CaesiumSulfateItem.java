package net.ndkien.chemicraft.item;

import net.minecraft.world.item.Item;

public class CaesiumSulfateItem extends Item {
	public CaesiumSulfateItem(Item.Properties properties) {
		super(properties);
	}
}