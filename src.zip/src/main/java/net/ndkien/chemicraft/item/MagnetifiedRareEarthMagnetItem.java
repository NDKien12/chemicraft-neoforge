package net.ndkien.chemicraft.item;

import net.minecraft.world.item.Item;

public class MagnetifiedRareEarthMagnetItem extends Item {
	public MagnetifiedRareEarthMagnetItem(Item.Properties properties) {
		super(properties);
	}
}