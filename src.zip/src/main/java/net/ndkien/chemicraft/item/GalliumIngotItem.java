package net.ndkien.chemicraft.item;

import net.minecraft.world.item.Item;

public class GalliumIngotItem extends Item {
	public GalliumIngotItem(Item.Properties properties) {
		super(properties);
	}
}