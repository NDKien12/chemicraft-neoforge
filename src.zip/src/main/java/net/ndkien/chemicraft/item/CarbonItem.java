package net.ndkien.chemicraft.item;

import net.minecraft.world.item.Item;

public class CarbonItem extends Item {
	public CarbonItem(Item.Properties properties) {
		super(properties);
	}
}