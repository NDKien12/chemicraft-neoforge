package net.ndkien.chemicraft.item;

import net.minecraft.world.item.Item;

public class AmericiumNuggetItem extends Item {
	public AmericiumNuggetItem(Item.Properties properties) {
		super(properties);
	}
}