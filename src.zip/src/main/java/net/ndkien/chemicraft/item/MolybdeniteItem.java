package net.ndkien.chemicraft.item;

import net.minecraft.world.item.Item;

public class MolybdeniteItem extends Item {
	public MolybdeniteItem(Item.Properties properties) {
		super(properties);
	}
}