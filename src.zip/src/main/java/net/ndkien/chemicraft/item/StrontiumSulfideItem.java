package net.ndkien.chemicraft.item;

import net.minecraft.world.item.Item;

public class StrontiumSulfideItem extends Item {
	public StrontiumSulfideItem(Item.Properties properties) {
		super(properties);
	}
}