package net.ndkien.chemicraft.item;

import net.minecraft.world.item.Item;

public class CassiteriteItem extends Item {
	public CassiteriteItem(Item.Properties properties) {
		super(properties);
	}
}