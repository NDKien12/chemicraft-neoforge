package net.ndkien.chemicraft.item;

import net.minecraft.world.item.Item;

public class Uranium238Item extends Item {
	public Uranium238Item(Item.Properties properties) {
		super(properties);
	}
}