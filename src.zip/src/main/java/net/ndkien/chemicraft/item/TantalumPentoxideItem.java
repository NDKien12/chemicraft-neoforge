package net.ndkien.chemicraft.item;

import net.minecraft.world.item.Item;

public class TantalumPentoxideItem extends Item {
	public TantalumPentoxideItem(Item.Properties properties) {
		super(properties);
	}
}