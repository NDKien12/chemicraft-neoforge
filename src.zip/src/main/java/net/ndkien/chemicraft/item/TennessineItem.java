package net.ndkien.chemicraft.item;

import net.minecraft.world.item.Item;

public class TennessineItem extends Item {
	public TennessineItem(Item.Properties properties) {
		super(properties);
	}
}