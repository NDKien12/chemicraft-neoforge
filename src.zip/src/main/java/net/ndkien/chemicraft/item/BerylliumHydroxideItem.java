package net.ndkien.chemicraft.item;

import net.minecraft.world.item.Item;

public class BerylliumHydroxideItem extends Item {
	public BerylliumHydroxideItem(Item.Properties properties) {
		super(properties);
	}
}