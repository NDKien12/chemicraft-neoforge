package net.ndkien.chemicraft.item;

import net.minecraft.world.item.Item;

public class AstatineScrapItem extends Item {
	public AstatineScrapItem(Item.Properties properties) {
		super(properties);
	}
}