package net.ndkien.chemicraft.item;

import net.minecraft.world.item.Item;

public class HafniumIngotItem extends Item {
	public HafniumIngotItem(Item.Properties properties) {
		super(properties);
	}
}