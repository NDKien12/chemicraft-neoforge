package net.ndkien.chemicraft.item;

import net.minecraft.world.item.Item;

public class MeitneriumItem extends Item {
	public MeitneriumItem(Item.Properties properties) {
		super(properties);
	}
}