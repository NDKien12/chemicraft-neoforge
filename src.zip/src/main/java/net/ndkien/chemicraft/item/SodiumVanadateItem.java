package net.ndkien.chemicraft.item;

import net.minecraft.world.item.Item;

public class SodiumVanadateItem extends Item {
	public SodiumVanadateItem(Item.Properties properties) {
		super(properties);
	}
}