package net.ndkien.chemicraft.item;

import net.minecraft.world.item.Item;

public class RoentgeniumItem extends Item {
	public RoentgeniumItem(Item.Properties properties) {
		super(properties);
	}
}