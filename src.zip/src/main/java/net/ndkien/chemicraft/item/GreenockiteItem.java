package net.ndkien.chemicraft.item;

import net.minecraft.world.item.Item;

public class GreenockiteItem extends Item {
	public GreenockiteItem(Item.Properties properties) {
		super(properties);
	}
}