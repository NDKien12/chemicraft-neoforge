package net.ndkien.chemicraft.item;

import net.minecraft.world.item.Item;

public class SpondumeneItem extends Item {
	public SpondumeneItem(Item.Properties properties) {
		super(properties);
	}
}