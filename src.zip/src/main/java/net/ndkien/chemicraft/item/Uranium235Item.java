package net.ndkien.chemicraft.item;

import net.minecraft.world.item.Item;

public class Uranium235Item extends Item {
	public Uranium235Item(Item.Properties properties) {
		super(properties);
	}
}