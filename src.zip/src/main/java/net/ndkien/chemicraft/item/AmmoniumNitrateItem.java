package net.ndkien.chemicraft.item;

import net.minecraft.world.item.Item;

public class AmmoniumNitrateItem extends Item {
	public AmmoniumNitrateItem(Item.Properties properties) {
		super(properties);
	}
}