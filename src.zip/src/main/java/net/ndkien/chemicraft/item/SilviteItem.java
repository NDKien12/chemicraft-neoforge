package net.ndkien.chemicraft.item;

import net.minecraft.world.item.Item;

public class SilviteItem extends Item {
	public SilviteItem(Item.Properties properties) {
		super(properties);
	}
}