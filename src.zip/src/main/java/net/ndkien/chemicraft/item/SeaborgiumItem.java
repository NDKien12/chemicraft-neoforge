package net.ndkien.chemicraft.item;

import net.minecraft.world.item.Item;

public class SeaborgiumItem extends Item {
	public SeaborgiumItem(Item.Properties properties) {
		super(properties);
	}
}