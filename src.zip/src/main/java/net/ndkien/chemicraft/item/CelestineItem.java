package net.ndkien.chemicraft.item;

import net.minecraft.world.item.Item;

public class CelestineItem extends Item {
	public CelestineItem(Item.Properties properties) {
		super(properties);
	}
}