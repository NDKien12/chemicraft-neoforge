package net.ndkien.chemicraft.item;

import net.minecraft.world.item.Item;

public class CinnabarItem extends Item {
	public CinnabarItem(Item.Properties properties) {
		super(properties);
	}
}