package net.ndkien.chemicraft.item;

import net.minecraft.world.item.ToolMaterial;
import net.minecraft.world.item.Item;
import net.minecraft.tags.TagKey;
import net.minecraft.tags.BlockTags;
import net.minecraft.resources.Identifier;
import net.minecraft.core.registries.Registries;

public class SteelHoeItem extends Item {
	private static final ToolMaterial TOOL_MATERIAL = new ToolMaterial(BlockTags.INCORRECT_FOR_IRON_TOOL, 500, 6f, 0, 2, TagKey.create(Registries.ITEM, Identifier.parse("chemicraft:steel_hoe_repair_items")));

	public SteelHoeItem(Item.Properties properties) {
		super(properties.pickaxe(TOOL_MATERIAL, 0f, -1f));
	}
}