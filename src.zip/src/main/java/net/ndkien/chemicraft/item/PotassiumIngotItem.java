package net.ndkien.chemicraft.item;

import net.minecraft.world.item.Item;

public class PotassiumIngotItem extends Item {
	public PotassiumIngotItem(Item.Properties properties) {
		super(properties);
	}
}