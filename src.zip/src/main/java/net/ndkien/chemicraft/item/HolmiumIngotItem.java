package net.ndkien.chemicraft.item;

import net.minecraft.world.item.Item;

public class HolmiumIngotItem extends Item {
	public HolmiumIngotItem(Item.Properties properties) {
		super(properties);
	}
}