package net.ndkien.chemicraft.item;

import net.minecraft.world.item.Item;

public class GadoliniumIngotItem extends Item {
	public GadoliniumIngotItem(Item.Properties properties) {
		super(properties);
	}
}