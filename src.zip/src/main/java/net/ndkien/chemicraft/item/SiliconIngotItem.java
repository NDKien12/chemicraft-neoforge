package net.ndkien.chemicraft.item;

import net.minecraft.world.item.Item;

public class SiliconIngotItem extends Item {
	public SiliconIngotItem(Item.Properties properties) {
		super(properties);
	}
}