package net.ndkien.chemicraft.item;

import net.minecraft.world.item.Item;

public class FranciumScrapItem extends Item {
	public FranciumScrapItem(Item.Properties properties) {
		super(properties);
	}
}