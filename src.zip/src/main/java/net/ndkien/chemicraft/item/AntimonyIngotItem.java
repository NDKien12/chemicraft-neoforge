package net.ndkien.chemicraft.item;

import net.minecraft.world.item.Item;

public class AntimonyIngotItem extends Item {
	public AntimonyIngotItem(Item.Properties properties) {
		super(properties);
	}
}