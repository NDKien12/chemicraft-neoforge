package net.ndkien.chemicraft.item;

import net.minecraft.world.item.Item;

public class HutchinsoniteItem extends Item {
	public HutchinsoniteItem(Item.Properties properties) {
		super(properties);
	}
}