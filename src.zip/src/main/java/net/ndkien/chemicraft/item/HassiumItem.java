package net.ndkien.chemicraft.item;

import net.minecraft.world.item.Item;

public class HassiumItem extends Item {
	public HassiumItem(Item.Properties properties) {
		super(properties);
	}
}