package net.ndkien.chemicraft.item;

import net.minecraft.world.item.Item;

public class ZirconiumIngotItem extends Item {
	public ZirconiumIngotItem(Item.Properties properties) {
		super(properties);
	}
}