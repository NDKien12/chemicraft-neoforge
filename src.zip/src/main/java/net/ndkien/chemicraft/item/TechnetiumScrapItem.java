package net.ndkien.chemicraft.item;

import net.minecraft.world.item.Item;

public class TechnetiumScrapItem extends Item {
	public TechnetiumScrapItem(Item.Properties properties) {
		super(properties);
	}
}