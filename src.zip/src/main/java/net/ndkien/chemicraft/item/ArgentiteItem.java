package net.ndkien.chemicraft.item;

import net.minecraft.world.item.Item;

public class ArgentiteItem extends Item {
	public ArgentiteItem(Item.Properties properties) {
		super(properties);
	}
}