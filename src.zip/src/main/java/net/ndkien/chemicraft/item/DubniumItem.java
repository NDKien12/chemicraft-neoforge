package net.ndkien.chemicraft.item;

import net.minecraft.world.item.Item;

public class DubniumItem extends Item {
	public DubniumItem(Item.Properties properties) {
		super(properties);
	}
}