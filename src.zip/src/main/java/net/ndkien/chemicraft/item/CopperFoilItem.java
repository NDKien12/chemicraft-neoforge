package net.ndkien.chemicraft.item;

import net.minecraft.world.item.Item;

public class CopperFoilItem extends Item {
	public CopperFoilItem(Item.Properties properties) {
		super(properties);
	}
}