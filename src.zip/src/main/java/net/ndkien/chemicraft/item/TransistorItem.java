package net.ndkien.chemicraft.item;

import net.minecraft.world.item.Item;

public class TransistorItem extends Item {
	public TransistorItem(Item.Properties properties) {
		super(properties);
	}
}