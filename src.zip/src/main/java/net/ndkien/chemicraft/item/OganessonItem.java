package net.ndkien.chemicraft.item;

import net.minecraft.world.item.Item;

public class OganessonItem extends Item {
	public OganessonItem(Item.Properties properties) {
		super(properties);
	}
}