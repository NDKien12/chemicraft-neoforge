package net.ndkien.chemicraft.item;

import net.minecraft.world.item.Item;

public class TungstenTrioxideItem extends Item {
	public TungstenTrioxideItem(Item.Properties properties) {
		super(properties);
	}
}