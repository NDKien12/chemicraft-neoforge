package net.ndkien.chemicraft.item;

import net.minecraft.world.item.Item;

public class AmmoniaSolutionItem extends Item {
	public AmmoniaSolutionItem(Item.Properties properties) {
		super(properties);
	}
}