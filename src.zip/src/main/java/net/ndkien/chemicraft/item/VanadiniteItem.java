package net.ndkien.chemicraft.item;

import net.minecraft.world.item.Item;

public class VanadiniteItem extends Item {
	public VanadiniteItem(Item.Properties properties) {
		super(properties);
	}
}