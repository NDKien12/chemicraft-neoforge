package net.ndkien.chemicraft.item;

import net.minecraft.world.item.Item;

public class AquamarineItem extends Item {
	public AquamarineItem(Item.Properties properties) {
		super(properties);
	}
}