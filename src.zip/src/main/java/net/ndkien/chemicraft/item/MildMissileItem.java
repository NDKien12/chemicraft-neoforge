package net.ndkien.chemicraft.item;

import net.minecraft.world.item.Item;

public class MildMissileItem extends Item {
	public MildMissileItem(Item.Properties properties) {
		super(properties);
	}
}