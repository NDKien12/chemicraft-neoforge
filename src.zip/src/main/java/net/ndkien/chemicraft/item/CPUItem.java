package net.ndkien.chemicraft.item;

import net.minecraft.world.item.Item;

public class CPUItem extends Item {
	public CPUItem(Item.Properties properties) {
		super(properties);
	}
}