package net.ndkien.chemicraft.item;

import net.minecraft.world.item.Item;

public class ZincOxideItem extends Item {
	public ZincOxideItem(Item.Properties properties) {
		super(properties);
	}
}