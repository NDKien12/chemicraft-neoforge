package net.ndkien.chemicraft.item;

import net.minecraft.world.item.Item;

public class ScandiumIngotItem extends Item {
	public ScandiumIngotItem(Item.Properties properties) {
		super(properties);
	}
}