package net.ndkien.chemicraft.item;

import net.minecraft.world.item.Item;

public class EuropiumIngotItem extends Item {
	public EuropiumIngotItem(Item.Properties properties) {
		super(properties);
	}
}