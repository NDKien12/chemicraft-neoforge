package net.ndkien.chemicraft.item;

import net.minecraft.world.item.Item;

public class MolybdenumItem extends Item {
	public MolybdenumItem(Item.Properties properties) {
		super(properties);
	}
}