package net.ndkien.chemicraft.item;

import net.minecraft.world.item.Item;

public class SodiumIodideItem extends Item {
	public SodiumIodideItem(Item.Properties properties) {
		super(properties);
	}
}