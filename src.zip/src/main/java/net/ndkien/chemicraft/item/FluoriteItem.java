package net.ndkien.chemicraft.item;

import net.minecraft.world.item.Item;

public class FluoriteItem extends Item {
	public FluoriteItem(Item.Properties properties) {
		super(properties);
	}
}