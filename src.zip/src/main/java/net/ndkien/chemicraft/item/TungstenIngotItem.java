package net.ndkien.chemicraft.item;

import net.minecraft.world.item.Item;

public class TungstenIngotItem extends Item {
	public TungstenIngotItem(Item.Properties properties) {
		super(properties);
	}
}