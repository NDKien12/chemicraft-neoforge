package net.ndkien.chemicraft.item;

import net.minecraft.world.item.Item;

public class StrontiumIngotItem extends Item {
	public StrontiumIngotItem(Item.Properties properties) {
		super(properties);
	}
}