package net.ndkien.chemicraft.item;

import net.minecraft.world.item.Item;

public class ErbiumIngotItem extends Item {
	public ErbiumIngotItem(Item.Properties properties) {
		super(properties);
	}
}