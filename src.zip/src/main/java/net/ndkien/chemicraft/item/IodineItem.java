package net.ndkien.chemicraft.item;

import net.minecraft.world.item.Item;

public class IodineItem extends Item {
	public IodineItem(Item.Properties properties) {
		super(properties);
	}
}