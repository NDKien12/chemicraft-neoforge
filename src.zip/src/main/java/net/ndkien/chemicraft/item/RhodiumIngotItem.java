package net.ndkien.chemicraft.item;

import net.minecraft.world.item.Item;

public class RhodiumIngotItem extends Item {
	public RhodiumIngotItem(Item.Properties properties) {
		super(properties);
	}
}