package net.ndkien.chemicraft.item;

import net.minecraft.world.item.ToolMaterial;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.AxeItem;
import net.minecraft.tags.TagKey;
import net.minecraft.tags.BlockTags;
import net.minecraft.resources.Identifier;
import net.minecraft.core.registries.Registries;

public class TungstenHoeItem extends AxeItem {
	private static final ToolMaterial TOOL_MATERIAL = new ToolMaterial(BlockTags.INCORRECT_FOR_DIAMOND_TOOL, 1741, 9f, 0, 14, TagKey.create(Registries.ITEM, Identifier.parse("chemicraft:tungsten_hoe_repair_items")));

	public TungstenHoeItem(Item.Properties properties) {
		super(TOOL_MATERIAL, 0f, 0f, properties.fireResistant());
	}
}