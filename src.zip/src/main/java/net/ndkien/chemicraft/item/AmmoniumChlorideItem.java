package net.ndkien.chemicraft.item;

import net.minecraft.world.item.Item;

public class AmmoniumChlorideItem extends Item {
	public AmmoniumChlorideItem(Item.Properties properties) {
		super(properties);
	}
}