package net.ndkien.chemicraft.item;

import net.minecraft.world.item.Item;

public class ArsenicItem extends Item {
	public ArsenicItem(Item.Properties properties) {
		super(properties);
	}
}