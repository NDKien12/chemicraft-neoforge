package net.ndkien.chemicraft.item;

import net.minecraft.world.item.Item;

public class AluminumFoilItem extends Item {
	public AluminumFoilItem(Item.Properties properties) {
		super(properties);
	}
}