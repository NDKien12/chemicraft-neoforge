package net.ndkien.chemicraft.item;

import net.minecraft.world.item.Item;

public class UraniumHexafluorideItem extends Item {
	public UraniumHexafluorideItem(Item.Properties properties) {
		super(properties);
	}
}