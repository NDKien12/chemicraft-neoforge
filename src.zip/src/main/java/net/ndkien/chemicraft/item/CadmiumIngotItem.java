package net.ndkien.chemicraft.item;

import net.minecraft.world.item.Item;

public class CadmiumIngotItem extends Item {
	public CadmiumIngotItem(Item.Properties properties) {
		super(properties);
	}
}