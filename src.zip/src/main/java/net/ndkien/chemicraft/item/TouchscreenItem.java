package net.ndkien.chemicraft.item;

import net.minecraft.world.item.Item;

public class TouchscreenItem extends Item {
	public TouchscreenItem(Item.Properties properties) {
		super(properties);
	}
}