package net.ndkien.chemicraft.item;

import net.minecraft.world.item.Item;

public class LawrenciumNuggetItem extends Item {
	public LawrenciumNuggetItem(Item.Properties properties) {
		super(properties);
	}
}