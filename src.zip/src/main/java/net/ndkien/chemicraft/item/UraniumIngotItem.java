package net.ndkien.chemicraft.item;

import net.minecraft.world.item.Item;

public class UraniumIngotItem extends Item {
	public UraniumIngotItem(Item.Properties properties) {
		super(properties);
	}
}