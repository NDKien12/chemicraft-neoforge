package net.ndkien.chemicraft.item;

import net.minecraft.world.item.Item;

public class LithiumIngotItem extends Item {
	public LithiumIngotItem(Item.Properties properties) {
		super(properties);
	}
}