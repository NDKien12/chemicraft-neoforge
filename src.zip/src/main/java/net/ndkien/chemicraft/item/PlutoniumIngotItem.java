package net.ndkien.chemicraft.item;

import net.minecraft.world.item.Item;

public class PlutoniumIngotItem extends Item {
	public PlutoniumIngotItem(Item.Properties properties) {
		super(properties);
	}
}