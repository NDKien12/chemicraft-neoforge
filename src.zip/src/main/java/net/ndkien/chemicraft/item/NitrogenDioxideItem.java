package net.ndkien.chemicraft.item;

import net.minecraft.world.item.Items;
import net.minecraft.world.item.ItemStackTemplate;
import net.minecraft.world.item.ItemInstance;
import net.minecraft.world.item.Item;

public class NitrogenDioxideItem extends Item {
	public NitrogenDioxideItem(Item.Properties properties) {
		super(properties.stacksTo(16));
	}

	@Override
	public ItemStackTemplate getCraftingRemainder(ItemInstance itemInstance) {
		return new ItemStackTemplate(Items.GLASS_BOTTLE);
	}
}