package net.ndkien.chemicraft.item;

import net.minecraft.world.item.Item;

public class ThoriumIngotItem extends Item {
	public ThoriumIngotItem(Item.Properties properties) {
		super(properties);
	}
}