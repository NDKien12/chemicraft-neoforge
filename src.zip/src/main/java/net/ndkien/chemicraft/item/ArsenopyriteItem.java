package net.ndkien.chemicraft.item;

import net.minecraft.world.item.Item;

public class ArsenopyriteItem extends Item {
	public ArsenopyriteItem(Item.Properties properties) {
		super(properties);
	}
}