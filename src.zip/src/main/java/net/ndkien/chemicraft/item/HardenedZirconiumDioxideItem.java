package net.ndkien.chemicraft.item;

import net.minecraft.world.item.Item;

public class HardenedZirconiumDioxideItem extends Item {
	public HardenedZirconiumDioxideItem(Item.Properties properties) {
		super(properties);
	}
}