package net.ndkien.chemicraft.item;

import net.minecraft.world.item.Item;

public class MonaziteItem extends Item {
	public MonaziteItem(Item.Properties properties) {
		super(properties);
	}
}