package net.ndkien.chemicraft.item;

import net.minecraft.world.item.Item;

public class PalladiumIngotItem extends Item {
	public PalladiumIngotItem(Item.Properties properties) {
		super(properties);
	}
}