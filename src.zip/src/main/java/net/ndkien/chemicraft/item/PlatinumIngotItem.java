package net.ndkien.chemicraft.item;

import net.minecraft.world.item.Item;

public class PlatinumIngotItem extends Item {
	public PlatinumIngotItem(Item.Properties properties) {
		super(properties);
	}
}