package net.ndkien.chemicraft.item;

import net.minecraft.world.item.Item;

public class MagnesiumIngotItem extends Item {
	public MagnesiumIngotItem(Item.Properties properties) {
		super(properties);
	}
}