package net.ndkien.chemicraft.item;

import net.minecraft.world.item.Item;

public class ZirconItem extends Item {
	public ZirconItem(Item.Properties properties) {
		super(properties);
	}
}