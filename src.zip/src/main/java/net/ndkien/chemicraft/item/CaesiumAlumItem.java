package net.ndkien.chemicraft.item;

import net.minecraft.world.item.Item;

public class CaesiumAlumItem extends Item {
	public CaesiumAlumItem(Item.Properties properties) {
		super(properties);
	}
}