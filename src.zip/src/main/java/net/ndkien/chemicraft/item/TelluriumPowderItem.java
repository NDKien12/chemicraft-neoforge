package net.ndkien.chemicraft.item;

import net.minecraft.world.item.Item;

public class TelluriumPowderItem extends Item {
	public TelluriumPowderItem(Item.Properties properties) {
		super(properties);
	}
}