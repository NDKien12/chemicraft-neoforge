package net.ndkien.chemicraft.item;

import net.minecraft.world.item.Item;

public class CeriumIngotItem extends Item {
	public CeriumIngotItem(Item.Properties properties) {
		super(properties);
	}
}