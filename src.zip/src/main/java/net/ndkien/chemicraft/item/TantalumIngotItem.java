package net.ndkien.chemicraft.item;

import net.minecraft.world.item.Item;

public class TantalumIngotItem extends Item {
	public TantalumIngotItem(Item.Properties properties) {
		super(properties);
	}
}