package net.ndkien.chemicraft.item;

import net.minecraft.world.item.Item;

public class StibniteItem extends Item {
	public StibniteItem(Item.Properties properties) {
		super(properties);
	}
}