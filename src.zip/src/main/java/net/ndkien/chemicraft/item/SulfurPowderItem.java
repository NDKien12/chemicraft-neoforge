package net.ndkien.chemicraft.item;

import net.minecraft.world.item.Item;

public class SulfurPowderItem extends Item {
	public SulfurPowderItem(Item.Properties properties) {
		super(properties);
	}
}