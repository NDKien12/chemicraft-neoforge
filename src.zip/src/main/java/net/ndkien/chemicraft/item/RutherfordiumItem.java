package net.ndkien.chemicraft.item;

import net.minecraft.world.item.Item;

public class RutherfordiumItem extends Item {
	public RutherfordiumItem(Item.Properties properties) {
		super(properties);
	}
}