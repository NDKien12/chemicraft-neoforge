package net.ndkien.chemicraft.item;

import net.minecraft.world.item.Item;

public class VanadiumPentoxideItem extends Item {
	public VanadiumPentoxideItem(Item.Properties properties) {
		super(properties);
	}
}