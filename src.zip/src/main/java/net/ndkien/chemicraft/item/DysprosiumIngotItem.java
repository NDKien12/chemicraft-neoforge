package net.ndkien.chemicraft.item;

import net.minecraft.world.item.Item;

public class DysprosiumIngotItem extends Item {
	public DysprosiumIngotItem(Item.Properties properties) {
		super(properties);
	}
}