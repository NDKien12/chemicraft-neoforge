package net.ndkien.chemicraft.item;

import net.minecraft.world.item.Item;

public class CopperOxideItem extends Item {
	public CopperOxideItem(Item.Properties properties) {
		super(properties);
	}
}