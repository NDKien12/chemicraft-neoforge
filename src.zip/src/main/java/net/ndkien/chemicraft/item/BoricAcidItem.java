package net.ndkien.chemicraft.item;

import net.minecraft.world.item.Item;

public class BoricAcidItem extends Item {
	public BoricAcidItem(Item.Properties properties) {
		super(properties);
	}
}