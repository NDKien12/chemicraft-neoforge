package net.ndkien.chemicraft.item;

import net.minecraft.world.item.Item;

public class AtomicBatteryItem extends Item {
	public AtomicBatteryItem(Item.Properties properties) {
		super(properties);
	}
}