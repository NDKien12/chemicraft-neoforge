package net.ndkien.chemicraft.item;

import net.minecraft.world.item.Item;

public class BohriumItem extends Item {
	public BohriumItem(Item.Properties properties) {
		super(properties);
	}
}