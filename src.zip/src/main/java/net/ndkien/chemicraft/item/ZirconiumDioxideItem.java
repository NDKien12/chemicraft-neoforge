package net.ndkien.chemicraft.item;

import net.minecraft.world.item.Item;

public class ZirconiumDioxideItem extends Item {
	public ZirconiumDioxideItem(Item.Properties properties) {
		super(properties);
	}
}