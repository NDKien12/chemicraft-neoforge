package net.ndkien.chemicraft.item;

import net.minecraft.world.item.Item;

public class CobaltiteItem extends Item {
	public CobaltiteItem(Item.Properties properties) {
		super(properties);
	}
}