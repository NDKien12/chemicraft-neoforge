package net.ndkien.chemicraft.item;

import net.minecraft.world.item.Item;

public class RheniumIngotItem extends Item {
	public RheniumIngotItem(Item.Properties properties) {
		super(properties.fireResistant());
	}
}