package net.ndkien.chemicraft.item;

import net.minecraft.world.item.Item;

public class CryoliteItem extends Item {
	public CryoliteItem(Item.Properties properties) {
		super(properties);
	}
}