package net.ndkien.chemicraft.item;

import net.minecraft.world.item.Item;

public class BaryteItem extends Item {
	public BaryteItem(Item.Properties properties) {
		super(properties);
	}
}