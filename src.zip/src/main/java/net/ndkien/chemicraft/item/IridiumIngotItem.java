package net.ndkien.chemicraft.item;

import net.minecraft.world.item.Item;

public class IridiumIngotItem extends Item {
	public IridiumIngotItem(Item.Properties properties) {
		super(properties);
	}
}