package net.ndkien.chemicraft.potion;

import net.ndkien.chemicraft.procedures.AnesthesiaEffectStartedappliedProcedure;

import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.effect.MobEffectCategory;
import net.minecraft.world.effect.MobEffect;

public class AnesthesiaMobEffect extends MobEffect {
	public AnesthesiaMobEffect() {
		super(MobEffectCategory.HARMFUL, -16737793);
	}

	@Override
	public void onEffectStarted(LivingEntity entity, int amplifier) {
		AnesthesiaEffectStartedappliedProcedure.execute(entity.level(), entity.getX(), entity.getY(), entity.getZ());
	}
}